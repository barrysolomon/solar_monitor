# Solar Monitor v1.0.89 - Professional SunPower Monitoring System 🏆

**🌞 Complete Local Solar Monitoring Solution - CURRENT STABLE VERSION!**

A professional, feature-complete solar monitoring system for SunPower installations. **Replace expensive cloud services with your own local dashboard!** Features real-time charts, device management, comprehensive database interface, and advanced analytics. **No monthly fees, complete data ownership, works offline.**

![Solar Monitor Dashboard](docs/images/dashboard-v1.0.19.png)
*Professional dashboard with comprehensive database management, real-time monitoring, and advanced analytics*

## ✨ Features (v1.0.81 - Current Stable)

### 📊 Professional Dashboard
- **Multi-Section Interface**: Overview, Devices, Charts, Database, Raw Data, Export tabs
- **Real-Time Updates**: Live data refreshes every 30 seconds automatically
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Professional Charts**: Interactive Chart.js visualizations with multiple time periods
- **Device Management**: Monitor all 21 devices with detailed breakdown (18 Inverters, 3 Other)
- **Smart Device Counting**: Auto-updating device statistics with component breakdown
- **Service Status Monitoring**: Real-time data collector service status display
- **URL State Management**: F5-friendly navigation with shareable bookmarkable links
- **Cached Data System**: Reliable operation during PVS6 disconnections
- **Database-First Loading**: Instant page loads using historical data, no PVS6 delays

### 🗄️ Comprehensive Database Management (NEW!)
- **Database Statistics**: Total records, file size, data ranges, table breakdowns
- **Advanced Table Browser**: Filter by time range, device type, with sortable columns
- **SQL Query Interface**: Full SQL editor with syntax highlighting
- **Pre-built Query Templates**: Recent production, device summary, hourly totals, top producers
- **Data Export**: One-click CSV downloads for tables and query results
- **Database Maintenance**: Cleanup old data, optimize performance, full backups

### 🔧 Advanced Configuration
- **Timezone Support**: Mountain, Eastern, Central, Pacific, UTC time zones
- **Theme Options**: Light and dark mode support
- **Update Intervals**: Configurable refresh rates (10-300 seconds)
- **Debug Mode**: Built-in debugging panel for troubleshooting
- **Force Refresh**: Manual data collection trigger with status indicators
- **Data Freshness**: Real-time indicators showing data age and source

### 💾 Robust Data Management
- **SQLite Database**: Reliable local data storage with indexing
- **Cached Data System**: Smart fallback when PVS6 is temporarily unreachable
- **System Monitoring**: CPU, memory, disk usage tracking
- **Automatic Backup**: Continuous data collection and storage
- **Offline Operation**: Works completely without internet connection
- **Performance Optimization**: Database VACUUM and cleanup tools

### 🌐 Network Connectivity
- **WiFi Bridge**: Wireless access from anywhere in your home
- **PVS6 WiFi Hotspot**: Direct connection to PVS6's built-in WiFi
- **Ethernet Fallback**: Reliable wired connection option
- **Auto-Reconnection**: Robust network error handling and recovery

## 🛒 Recommended Hardware

### Choose Your Pi Configuration

#### **Option 1: Basic Setup (2GB) - $75**
- **[Raspberry Pi 4 (2GB)](https://amzn.to/your-pi-2gb-link)** - $35-45
- **[32GB MicroSD Card](https://amzn.to/your-sd-link)** - $8-12  
- **[Official USB-C Power Supply (5V/3A)](https://www.amazon.com/Official-Connector-Raspberry-XYGStudy-PI-PSU-5V3A-USB-C-US/dp/B0CYZ7FPH4)** - $10-15
- **[Cat6 Ethernet Cable (50ft)](https://www.amazon.com/Cable-Matters-Snagless-Ethernet-Black/dp/B007NZHQDY)** - $12-20
- **[Pi Case with Fan](https://amzn.to/your-case-link)** - $10-15

**Best for:** Simple monitoring, budget-conscious users

#### **Option 2: Advanced Setup (4GB) - $95**
- **[Raspberry Pi 4 (4GB)](https://amzn.to/your-pi-4gb-link)** - $55-65
- **[64GB MicroSD Card](https://amzn.to/your-sd-64gb-link)** - $12-18
- **[USB-C Power Supply with Switch](https://www.amazon.com/Adapter-Raspberry-Version-Supply-Charger/dp/B08523QCT6)** - $12-18
- **[Cat6 Ethernet Cable (50ft)](https://www.amazon.com/Cable-Matters-Snagless-Ethernet-Black/dp/B007NZHQDY)** - $12-20
- **[Pi Case with Fan](https://amzn.to/your-case-link)** - $10-15

**Best for:** Home Assistant integration, Grafana, Bluetooth features

#### **Option 3: Professional Setup (8GB) - $115**
- **[Raspberry Pi 4 (8GB)](https://amzn.to/your-pi-8gb-link)** - $75-85
- **[128GB MicroSD Card](https://amzn.to/your-sd-128gb-link)** - $18-25
- **[Premium USB-C Power Supply](https://www.amazon.com/Miuzei-Raspberry-Compatible-Charger-Adapter/dp/B09WYRFWMW)** - $12-18
- **[Outdoor Cat6 Ethernet Cable (50ft)](https://www.amazon.com/Maximm-Cat6-Outdoor-Cable-50ft/dp/B0745ZQ1KR)** - $18-25
- **[Premium Pi Case with OLED](https://amzn.to/your-premium-case-link)** - $25-35

**Best for:** Complete smart home hub, multiple projects, advanced automation

### Optional Accessories
- **[MicroSD Card Reader](https://amzn.to/your-reader-link)** - $5-10
- **[Heat Sinks](https://amzn.to/your-heatsink-link)** - $5-8
- **[Bluetooth Sensors](https://amzn.to/your-bluetooth-sensors-link)** - $15-25
- **[Weather Station](https://amzn.to/your-weather-station-link)** - $30-50

### 💰 Cost Comparison vs SunStrong

| Feature | SunStrong | Your Local System | Annual Savings |
|---------|-----------|-------------------|----------------|
| **Basic Monitoring** | $10/month | **FREE** | **$120/year** |
| **Historical Data** | $10/month | **FREE** | **$120/year** |
| **Data Ownership** | ❌ No | **✅ Complete** | **Priceless** |
| **No Internet Required** | ❌ No | **✅ Works Offline** | **Reliability** |
| **Custom Features** | ❌ Limited | **✅ Unlimited** | **Flexibility** |

**Total Annual Savings: $120+ per year** (plus complete data ownership and reliability!)

## ⚠️ Important Disclaimer

**This project is a compilation of information and approaches gathered from various community sources and research, plus the author's imagination and musings of possibilities (both practical and not). It has NOT been personally tested by the author yet, but testing is planned.**

### What This Project Is
- **Compiled information** from multiple community sources
- **Theoretical implementation** based on proven concepts
- **Educational resource** for understanding SunPower local monitoring
- **Creative exploration** of possibilities and potential solutions
- **Community-driven approach** building on existing work

### What This Project Is NOT
- **Personally tested** by the author
- **Guaranteed to work** in all scenarios
- **Official SunPower documentation**
- **Professional installation guide**

### 🚨 Comprehensive Legal Disclaimer
**I will not be held liable for ANY damage, injury, warranty voiding, system failures, electrical fires, data loss, or any other consequences that result from:**

- **Following any instructions** in this project
- **Attempting any modifications** to your solar system
- **Using any code or scripts** provided
- **Making any electrical connections** or modifications
- **Opening or modifying** your PVS6 or any solar equipment
- **Installing any hardware** suggested in this project
- **Doing anything stupid** with any part of this project

**You are 100% responsible for your own actions and decisions.** This is educational material only. Use at your own risk. If you break something, electrocute yourself, void warranties, or burn down your house, that's on you, not me.

**Seriously, don't be stupid. If you're not sure what you're doing, don't do it.**

### Sources and Inspiration
This project builds upon the work of:

#### Primary Contributors
- **[Scott Gruby](https://blog.gruby.com/2020/04/28/monitoring-a-sunpower-solar-system/)** - "Monitoring a SunPower Solar System" blog post (April 2020)
- **[Nelson Minar](https://nelsonslog.wordpress.com/2021/12/02/getting-local-access-to-sunpower-pvs6-data/)** - Comprehensive PVS6 documentation and monitoring system setup
- **[Gino Ledesma](https://github.com/ginoledesma/sunpower-pvs-exporter)** - sunpower-pvs-exporter Prometheus integration
- **[Kiel Koleson](https://gist.github.com/koleson/5c719620039e0282976a8263c068e85c)** - Extensive PVS6 technical notes and documentation
- **[Kevin Fleming](https://github.com/kpfleming/esphome-sunpower)** - ESPHome components for SunPower PVS devices
- **[Hasherati](https://github.com/hasherati/solar)** - Alternative SunPower PVS6 query methods and approaches

#### Community Projects
- **[GitHub community projects](https://github.com/search?q=sunpower+monitoring)** - Various SunPower monitoring implementations
- **[Home Assistant integrations](https://www.home-assistant.io/integrations/)** - Community-developed HA components
- **[ESPHome components](https://esphome.io/)** - Experimental SunPower data collection
- **[Prometheus/Grafana exporters](https://prometheus.io/docs/instrumenting/exporters/)** - Professional monitoring approaches

### Theoretical Basis
The approaches described here are **theoretically sound** because they:
- **Use documented API endpoints** that have been tested by others
- **Follow established networking principles** for PVS6 access
- **Build upon proven hardware configurations** (Raspberry Pi, Powerline adapters)
- **Implement standard software patterns** (Python, Flask, SQLite, etc.)

### Use at Your Own Risk
- **Test thoroughly** before deploying in production
- **Follow electrical safety guidelines** when working with solar equipment
- **Backup your data** before making changes
- **Consult professionals** for electrical work if needed
- **Verify compatibility** with your specific PVS6 model and firmware

### Contributing and Testing
If you successfully implement this system:
- **Share your experience** - What worked, what didn't
- **Report issues** - Help improve the documentation
- **Submit improvements** - Enhance the guides and code
- **Test on different systems** - Verify compatibility across setups

**Remember**: This is a community-driven project based on research and compilation of existing work. Your mileage may vary!


## 🚀 Quick Start - One Command Installation

### ⚡ Super Simple Setup (15 minutes total!)
**Professional solar monitoring in 3 easy steps**

#### Step 1: Prepare Raspberry Pi (10 minutes)
1. **Flash SD Card**: Use Raspberry Pi Imager with Raspberry Pi OS Lite
2. **Enable SSH**: Set username `barry` and password during imaging
3. **Boot & Connect**: Connect Pi to your network via Ethernet
4. **Find IP**: Check your router or use `nmap -sn 192.168.1.0/24`

#### Step 2: Install Solar Monitor (3 minutes)
SSH to your Pi and run ONE command:

```bash
wget -O /tmp/solar_monitor_v1.0.19_database_page.tar.gz http://YOUR_COMPUTER_IP:8008/solar_monitor_v1.0.19_database_page.tar.gz && cd /tmp && tar -xzf solar_monitor_v1.0.19_database_page.tar.gz && sudo cp web_dashboard_cached_simple.py /home/barry/solar_monitor/src/web_dashboard.py && sudo cp src/version.py /home/barry/solar_monitor/src/ && sudo cp templates/dashboard.html /home/barry/solar_monitor/templates/ && sudo systemctl restart solar-monitor.service && echo "✅ Solar Monitor v1.0.19 deployed!"
```

**🏆 This installs the GOLDEN VERSION v1.0.19 with comprehensive database management!**

**That's it!** The script automatically:
- ✅ Installs all dependencies (Python, Flask, Chart.js)
- ✅ Configures PVS6 connection (WiFi hotspot + Ethernet)
- ✅ Sets up professional dashboard with 5 sections
- ✅ Starts monitoring service with auto-restart
- ✅ Begins data collection every 60 seconds

#### Step 3: Access Your Dashboard (2 minutes)
Open browser: `http://YOUR_PI_IP:5000/`

**🎉 Expected Results:**
- **📊 Dashboard**: Real-time stats updating every 30 seconds
- **📟 Devices**: All 21 devices (PVS6 + 2 meters + 18 inverters)
- **📈 Analytics**: Historical charts with timezone support
- **🗄️ Database**: Raw data viewer with pagination
- **⚙️ System**: Performance monitoring and configuration

![Dashboard Preview](docs/images/dashboard-v1.0.4-preview.png)
*Professional interface with Mountain Time support and debug tools*

## 📚 Complete Documentation

### 🚀 Getting Started
- **[Quick Start Guide](QUICKSTART.md)** - **Quick start guide with both setup options**
- **[Beginner's Guide](docs/guides/BEGINNER_GUIDE.md)** - Complete guide for non-technical users
- **[FAQ](docs/guides/FAQ.md)** - Frequently asked questions and troubleshooting
- **[Approach Comparison](docs/APPROACH_COMPARISON.md)** - **Compare all setup options and get recommendations**

### 🔧 Hardware & Setup
- **[Hardware Checklist](docs/hardware/HARDWARE_CHECKLIST.md)** - Detailed shopping list and purchase guide
- **[Hardware Comparison](docs/hardware/HARDWARE_COMPARISON.md)** - Compare Pi vs ESP32 vs other options
- **[Raspberry Pi Setup](RASPBERRY_PI_SETUP.md)** - **Raspberry Pi setup instructions (~$100)**
- **[Network Setup](docs/guides/NETWORK_SETUP.md)** - Network configuration and troubleshooting
- **[PVS6 Ports Guide](docs/hardware/PVS6_PORTS_GUIDE.md)** - Understanding BLUE vs WHITE Ethernet ports
- **[PVS6 Troubleshooting](docs/hardware/PVS6_TROUBLESHOOTING.md)** - **Complete troubleshooting guide for PVS6 connection issues including WiFi hotspot**
- **[Powerline Setup](docs/hardware/POWERLINE_SETUP.md)** - Use Powerline adapters instead of Ethernet cables

### 🔧 Advanced Setup Options
- **[WiFi Dongle Solutions](docs/wifi/WIFI_DONGLE_SOLUTION.md)** - Alternative WiFi connection methods
- **[Power Tapping Guide](docs/wifi/PVS6_POWER_TAPPING.md)** - Advanced power solutions ⚠️

### 🔗 Integrations
- **[Home Assistant Integration](docs/HOME_ASSISTANT_INTEGRATION.md)** - Integrate with Home Assistant
- **[Grafana Integration](docs/GRAFANA_INTEGRATION.md)** - Professional monitoring with Grafana
- **[Bluetooth Setup](docs/bluetooth/BLUETOOTH_SETUP.md)** - Bluetooth integration and mobile app connectivity
- **[Community Integration](docs/COMMUNITY_INTEGRATION.md)** - Connect with community projects

### 📱 Mobile Development
- **[Mobile App Project](docs/mobile/MOBILE_APP_PROJECT.md)** - **iOS/Android mobile app development**
- **[Mobile App Development](docs/mobile/MOBILE_APP_DEVELOPMENT.md)** - **Complete mobile app development guide**

### 🛒 Business & Legal
- **[Legal Considerations](docs/legal/LEGAL_CONSIDERATIONS.md)** - Business and legal analysis
- **[Disclaimer](docs/legal/DISCLAIMER.md)** - Legal notice and project status
- **[Acknowledgments](docs/legal/ACKNOWLEDGMENTS.md)** - Complete credits and references

### 📊 Tools & Resources
- **[SEO Meta Tags](docs/SEO_META_TAGS.md)** - **SEO optimization for search engines**
- **[Scott Gruby's Blog](https://blog.gruby.com/2020/04/28/monitoring-a-sunpower-solar-system/)** - Original PVS6 API research
- **[Nelson Minar's Documentation](https://nelsonslog.wordpress.com/2021/12/02/getting-local-access-to-sunpower-pvs6-data/)** - PVS6 access methods
- **[Gino Ledesma's Prometheus Exporter](https://github.com/ginoledesma/sunpower-pvs-exporter)** - Professional monitoring
- **[Kiel Koleson's Technical Notes](https://gist.github.com/koleson/5c719620039e0282976a8263c068e85c)** - PVS6 specifications
- **[Kevin Fleming's ESPHome Components](https://github.com/kpfleming/esphome-sunpower)** - ESP32 integration
- **[Hasherati's Solar Project](https://github.com/hasherati/solar)** - Alternative approaches

### 🐍 Source Code (`src/` Directory)
- **solar_monitor.py** - Main application launcher
- **pvs_client.py** - PVS6 API client
- **data_collector.py** - Data collection service
- **database.py** - Database management
- **web_dashboard.py** - Web dashboard interface
- **config.py** - Configuration settings
- **bluetooth_monitor.py** - Bluetooth monitoring and automation
- **mobile_api.py** - Mobile app API endpoints

### Project Information
- **[SUCCESS_STORY.md](SUCCESS_STORY.md)** - **PROOF IT WORKS! Real dashboard screenshot and implementation details**
- **[DISCLAIMER.md](docs/legal/DISCLAIMER.md)** - Important disclaimer and legal notice
- **[ENHANCEMENT_OPPORTUNITIES.md](docs/ENHANCEMENT_OPPORTUNITIES.md)** - Community projects and future enhancements

## 🛠️ Troubleshooting

### 🔧 Common Issues & Solutions

#### Service Not Starting?
```bash
# Check service status
sudo systemctl status solar-monitor.service

# View recent logs
sudo journalctl -u solar-monitor.service -n 20

# Restart service
sudo systemctl restart solar-monitor.service
```

#### Dashboard Not Loading?
```bash
# Test local connection
curl http://localhost:5000/api/current_status

# Check if port is open
sudo netstat -tlnp | grep :5000

# Restart and check logs
sudo systemctl restart solar-monitor.service
sudo journalctl -u solar-monitor.service -f
```

#### PVS6 Connection Issues?
```bash
# Check WiFi connection to PVS6 hotspot
iwconfig
ping 172.27.152.1

# Test PVS6 API directly
curl "http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList"

# Check network interfaces
ip addr show
```

#### JavaScript Errors in Browser?
1. **Open browser console** (F12 → Console tab)
2. **Enable debug mode** (Config → Debug button)
3. **Check for errors** and note the specific error messages
4. **Force refresh** (Ctrl+F5 or Cmd+Shift+R)

#### No Data Showing?
```bash
# Check database
ls -la ~/solar_monitor/solar_data.db

# Test PVS connection manually
cd ~/solar_monitor/src
python3 -c "from pvs_client import PVSClient; client = PVSClient(); print(client.test_connection())"

# Check data collection
sudo journalctl -u solar-monitor.service | grep "Data collected"
```

## 💰 Cost Comparison

| Feature | SunStrong | Your System | Annual Savings |
|---------|-----------|-------------|----------------|
| **Basic Monitoring** | $10/month | **FREE** | **$120/year** |
| **Data Ownership** | ❌ No | **✅ Complete** | **Priceless** |
| **Offline Access** | ❌ No | **✅ Yes** | **Reliability** |
| **Custom Features** | ❌ Limited | **✅ Unlimited** | **Flexibility** |

**Total Savings: $120+ per year plus complete data control!**

## 🎯 Expected Results (v1.0.4)

### 📊 Dashboard Performance
- **📟 Device Detection**: 21 devices (1 PVS6 + 2 meters + 18 inverters)
- **⚡ Real-Time Data**: ~2.6 kW production during peak sunlight
- **🔄 Auto-Updates**: Dashboard refreshes every 30 seconds
- **📱 Mobile Ready**: Responsive design on all screen sizes
- **🌐 Offline Ready**: Operates 24/7 without internet connection

### 🎨 User Interface
- **5 Navigation Tabs**: Dashboard, Devices, Analytics, Database, System
- **Interactive Charts**: Chart.js visualizations with zoom and hover
- **Timezone Support**: Mountain Time (MDT/MST) by default
- **Debug Tools**: Built-in troubleshooting panel
- **Configuration**: Theme, update intervals, and settings management

### 📈 Data & Analytics
- **Historical Storage**: SQLite database with automatic indexing
- **Time Range Views**: Hour, day, week, month, year analytics
- **Device Monitoring**: Individual inverter and meter status
- **System Health**: CPU, memory, disk usage tracking
- **Data Export**: CSV export for external analysis

### 🔧 System Reliability
- **Auto-Restart**: Systemd service with automatic recovery
- **Error Handling**: Robust API timeouts and fallbacks
- **Network Recovery**: Automatic reconnection to PVS6
- **Data Integrity**: Continuous backup and validation

## 🤝 Community & Support

This project builds upon excellent work by:
- **[Scott Gruby](https://blog.gruby.com/2020/04/28/monitoring-a-sunpower-solar-system/)** - Original PVS6 API research
- **[Nelson Minar](https://nelsonslog.wordpress.com/2021/12/02/getting-local-access-to-sunpower-pvs6-data/)** - PVS6 documentation
- **[Community Contributors](docs/legal/ACKNOWLEDGMENTS.md)** - Various monitoring implementations

### 🔧 Troubleshooting & Maintenance

#### Quick Fixes
- **Dashboard not loading**: `sudo systemctl restart solar-monitor.service`
- **No data showing**: Check PVS6 connection: `ping 172.27.152.1`
- **Service status**: `sudo systemctl status solar-monitor.service solar-data-collector.service`
- **View logs**: `sudo journalctl -u solar-monitor.service -f`

#### Safe Deployment (Preserves Database)
```bash
# Download and run safe deployment script
cd /home/barry
wget http://YOUR_COMPUTER_IP:8009/simple_deploy.sh
chmod +x simple_deploy.sh
./simple_deploy.sh
```

#### Common Issues
- **"0 Active Devices"**: Fixed in v1.0.77+ with database fallback device counting
- **Charts showing 1 data point**: Caused by database truncation during deployment (use safe deployment)
- **PVS6 disconnected**: Check WiFi connection to SunPower network (172.27.152.1)
- **Timezone issues**: Set correct timezone: `sudo timedatectl set-timezone America/Denver`

#### Network Configuration
- **Pi WiFi (wlan0)**: Connected to SunPower PVS6 hotspot (172.27.152.1)
- **Pi Ethernet (eth0)**: Connected to home network for remote access
- **PVS6 API**: `http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList`

#### Version History
- **v1.0.56**: Last known stable before help system issues
- **v1.0.78**: Fixed device counting and collector status display  
- **v1.0.81**: Previous stable with auto-updating device breakdown
- **v1.0.89**: **🏆 CURRENT GOLDEN VERSION** - Consolidated menus, modern help system, JavaScript fixes

## ⚠️ Important Notes

### What This Is
- **Community-compiled** solution based on proven methods
- **One-command installation** for easy setup
- **Professional dashboard** with real-time monitoring
- **Cost-effective alternative** to paid services

### What This Isn't
- **Official SunPower software** (this is independent)
- **Warranty-voiding modification** (read-only monitoring)
- **Internet-dependent service** (works completely offline)

### Use Responsibly
- **Test thoroughly** before relying on it
- **Follow safety guidelines** when working with electrical equipment
- **Backup your data** regularly
- **Share your experience** to help the community

## 🎉 Success Stories

See **[SUCCESS_STORY.md](SUCCESS_STORY.md)** for real implementation results with screenshots and performance data!

---

**🌞 Ready to take control of your solar data? Get started with the one-command installation above!**
