#!/usr/bin/env python3
"""
Consolidate database tables and remove redundancy
"""

import sqlite3
from datetime import datetime

def consolidate_database_tables():
    """Consolidate redundant tables and clean up the database"""
    
    # Connect to Pi database
    conn = sqlite3.connect('/opt/solar_monitor/solar_data.db')
    cursor = conn.cursor()
    
    print("🔍 Analyzing current database structure...")
    
    # Check current record counts
    cursor.execute("SELECT COUNT(*) FROM system_status")
    system_status_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM solar_data")
    solar_data_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM solar_data_new")
    solar_data_new_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM device_data")
    device_data_count = cursor.fetchone()[0]
    
    print(f"📊 Current record counts:")
    print(f"   system_status: {system_status_count}")
    print(f"   solar_data: {solar_data_count}")
    print(f"   solar_data_new: {solar_data_new_count}")
    print(f"   device_data: {device_data_count}")
    
    # Step 1: Merge system_status data into solar_data (keep the more complete data)
    print("\n🔄 Merging system_status data into solar_data...")
    
    # Get system_status records that aren't already in solar_data
    cursor.execute("""
        INSERT INTO solar_data (timestamp, production_kw, consumption_kw, net_export_kw)
        SELECT timestamp, production_kw, consumption_kw, net_export_kw
        FROM system_status
        WHERE timestamp NOT IN (SELECT timestamp FROM solar_data)
    """)
    
    merged_count = cursor.rowcount
    print(f"✅ Merged {merged_count} additional records from system_status into solar_data")
    
    # Step 2: Drop redundant tables
    print("\n🗑️  Removing redundant tables...")
    
    # Drop solar_data_new (migration leftover)
    cursor.execute("DROP TABLE IF EXISTS solar_data_new")
    print(f"✅ Dropped solar_data_new table ({solar_data_new_count} records)")
    
    # Drop system_status (now redundant)
    cursor.execute("DROP TABLE IF EXISTS system_status")
    print(f"✅ Dropped system_status table ({system_status_count} records)")
    
    # Step 3: Clean up any sqlite metadata tables
    cursor.execute("DROP TABLE IF EXISTS sqlite_stat1")
    print("✅ Cleaned up sqlite metadata tables")
    
    # Step 4: Verify final structure
    print("\n📋 Final database structure:")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = cursor.fetchall()
    
    for table in tables:
        table_name = table[0]
        if table_name != 'sqlite_sequence':
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            print(f"   ✅ {table_name}: {count} records")
    
    # Step 5: Optimize database
    print("\n⚡ Optimizing database...")
    cursor.execute("VACUUM")
    cursor.execute("ANALYZE")
    
    conn.commit()
    conn.close()
    
    print("\n✅ Database consolidation complete!")

def update_data_collector():
    """Update data collector to only write to solar_data table"""
    
    print("\n🔧 Updating data collector to remove redundant writes...")
    
    with open('/opt/solar_monitor/simple_data_collector.py', 'r') as f:
        content = f.read()
    
    # Remove the system_status insert
    old_system_status_insert = '''        # Insert into system_status
        cursor.execute("""
            INSERT INTO system_status (timestamp, production_kw, consumption_kw, net_export_kw)
            VALUES (?, ?, ?, ?)
        """, (timestamp, production_kw, consumption_kw, net_export_kw))
        
        # Insert into solar_data for compatibility'''
    
    new_solar_data_insert = '''        # Insert into solar_data'''
    
    if old_system_status_insert in content:
        content = content.replace(old_system_status_insert, new_solar_data_insert)
        print("✅ Removed redundant system_status insert from data collector")
    
    # Also remove system_status table creation
    old_system_status_create = '''    # Create system_status table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS system_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            production_kw REAL DEFAULT 0,
            consumption_kw REAL DEFAULT 0,
            net_export_kw REAL DEFAULT 0,
            grid_frequency REAL DEFAULT 60.0,
            voltage REAL DEFAULT 240.0
        )
    """)
    
    # Create solar_data table with device_id column'''
    
    new_solar_data_create = '''    # Create solar_data table with device_id column'''
    
    if old_system_status_create in content:
        content = content.replace(old_system_status_create, new_solar_data_create)
        print("✅ Removed system_status table creation from data collector")
    
    with open('/opt/solar_monitor/simple_data_collector.py', 'w') as f:
        f.write(content)
    
    print("✅ Data collector updated to use only solar_data table")

if __name__ == '__main__':
    print("🗃️  Consolidating Database Tables")
    print("=" * 50)
    
    consolidate_database_tables()
    update_data_collector()
    
    print("\n🎉 Database consolidation complete!")
    print("📊 Final structure:")
    print("   ✅ solar_data: System-level production/consumption time-series")
    print("   ✅ device_data: Individual inverter time-series data")
    print("   ❌ Removed: system_status (redundant)")
    print("   ❌ Removed: solar_data_new (migration leftover)")
    print("\n💾 Database optimized and data collector updated")
