#!/bin/bash

echo "🔧 DEPLOYING PVS CLIENT FIX TO RASPBERRY PI"
echo "=============================================="

PI_IP="192.168.1.126"
PI_USER="barry"

echo "📦 Creating deployment package..."
tar -czf fix_pvs_client_complete.tar.gz fix_pvs_client_complete.py

echo "📡 Uploading fix to Pi..."
scp fix_pvs_client_complete.tar.gz ${PI_USER}@${PI_IP}:~/

echo "🚀 Executing fix on Pi..."
ssh ${PI_USER}@${PI_IP} << 'EOF'
    echo "📦 Extracting fix..."
    tar -xzf fix_pvs_client_complete.tar.gz
    
    echo "🔄 Backing up current pvs_client.py..."
    sudo cp /home/barry/solar_monitor/src/pvs_client.py /home/barry/solar_monitor/src/pvs_client.py.backup
    
    echo "✅ Installing fixed pvs_client.py..."
    sudo cp fix_pvs_client_complete.py /home/barry/solar_monitor/src/pvs_client.py
    
    echo "🔄 Restarting Solar Monitor service..."
    sudo systemctl restart solar-monitor.service
    
    echo "⏳ Waiting for service to start..."
    sleep 5
    
    echo "📊 Checking service status..."
    sudo systemctl status solar-monitor.service --no-pager -l
    
    echo "🧪 Testing API..."
    curl -s http://192.168.1.126:5000/api/current_status | head -10
    
    echo "📋 Checking recent logs..."
    sudo journalctl -u solar-monitor.service --lines=10 --no-pager
EOF

echo ""
echo "✅ PVS CLIENT FIX DEPLOYMENT COMPLETE!"
echo "🌐 Test the dashboard: http://192.168.1.126:5000"
echo "📊 Test the API: curl http://192.168.1.126:5000/api/current_status"
