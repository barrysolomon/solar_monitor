#!/bin/bash
# Solar Monitor v1.0.0 - Complete Pi Deployment Script
# This script deploys the solar monitor to a Raspberry Pi

set -e  # Exit on any error

echo "🚀 SOLAR MONITOR v1.0.0 - RASPBERRY PI DEPLOYMENT"
echo "================================================="
echo ""

# Configuration
PI_USER="barry"
PI_HOST=""
PROJECT_NAME="solar_monitor"
SERVICE_NAME="solar-monitor"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Get Pi IP address
if [ -z "$1" ]; then
    echo "Usage: $0 <pi_ip_address>"
    echo "Example: $0 192.168.1.100"
    echo ""
    echo "To find your Pi's IP address:"
    echo "  nmap -sn 192.168.1.0/24 | grep -B2 'Raspberry Pi'"
    echo "  or check your router's admin panel"
    exit 1
fi

PI_HOST="$1"

print_status "Deploying to Pi at $PI_HOST"

# Test SSH connection
print_status "Testing SSH connection to Pi..."
if ! ssh -o ConnectTimeout=10 -o BatchMode=yes "$PI_USER@$PI_HOST" exit 2>/dev/null; then
    print_error "Cannot connect to Pi via SSH"
    echo "Please ensure:"
    echo "  1. Pi is powered on and connected to network"
    echo "  2. SSH is enabled on the Pi"
    echo "  3. Username is '$PI_USER' (or modify this script)"
    echo "  4. SSH keys are set up or password authentication is enabled"
    exit 1
fi
print_success "SSH connection successful"

# Create deployment package
print_status "Creating deployment package..."
TEMP_DIR=$(mktemp -d)
PACKAGE_DIR="$TEMP_DIR/$PROJECT_NAME"

mkdir -p "$PACKAGE_DIR"

# Copy essential files
cp -r src "$PACKAGE_DIR/"
cp -r templates "$PACKAGE_DIR/"
cp requirements.txt "$PACKAGE_DIR/"
cp install.sh "$PACKAGE_DIR/"
cp start.sh "$PACKAGE_DIR/"

# Create Pi-specific deployment script
cat > "$PACKAGE_DIR/deploy_on_pi.sh" << 'DEPLOY_SCRIPT'
#!/bin/bash
# Solar Monitor Pi Installation Script
set -e

echo "🔧 INSTALLING SOLAR MONITOR ON RASPBERRY PI"
echo "==========================================="

# Update system
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python and pip if not present
echo "🐍 Installing Python dependencies..."
sudo apt install -y python3 python3-pip python3-venv git

# Create project directory
PROJECT_DIR="$HOME/solar_monitor"
echo "📁 Setting up project directory: $PROJECT_DIR"

# Backup existing installation if present
if [ -d "$PROJECT_DIR" ]; then
    BACKUP_DIR="$HOME/solar_monitor_backup_$(date +%Y%m%d_%H%M%S)"
    echo "💾 Backing up existing installation to $BACKUP_DIR"
    mv "$PROJECT_DIR" "$BACKUP_DIR"
fi

mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

# Copy files from deployment package
echo "📋 Copying application files..."
cp -r ../solar_monitor_deploy/* .

# Create virtual environment
echo "🌐 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📦 Installing Python packages..."
pip install --upgrade pip
pip install -r requirements.txt

# Create systemd service file
echo "⚙️ Creating systemd service..."
sudo tee /etc/systemd/system/solar-monitor.service > /dev/null << EOF
[Unit]
Description=Solar Monitor Service
After=network.target
Wants=network.target

[Service]
Type=simple
User=$USER
Group=$USER
WorkingDirectory=$PROJECT_DIR/src
Environment=PATH=$PROJECT_DIR/venv/bin
ExecStart=$PROJECT_DIR/venv/bin/python solar_monitor.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Set permissions
chmod +x src/solar_monitor.py
chmod +x start.sh

# Enable and start service
echo "🚀 Enabling and starting service..."
sudo systemctl daemon-reload
sudo systemctl enable solar-monitor.service

# Test PVS connection before starting service
echo "🔍 Testing PVS connection..."
cd src
if python3 solar_monitor.py --test-connection; then
    echo "✅ PVS connection successful!"
    
    # Start the service
    sudo systemctl start solar-monitor.service
    
    # Wait a moment for service to start
    sleep 5
    
    # Check service status
    if sudo systemctl is-active --quiet solar-monitor.service; then
        echo ""
        echo "🎉 SOLAR MONITOR INSTALLATION COMPLETE!"
        echo "======================================"
        echo ""
        echo "✅ Service Status: RUNNING"
        echo "🌐 Dashboard URL: http://$(hostname -I | awk '{print $1}'):5000"
        echo ""
        echo "📊 Features Available:"
        echo "  • Real-time solar monitoring"
        echo "  • Historical data analytics"
        echo "  • Device status management"
        echo "  • Professional dashboard"
        echo "  • Automatic data collection"
        echo ""
        echo "🔧 Service Management:"
        echo "  • Check status: sudo systemctl status solar-monitor.service"
        echo "  • View logs: sudo journalctl -u solar-monitor.service -f"
        echo "  • Restart: sudo systemctl restart solar-monitor.service"
        echo ""
        echo "🎯 Next Steps:"
        echo "  1. Open http://$(hostname -I | awk '{print $1}'):5000 in your browser"
        echo "  2. Verify data is being collected"
        echo "  3. Check all devices are detected"
        echo ""
    else
        echo "❌ Service failed to start. Check logs:"
        sudo journalctl -u solar-monitor.service -n 20
    fi
else
    echo "❌ PVS connection failed!"
    echo ""
    echo "🔧 Troubleshooting Steps:"
    echo "  1. Check network connection to PVS6"
    echo "  2. Verify PVS6 is accessible at 172.27.152.1"
    echo "  3. Try: ping 172.27.152.1"
    echo "  4. Check PVS6 WiFi hotspot or Ethernet connection"
    echo ""
    echo "📖 See RASPBERRY_PI_SETUP.md for detailed network setup"
fi

echo ""
echo "🏁 Installation script completed!"
DEPLOY_SCRIPT

chmod +x "$PACKAGE_DIR/deploy_on_pi.sh"

# Create archive
print_status "Creating deployment archive..."
cd "$TEMP_DIR"
tar -czf solar_monitor_deploy.tar.gz "$PROJECT_NAME"

# Transfer to Pi
print_status "Transferring files to Pi..."
scp solar_monitor_deploy.tar.gz "$PI_USER@$PI_HOST:~/"

# Extract and run deployment on Pi
print_status "Running deployment on Pi..."
ssh "$PI_USER@$PI_HOST" << 'REMOTE_COMMANDS'
echo "📦 Extracting deployment package..."
tar -xzf solar_monitor_deploy.tar.gz
mv solar_monitor solar_monitor_deploy

echo "🚀 Running installation script..."
cd solar_monitor_deploy
chmod +x deploy_on_pi.sh
./deploy_on_pi.sh
REMOTE_COMMANDS

# Cleanup
rm -rf "$TEMP_DIR"

print_success "Deployment completed!"
echo ""
echo "🎉 SOLAR MONITOR DEPLOYED TO RASPBERRY PI"
echo "========================================"
echo ""
echo "📍 Pi Address: $PI_HOST"
echo "🌐 Dashboard: http://$PI_HOST:5000"
echo ""
echo "🔧 Remote Management Commands:"
echo "  ssh $PI_USER@$PI_HOST 'sudo systemctl status solar-monitor.service'"
echo "  ssh $PI_USER@$PI_HOST 'sudo journalctl -u solar-monitor.service -f'"
echo "  ssh $PI_USER@$PI_HOST 'sudo systemctl restart solar-monitor.service'"
echo ""
echo "✅ Your solar monitor should now be running!"
echo "Open http://$PI_HOST:5000 in your browser to access the dashboard."
