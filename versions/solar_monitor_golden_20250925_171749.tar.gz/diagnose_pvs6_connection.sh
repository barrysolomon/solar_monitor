#!/bin/bash
echo "🔍 PVS6 Connection Diagnostics"
echo "============================="
echo ""

echo "📅 Current Pi Time:"
date
echo ""

echo "🔧 Service Status:"
sudo systemctl status solar-data-collector.service --no-pager -l
echo ""

echo "📋 Recent Data Collector Logs:"
sudo journalctl -u solar-data-collector.service --since '10 minutes ago' -n 15 --no-pager
echo ""

echo "🌐 Network Connectivity:"
echo "Checking if Pi can reach PVS6..."
ping -c 3 192.168.1.201 2>/dev/null || echo "❌ Cannot reach PVS6 at 192.168.1.201"
echo ""

echo "📡 WiFi Status:"
iwconfig wlan0 2>/dev/null | grep -E "(ESSID|Access Point)" || echo "❌ WiFi not connected"
echo ""

echo "🔌 Network Interfaces:"
ip addr show | grep -E "(wlan0|eth0)" -A 2
echo ""

echo "🧪 Test PVS6 API Call:"
curl -s --connect-timeout 5 "http://192.168.1.201/cgi-bin/dl_cgi?Command=DeviceList" | head -c 200 || echo "❌ PVS6 API not responding"
echo ""
echo ""

echo "💡 Next Steps:"
echo "1. If PVS6 ping fails: Check WiFi connection to SunPower network"
echo "2. If API call fails: PVS6 may be in sleep mode or offline"
echo "3. Check service logs for specific error messages"