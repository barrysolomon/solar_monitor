#!/usr/bin/env python3
"""
Isolated Status API Module - Safe to test independently
"""
from flask import Flask, jsonify
import subprocess

# Create isolated Flask app for testing
test_app = Flask(__name__)

@test_app.route('/api/system/collector-status')
def collector_status():
    """Get data collector service status - ISOLATED"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'solar-data-collector.service'],
            capture_output=True, text=True, timeout=5
        )
        is_running = result.returncode == 0 and result.stdout.strip() == 'active'
        return jsonify({
            'status': 'running' if is_running else 'stopped',
            'success': is_running,
            'service': 'solar-data-collector',
            'module': 'isolated'
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'success': False,
            'error': str(e),
            'module': 'isolated'
        })

@test_app.route('/api/system/pvs6-status')  
def pvs6_status():
    """Get PVS6 connectivity status - ISOLATED"""
    try:
        result = subprocess.run(
            ['ping', '-c', '1', '-W', '2', '172.27.152.1'],
            capture_output=True, timeout=3
        )
        online = result.returncode == 0
        return jsonify({
            'pvs_online': online,
            'success': True,
            'target': '172.27.152.1',
            'module': 'isolated'
        })
    except Exception as e:
        return jsonify({
            'pvs_online': False,
            'success': False,
            'error': str(e),
            'module': 'isolated'
        })

def add_routes_to_main_app(main_app):
    """Safely add routes to main app without breaking it"""
    try:
        # Add collector status route
        @main_app.route('/api/system/collector-status')
        def main_collector_status():
            return collector_status().get_data(), collector_status().status_code
        
        # Add PVS6 status route  
        @main_app.route('/api/system/pvs6-status')
        def main_pvs6_status():
            return pvs6_status().get_data(), pvs6_status().status_code
            
        return True
    except Exception as e:
        print(f"Failed to add routes: {e}")
        return False

if __name__ == '__main__':
    # Test the isolated module
    print("Testing isolated status API module...")
    test_app.run(host='127.0.0.1', port=5001, debug=True)
