#!/usr/bin/env python3
"""
Check database status on the Pi via API calls
"""
import requests
import json
from datetime import datetime, timedelta

PI_IP = "192.168.1.126"
PI_PORT = "5000"

def check_database_status():
    """Check if the Pi is storing data in the database"""
    print("🔍 Checking Solar Monitor Database Status")
    print("=" * 50)
    
    try:
        # Check current status
        print("📊 Current Status API:")
        response = requests.get(f"http://{PI_IP}:{PI_PORT}/api/current_status", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"  ✅ API responding")
            print(f"  📡 PVS Online: {data.get('pvs_online', False)}")
            print(f"  🔧 System Online: {data.get('system_online', False)}")
            print(f"  📱 Device Count: {data.get('device_count', 0)}")
            print(f"  ⚡ Production: {data.get('total_production_kw', 0)} kW")
        else:
            print(f"  ❌ API error: {response.status_code}")
            
        print()
        
        # Check historical data
        print("📈 Historical Data API:")
        response = requests.get(f"http://{PI_IP}:{PI_PORT}/api/historical_data?hours=1", timeout=10)
        if response.status_code == 200:
            data = response.json()
            count = data.get('count', 0)
            print(f"  📊 Data Points (1 hour): {count}")
            
            if count > 0:
                print(f"  ✅ Database is storing data!")
                # Show sample data
                sample_data = data.get('data', [])[:3]
                for i, point in enumerate(sample_data):
                    print(f"    {i+1}. {point.get('timestamp', 'N/A')} - {point.get('device_type', 'N/A')} - {point.get('power_kw', 0)} kW")
            else:
                print(f"  ❌ No historical data found")
                if 'error' in data:
                    print(f"  🚨 Error: {data['error']}")
        else:
            print(f"  ❌ Historical API error: {response.status_code}")
            
        print()
        
        # Check different time ranges
        for hours in [6, 24, 168]:  # 6 hours, 1 day, 1 week
            print(f"📊 Historical Data ({hours} hours):")
            response = requests.get(f"http://{PI_IP}:{PI_PORT}/api/historical_data?hours={hours}", timeout=10)
            if response.status_code == 200:
                data = response.json()
                count = data.get('count', 0)
                print(f"  📈 Data Points: {count}")
                
                if count > 0:
                    # Calculate expected data points (assuming 30-second intervals)
                    expected_points = (hours * 60 * 60) / 30  # 30-second intervals
                    coverage = (count / expected_points) * 100 if expected_points > 0 else 0
                    print(f"  📊 Coverage: {coverage:.1f}% (expected ~{expected_points:.0f} points)")
                    
                    # Show time range
                    data_points = data.get('data', [])
                    if data_points:
                        first_time = data_points[0].get('timestamp', 'N/A')
                        last_time = data_points[-1].get('timestamp', 'N/A')
                        print(f"  ⏰ Range: {first_time} to {last_time}")
            else:
                print(f"  ❌ API error: {response.status_code}")
            print()
            
        # Diagnosis
        print("🔍 DIAGNOSIS:")
        response = requests.get(f"http://{PI_IP}:{PI_PORT}/api/historical_data?hours=24", timeout=10)
        if response.status_code == 200:
            data = response.json()
            count = data.get('count', 0)
            
            if count == 0:
                print("  ❌ ISSUE: No historical data is being stored")
                print("  🔧 LIKELY CAUSES:")
                print("    1. Data collector thread is not running")
                print("    2. Database write permissions issue")
                print("    3. Data collector is crashing silently")
                print("    4. PVS connection failing during data collection")
                print()
                print("  🛠️ RECOMMENDED FIXES:")
                print("    1. Restart the solar-monitor service")
                print("    2. Check service logs for errors")
                print("    3. Verify database file permissions")
                print("    4. Test data collection manually")
            elif count < 100:  # Less than expected for 24 hours
                print("  ⚠️ ISSUE: Limited historical data (data collection may be intermittent)")
                print("  🔧 POSSIBLE CAUSES:")
                print("    1. Recent deployment (data collection just started)")
                print("    2. Intermittent PVS connection issues")
                print("    3. Service restarts clearing data")
            else:
                print("  ✅ Historical data collection appears to be working normally")
        
    except Exception as e:
        print(f"❌ Error checking database status: {e}")

if __name__ == "__main__":
    check_database_status()
