"""
Enhanced Solar Monitor Web Dashboard with Cached Data System
Uses last collected data when PVS6 is unreachable, with data freshness indicators
"""
import os
import sys
import sqlite3
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
import requests
from typing import List, Dict, Optional

# Add the src directory to Python path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

try:
    from pvs_client import PVSClient
    from database import SolarDatabase
    import config
except ImportError as e:
    print(f"Import error: {e}")
    print("Make sure you're running from the project root directory")
    sys.exit(1)

app = Flask(__name__, template_folder='templates')

# Global instances
pvs_client = PVSClient()
solar_db = SolarDatabase()

# Cache for last successful data
_last_device_data = None
_last_system_summary = None
_last_successful_fetch = None
_cache_duration_minutes = 10  # Consider data stale after 10 minutes

def get_cached_or_live_data(force_refresh=False):
    """
    Get device data from PVS6 or return cached data if PVS6 is unreachable
    Returns: (devices, system_summary, data_source, last_fetch_time, is_stale)
    """
    global _last_device_data, _last_system_summary, _last_successful_fetch
    
    now = datetime.now()
    
    # Check if we should use cache (unless force refresh)
    if not force_refresh and _last_device_data and _last_successful_fetch:
        cache_age = (now - _last_successful_fetch).total_seconds() / 60  # minutes
        if cache_age < 2:  # Use cache if less than 2 minutes old for performance
            is_stale = cache_age > _cache_duration_minutes
            return _last_device_data, _last_system_summary, 'CACHED_RECENT', _last_successful_fetch, is_stale
    
    # Try to fetch live data
    try:
        if pvs_client.test_connection():
            devices = pvs_client.get_device_list()
            system_summary = pvs_client.get_system_summary()
            
            if devices and system_summary:
                # Update cache
                _last_device_data = devices
                _last_system_summary = system_summary
                _last_successful_fetch = now
                
                return devices, system_summary, 'LIVE_PVS', now, False
    except Exception as e:
        print(f"Error fetching live data: {e}")
    
    # Fall back to cached data if available
    if _last_device_data and _last_system_summary and _last_successful_fetch:
        cache_age = (now - _last_successful_fetch).total_seconds() / 60  # minutes
        is_stale = cache_age > _cache_duration_minutes
        data_source = 'CACHED_STALE' if is_stale else 'CACHED_FRESH'
        return _last_device_data, _last_system_summary, data_source, _last_successful_fetch, is_stale
    
    # No data available
    return None, None, 'NO_DATA', None, True

def get_latest_database_summary():
    """Get the most recent data from the database as fallback"""
    try:
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Get latest system status
            cursor.execute("""
                SELECT * FROM system_status 
                ORDER BY timestamp DESC LIMIT 1
            """)
            system_row = cursor.fetchone()
            
            # Get device counts by type
            cursor.execute("""
                SELECT device_type, COUNT(DISTINCT device_id) as count
                FROM solar_data 
                WHERE timestamp > datetime('now', '-1 hour')
                GROUP BY device_type
            """)
            device_counts = dict(cursor.fetchall())
            
            if system_row:
                return {
                    'timestamp': system_row[1],
                    'total_production_kw': system_row[2] or 0,
                    'total_consumption_kw': system_row[3] or 0,
                    'net_export_kw': system_row[4] or 0,
                    'device_counts': device_counts,
                    'source': 'DATABASE'
                }
    except Exception as e:
        print(f"Error getting database summary: {e}")
    
    return None

# ============================================================================
# MAIN DASHBOARD ROUTES
# ============================================================================

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/current_status')
def current_status():
    """Get current system status with caching and freshness indicators"""
    try:
        force_refresh = request.args.get('force', 'false').lower() == 'true'
        
        devices, system_summary, data_source, last_fetch, is_stale = get_cached_or_live_data(force_refresh)
        
        if devices and system_summary:
            # Calculate freshness
            freshness_minutes = 0
            if last_fetch:
                freshness_minutes = (datetime.now() - last_fetch).total_seconds() / 60
            
            response = {
                'api_status': 'success',
                'pvs_online': data_source.startswith('LIVE'),
                'system_online': True,
                'device_count': len(devices),
                'total_production_kw': system_summary.get('total_production_kw', 0.0),
                'total_consumption_kw': system_summary.get('total_consumption_kw', 0.0),
                'net_export_kw': system_summary.get('net_export_kw', 0.0),
                'timestamp': datetime.now().isoformat(),
                'data_source': data_source,
                'last_pvs_fetch': last_fetch.isoformat() if last_fetch else None,
                'data_age_minutes': round(freshness_minutes, 1),
                'is_stale': is_stale,
                'cache_duration_minutes': _cache_duration_minutes
            }
            
            return jsonify(response)
        
        # Try database fallback
        db_summary = get_latest_database_summary()
        if db_summary:
            device_count = sum(db_summary['device_counts'].values())
            freshness_minutes = (datetime.now() - datetime.fromisoformat(db_summary['timestamp'])).total_seconds() / 60
            
            return jsonify({
                'api_status': 'success',
                'pvs_online': False,
                'system_online': True,
                'device_count': device_count,
                'total_production_kw': db_summary['total_production_kw'],
                'total_consumption_kw': db_summary['total_consumption_kw'],
                'net_export_kw': db_summary['net_export_kw'],
                'timestamp': datetime.now().isoformat(),
                'data_source': 'DATABASE_FALLBACK',
                'last_pvs_fetch': db_summary['timestamp'],
                'data_age_minutes': round(freshness_minutes, 1),
                'is_stale': freshness_minutes > _cache_duration_minutes,
                'cache_duration_minutes': _cache_duration_minutes
            })
        
        # No data available at all
        return jsonify({
            'api_status': 'error',
            'error': 'No data available - PVS6 unreachable and no cached/database data',
            'pvs_online': False,
            'system_online': False,
            'device_count': 0,
            'total_production_kw': 0.0,
            'total_consumption_kw': 0.0,
            'net_export_kw': 0.0,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'NO_DATA',
            'last_pvs_fetch': None,
            'data_age_minutes': None,
            'is_stale': True,
            'cache_duration_minutes': _cache_duration_minutes
        }), 503
        
    except Exception as e:
        print(f"❌ API Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'pvs_online': False,
            'system_online': False,
            'device_count': 0,
            'total_production_kw': 0.0,
            'total_consumption_kw': 0.0,
            'net_export_kw': 0.0,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'ERROR',
            'last_pvs_fetch': None,
            'data_age_minutes': None,
            'is_stale': True,
            'cache_duration_minutes': _cache_duration_minutes
        }), 500

@app.route('/api/device_details')
def device_details():
    """Get detailed device information with caching"""
    try:
        force_refresh = request.args.get('force', 'false').lower() == 'true'
        
        devices, _, data_source, last_fetch, is_stale = get_cached_or_live_data(force_refresh)
        
        if devices:
            # Process devices for frontend
            processed_devices = []
            for device in devices:
                try:
                    parsed_device = pvs_client.parse_device_data(device)
                    processed_devices.append(parsed_device)
                except Exception as e:
                    print(f"Error parsing device {device.get('DeviceID', 'unknown')}: {e}")
                    # Add raw device data as fallback
                    processed_devices.append({
                        'device_id': device.get('DeviceID', 'Unknown'),
                        'device_type': device.get('DeviceType', 'Unknown'),
                        'serial': device.get('DeviceID', 'Unknown'),
                        'status': 'unknown',
                        'power_kw': 0.0,
                        'energy_kwh': 0.0,
                        'voltage': 0.0,
                        'current': 0.0,
                        'raw_data': json.dumps(device)
                    })

            freshness_minutes = 0
            if last_fetch:
                freshness_minutes = (datetime.now() - last_fetch).total_seconds() / 60

            response = {
                'api_status': 'success',
                'devices': processed_devices,
                'device_count': len(processed_devices),
                'pvs_online': data_source.startswith('LIVE'),
                'timestamp': datetime.now().isoformat(),
                'data_source': data_source,
                'last_pvs_fetch': last_fetch.isoformat() if last_fetch else None,
                'data_age_minutes': round(freshness_minutes, 1),
                'is_stale': is_stale
            }
            
            return jsonify(response)
        
        # No device data available
        return jsonify({
            'api_status': 'error',
            'error': 'No device data available',
            'devices': [],
            'device_count': 0,
            'pvs_online': False,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'NO_DATA',
            'last_pvs_fetch': None,
            'data_age_minutes': None,
            'is_stale': True
        }), 503
        
    except Exception as e:
        print(f"❌ Device Details Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'devices': [],
            'device_count': 0,
            'pvs_online': False,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'ERROR',
            'last_pvs_fetch': None,
            'data_age_minutes': None,
            'is_stale': True
        }), 500

@app.route('/api/force_refresh', methods=['POST'])
def force_refresh():
    """Force refresh data from PVS6"""
    try:
        devices, system_summary, data_source, last_fetch, is_stale = get_cached_or_live_data(force_refresh=True)
        
        if data_source.startswith('LIVE'):
            return jsonify({
                'success': True,
                'message': 'Data refreshed successfully from PVS6',
                'data_source': data_source,
                'last_fetch': last_fetch.isoformat() if last_fetch else None,
                'device_count': len(devices) if devices else 0
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Could not connect to PVS6 for refresh',
                'data_source': data_source,
                'last_fetch': last_fetch.isoformat() if last_fetch else None
            }), 503
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error during refresh: {str(e)}',
            'data_source': 'ERROR'
        }), 500

@app.route('/api/cache_status')
def cache_status():
    """Get current cache status and configuration"""
    global _last_successful_fetch, _cache_duration_minutes
    
    now = datetime.now()
    cache_age_minutes = None
    
    if _last_successful_fetch:
        cache_age_minutes = (now - _last_successful_fetch).total_seconds() / 60
    
    return jsonify({
        'cache_enabled': True,
        'cache_duration_minutes': _cache_duration_minutes,
        'last_successful_fetch': _last_successful_fetch.isoformat() if _last_successful_fetch else None,
        'cache_age_minutes': round(cache_age_minutes, 1) if cache_age_minutes else None,
        'has_cached_data': _last_device_data is not None,
        'is_stale': cache_age_minutes > _cache_duration_minutes if cache_age_minutes else True
    })

# ============================================================================
# EXISTING DATABASE APIs (from previous enhancement)
# ============================================================================

@app.route('/api/db/status')
def database_status():
    """Get comprehensive database status and health information"""
    try:
        db_path = config.DATABASE_PATH
        
        # Check if database file exists
        db_exists = os.path.exists(db_path)
        if not db_exists:
            return jsonify({
                'status': 'error',
                'error': 'Database file does not exist',
                'db_path': db_path,
                'exists': False
            }), 404
            
        # Get database file info
        db_stat = os.stat(db_path)
        db_size = db_stat.st_size
        db_modified = datetime.fromtimestamp(db_stat.st_mtime).isoformat()
        
        # Connect to database and get table info
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Get table information
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # Get record counts for each table
            table_info = {}
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                
                # Get latest record timestamp if applicable
                latest_timestamp = None
                if table in ['solar_data', 'system_status']:
                    try:
                        cursor.execute(f"SELECT MAX(timestamp) FROM {table}")
                        latest_result = cursor.fetchone()
                        if latest_result and latest_result[0]:
                            latest_timestamp = latest_result[0]
                    except:
                        pass
                
                table_info[table] = {
                    'record_count': count,
                    'latest_timestamp': latest_timestamp
                }
            
            # Get recent data collection activity (last hour)
            cursor.execute("""
                SELECT COUNT(*) FROM solar_data 
                WHERE timestamp > datetime('now', '-1 hour')
            """)
            recent_records = cursor.fetchone()[0]
            
            # Calculate data collection rate
            cursor.execute("""
                SELECT MIN(timestamp), MAX(timestamp), COUNT(*) 
                FROM solar_data 
                WHERE timestamp > datetime('now', '-24 hours')
            """)
            rate_result = cursor.fetchone()
            
            collection_rate = 0
            if rate_result and rate_result[0] and rate_result[1] and rate_result[2]:
                start_time = datetime.fromisoformat(rate_result[0])
                end_time = datetime.fromisoformat(rate_result[1])
                duration_hours = (end_time - start_time).total_seconds() / 3600
                if duration_hours > 0:
                    collection_rate = rate_result[2] / duration_hours
        
        return jsonify({
            'status': 'success',
            'database': {
                'path': db_path,
                'exists': True,
                'size_bytes': db_size,
                'size_mb': round(db_size / (1024 * 1024), 2),
                'last_modified': db_modified
            },
            'tables': table_info,
            'activity': {
                'recent_records_1h': recent_records,
                'collection_rate_per_hour': round(collection_rate, 1),
                'is_collecting': recent_records > 0
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/db/recent_data')
def recent_database_data():
    """Get recent data from the database with flexible filtering"""
    try:
        # Parameters
        table = request.args.get('table', 'solar_data')
        hours = int(request.args.get('hours', 1))
        limit = int(request.args.get('limit', 100))
        device_type = request.args.get('device_type', None)
        device_id = request.args.get('device_id', None)
        
        # Validate table name for security
        valid_tables = ['solar_data', 'system_status']
        if table not in valid_tables:
            return jsonify({
                'status': 'error',
                'error': f'Invalid table. Must be one of: {valid_tables}'
            }), 400
        
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Build query based on table and filters
            if table == 'solar_data':
                query = """
                    SELECT * FROM solar_data 
                    WHERE timestamp > datetime('now', '-{} hours')
                """.format(hours)
                
                params = []
                if device_type:
                    query += " AND device_type = ?"
                    params.append(device_type)
                    
                if device_id:
                    query += " AND device_id = ?"
                    params.append(device_id)
                    
                query += " ORDER BY timestamp DESC LIMIT ?"
                params.append(limit)
                
            else:  # system_status
                query = """
                    SELECT * FROM system_status 
                    WHERE timestamp > datetime('now', '-{} hours')
                    ORDER BY timestamp DESC LIMIT ?
                """.format(hours)
                params = [limit]
            
            cursor.execute(query, params)
            columns = [description[0] for description in cursor.description]
            rows = cursor.fetchall()
            
            # Convert to list of dictionaries
            results = []
            for row in rows:
                results.append(dict(zip(columns, row)))
        
        return jsonify({
            'status': 'success',
            'table': table,
            'filters': {
                'hours': hours,
                'limit': limit,
                'device_type': device_type,
                'device_id': device_id
            },
            'results': results,
            'count': len(results),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/collector/status')
def collector_status():
    """Get data collector status and health"""
    try:
        # Check if data collection is active by looking at recent database activity
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Check for recent data (last 5 minutes)
            cursor.execute("""
                SELECT COUNT(*) FROM solar_data 
                WHERE timestamp > datetime('now', '-5 minutes')
            """)
            recent_count = cursor.fetchone()[0]
            
            # Get latest record
            cursor.execute("""
                SELECT MAX(timestamp) FROM solar_data
            """)
            latest_timestamp = cursor.fetchone()[0]
            
            # Calculate time since last collection
            time_since_last = None
            if latest_timestamp:
                latest_dt = datetime.fromisoformat(latest_timestamp)
                time_since_last = (datetime.now() - latest_dt).total_seconds()
        
        # Test PVS connection
        pvs_online = pvs_client.test_connection()
        
        # Determine collector status
        is_collecting = recent_count > 0
        is_healthy = is_collecting and pvs_online and (time_since_last is None or time_since_last < 300)  # 5 minutes
        
        return jsonify({
            'status': 'success',
            'collector': {
                'is_collecting': is_collecting,
                'is_healthy': is_healthy,
                'recent_records_5min': recent_count,
                'latest_collection': latest_timestamp,
                'seconds_since_last': round(time_since_last) if time_since_last else None,
                'pvs_online': pvs_online,
                'poll_interval': config.POLL_INTERVAL_SECONDS
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

# ============================================================================
# ENHANCED HISTORICAL DATA API
# ============================================================================

@app.route('/api/historical_data')
def historical_data():
    """Get historical data for analysis (enhanced with better error handling)"""
    try:
        hours = int(request.args.get('hours', 24))
        
        # Try to get data from database
        try:
            data = solar_db.get_latest_data(hours=hours)
        except Exception as db_error:
            return jsonify({
                'data': [],
                'count': 0,
                'hours': hours,
                'error': f'Database error: {str(db_error)}',
                'suggestion': 'Check if data collection is running with /api/collector/status'
            }), 500
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'hours': hours,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'hours': hours if 'hours' in locals() else 24,
            'error': str(e),
            'status': 'error'
        }), 500

if __name__ == '__main__':
    print("🚀 Starting Enhanced Solar Monitor Dashboard with Cached Data")
    print("=" * 70)
    print(f"📊 Dashboard: http://0.0.0.0:5000")
    print(f"🗄️  Database APIs:")
    print(f"   Status: http://0.0.0.0:5000/api/db/status")
    print(f"   Recent: http://0.0.0.0:5000/api/db/recent_data?hours=1")
    print(f"🔧 Collector APIs:")
    print(f"   Status: http://0.0.0.0:5000/api/collector/status")
    print(f"💾 Cached Data APIs:")
    print(f"   Current Status: http://0.0.0.0:5000/api/current_status")
    print(f"   Force Refresh: http://0.0.0.0:5000/api/force_refresh (POST)")
    print(f"   Cache Status: http://0.0.0.0:5000/api/cache_status")
    print("=" * 70)
    
    app.run(host='0.0.0.0', port=5000, debug=False)
