#!/bin/bash
echo "🧪 Testing PVS6 API Responses"
echo "============================="
echo ""

echo "📋 Device List API:"
echo "curl 'http://192.168.1.201/cgi-bin/dl_cgi?Command=DeviceList'"
curl -s "http://192.168.1.201/cgi-bin/dl_cgi?Command=DeviceList" | head -c 500
echo ""
echo ""

echo "📊 System Summary API:"
echo "curl 'http://192.168.1.201/cgi-bin/dl_cgi?Command=SystemSummary'"
curl -s "http://192.168.1.201/cgi-bin/dl_cgi?Command=SystemSummary" | head -c 500
echo ""
echo ""

echo "⚡ Production Data API:"
echo "curl 'http://192.168.1.201/cgi-bin/dl_cgi?Command=ProductionData'"
curl -s "http://192.168.1.201/cgi-bin/dl_cgi?Command=ProductionData" | head -c 500
echo ""
echo ""

echo "🔍 Check if APIs are returning actual data or empty responses"
