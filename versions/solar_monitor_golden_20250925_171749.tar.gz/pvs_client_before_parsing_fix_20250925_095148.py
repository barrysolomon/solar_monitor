#!/usr/bin/env python3
"""
PVS Client - Fixed to properly read real device states
No fake data - uses actual PVS STATE and STATEDESCR fields
"""

import requests
import json
from datetime import datetime
from typing import Dict, List, Optional

class PVSClient:
    def __init__(self, pvs_ip='172.27.152.1', pvs_port=80):
        self.pvs_ip = pvs_ip
        self.pvs_port = pvs_port
        self.base_url = f"http://{pvs_ip}:{pvs_port}"
        
    def test_connection(self) -> bool:
        """Test connection to PVS"""
        try:
            response = requests.get(f"{self.base_url}/cgi-bin/dl_cgi?Command=DeviceList", timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def get_device_list(self) -> Optional[List[Dict]]:
        """Get list of all devices from PVS - REAL DATA ONLY"""
        try:
            response = requests.get(f"{self.base_url}/cgi-bin/dl_cgi?Command=DeviceList", timeout=10)
            response.raise_for_status()
            
            data = response.json()
            if 'devices' in data:
                print(f"✅ Got {len(data['devices'])} REAL devices from PVS")
                return data['devices']
            return []
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Error fetching device list: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Error parsing JSON response: {e}")
            return None
    
    def get_system_summary(self) -> Dict:
        """Get system summary using REAL PVS data only"""
        devices = self.get_device_list()
        if not devices:
            return {
                'device_count': 0,
                'total_production_kw': 0,
                'total_consumption_kw': 0,
                'net_export_kw': 0,
                'system_online': False,
                'pvs_online': False,
                'timestamp': datetime.now().isoformat()
            }

        summary = {
            'timestamp': datetime.now().isoformat(),
            'device_count': len(devices),
            'total_production_kw': 0,
            'total_consumption_kw': 0,
            'net_export_kw': 0,
            'inverters': [],
            'meters': [],
            'system_online': True,
            'pvs_online': True
        }

        production_power = 0
        consumption_power = 0
        panel_flow_power = 0

        for device in devices:
            device_type = device.get('DEVICE_TYPE', '').lower()
            # Use REAL PVS state fields
            device_state = device.get('STATE', '').lower()
            device_state_desc = device.get('STATEDESCR', '')

            # Parse power meters using REAL PVS data
            if 'power meter' in device_type or 'meter' in device_type:
                power_kw = float(device.get('p_3phsum_kw', 0))
                subtype = device.get('subtype', '').lower()

                meter_data = {
                    'serial': device.get('SERIAL', ''),
                    'power_kw': power_kw,
                    'energy_kwh': float(device.get('net_ltea_3phsum_kwh', 0)),
                    'type': device.get('TYPE', ''),
                    'subtype': subtype,
                    'state': device_state,  # REAL state from PVS
                    'state_description': device_state_desc,  # REAL description
                    'status': 'online' if device_state == 'working' else 'offline'
                }
                summary['meters'].append(meter_data)

                # Categorize production vs consumption using serial numbers
                serial = device.get('SERIAL', '')
                if serial.endswith('p'):
                    production_power += power_kw
                    print(f"DEBUG: Production meter {serial}: {power_kw} kW")
                elif serial.endswith('c'):
                    # Consumption meter shows total panel flow, not actual home usage
                    # We'll calculate actual consumption later: panel_flow - production
                    panel_flow_power = power_kw
                    print(f"DEBUG: Panel flow meter {serial}: {power_kw} kW (total through panel)")

            # Parse inverters using REAL PVS data
            elif 'inverter' in device_type or 'solarbridge' in device.get('TYPE', '').lower():
                power_kw = float(device.get('p_3phsum_kw', 0))

                inverter_data = {
                    'serial': device.get('SERIAL', ''),
                    'power_kw': power_kw,
                    'energy_kwh': float(device.get('ltea_3phsum_kwh', 0)),
                    'voltage': float(device.get('vln_3phavg_v', 0)),
                    'current': float(device.get('i_3phsum_a', 0)),
                    'temperature': float(device.get('t_htsnk_degc', 0)),
                    'state': device_state,  # REAL state from PVS
                    'state_description': device_state_desc,  # REAL description
                    'status': 'online' if device_state == 'working' else 'offline',  # Correct status logic
                    'panel': device.get('PANEL', ''),
                    'frequency': float(device.get('freq_hz', 0))
                }
                summary['inverters'].append(inverter_data)

        # Calculate actual home consumption from panel flow
        # Panel flow meter shows total power through main panel
        # Actual consumption = panel flow - production (what's left for the house)
        if panel_flow_power > 0:
            consumption_power = panel_flow_power - production_power
            # If consumption is negative, it means we're importing from grid
            if consumption_power < 0:
                consumption_power = abs(consumption_power)
        
        # Set totals
        summary['total_production_kw'] = production_power
        summary['total_consumption_kw'] = consumption_power
        summary['net_export_kw'] = production_power - consumption_power

        print(f"✅ REAL PVS Summary: {len(summary['inverters'])} inverters, {len(summary['meters'])} meters")
        print(f"✅ Production: {production_power:.2f}kW, Panel Flow: {panel_flow_power:.2f}kW")
        print(f"✅ Calculated Consumption: {consumption_power:.2f}kW, Net Export: {summary['net_export_kw']:.2f}kW")
        
        return summary
