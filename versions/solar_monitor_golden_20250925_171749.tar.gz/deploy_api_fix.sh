#!/bin/bash
# Deploy API Fix to Pi

echo "🚀 DEPLOYING API FIX TO PI"
echo "=========================="

PI_IP="192.168.1.126"
COMPUTER_IP="192.168.1.169"
HTTP_PORT="8008"

echo "📡 Downloading API fix from http://$COMPUTER_IP:$HTTP_PORT/fix_api_parsing.tar.gz"

# Download the fix
wget "http://$COMPUTER_IP:$HTTP_PORT/fix_api_parsing.tar.gz"

if [ $? -eq 0 ]; then
    echo "✅ Download successful"
    
    # Extract the fix
    echo "📦 Extracting fix..."
    tar -xzf fix_api_parsing.tar.gz
    
    # Backup current file
    echo "💾 Backing up current web_dashboard.py..."
    cp ~/solar_monitor/src/web_dashboard.py ~/solar_monitor/src/web_dashboard.py.backup.$(date +%Y%m%d_%H%M%S)
    
    # Deploy the fix
    echo "🔧 Deploying fixed web_dashboard.py..."
    cp src/web_dashboard.py ~/solar_monitor/src/
    
    # Restart the service
    echo "🔄 Restarting Solar Monitor service..."
    sudo systemctl restart solar-monitor.service
    
    # Wait for service to start
    sleep 5
    
    # Test the fix
    echo "🧪 Testing the fix..."
    
    echo "📊 Current Status API:"
    curl -s "http://localhost:5000/api/current_status" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(f'  ✅ API Status: {data.get(\"api_status\", \"unknown\")}')
    print(f'  📱 Device Count: {data.get(\"device_count\", 0)}')
    print(f'  🔗 PVS Online: {data.get(\"pvs_online\", False)}')
    print(f'  ⚡ Production: {data.get(\"total_production_kw\", 0)} kW')
    print(f'  🏠 Consumption: {data.get(\"total_consumption_kw\", 0)} kW')
    
    if data.get('device_count', 0) > 0:
        print('  🎉 SUCCESS: Devices are now being detected!')
    else:
        print('  ⚠️  Still showing 0 devices - may need PVS6 connection fix')
except Exception as e:
    print(f'  ❌ Error parsing API response: {e}')
"
    
    echo ""
    echo "📊 Device Details API:"
    curl -s "http://localhost:5000/api/device_details" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    total = data.get('total_count', 0)
    working = data.get('working_count', 0)
    offline = data.get('offline_count', 0)
    print(f'  📱 Total Devices: {total}')
    print(f'  ✅ Working: {working}')
    print(f'  ❌ Offline: {offline}')
    
    if total > 0:
        print('  🎉 SUCCESS: Device details API is working!')
        devices = data.get('devices', [])
        print('  📋 Sample devices:')
        for i, device in enumerate(devices[:3]):
            dtype = device.get('device_type', 'Unknown')
            serial = device.get('serial', 'Unknown')
            status = device.get('status', 'Unknown')
            power = device.get('power_kw', 0)
            print(f'    {i+1}. {dtype} ({serial}) - {status} - {power} kW')
    else:
        print('  ⚠️  Still no devices in details API')
except Exception as e:
    print(f'  ❌ Error parsing device details: {e}')
"
    
    echo ""
    echo "🎯 DEPLOYMENT COMPLETE!"
    echo "======================"
    
    # Check service status
    if sudo systemctl is-active --quiet solar-monitor.service; then
        echo "✅ Service is running"
        echo "🌐 Dashboard: http://$(hostname -I | awk '{print $1}'):5000"
        echo ""
        echo "🔍 If device count is still 0, the issue may be:"
        echo "  1. PVS6 network connection"
        echo "  2. PVS6 API response format"
        echo "  3. Device parsing logic needs further adjustment"
        echo ""
        echo "📋 Check service logs:"
        echo "  sudo journalctl -u solar-monitor.service -f"
    else
        echo "❌ Service failed to start"
        echo "📋 Check logs:"
        echo "  sudo journalctl -u solar-monitor.service -n 20"
    fi
    
    # Cleanup
    rm -f fix_api_parsing.tar.gz
    rm -rf src/
    
else
    echo "❌ Download failed"
    echo "Please check:"
    echo "  1. HTTP server is running: python3 -m http.server 8008"
    echo "  2. Network connectivity"
    echo "  3. Package exists at http://$COMPUTER_IP:$HTTP_PORT/fix_api_parsing.tar.gz"
fi
