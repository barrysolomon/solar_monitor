#!/usr/bin/env python3
"""
Fix Solar Monitor API Device Parsing
Updates the web dashboard to properly handle device parsing
"""

import os
import sys

# Fixed web_dashboard.py content
FIXED_WEB_DASHBOARD = '''#!/usr/bin/env python3
"""
Enhanced Web Dashboard for Solar Monitor - FIXED DEVICE PARSING
Professional interface with analysis capabilities
"""
import os
from flask import Flask, render_template, jsonify, request
from datetime import datetime, timedelta
import sys
import json

# Add parent directory to path to import other modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import SolarDatabase
from pvs_client import PVSClient
import config

# Create Flask app with correct template directory - FIXED PATH
app = Flask(__name__, template_folder="../templates")

@app.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/current_status')
def current_status():
    """Get current system status with enhanced data - FIXED DEVICE PARSING"""
    try:
        client = PVSClient()
        
        # Test connection first
        if not client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'device_count': 0,
                'total_production_kw': 0.0,
                'total_consumption_kw': 0.0,
                'net_export_kw': 0.0,
                'pvs_online': False,
                'system_online': False,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'ERROR'
            })
        
        # Get system summary
        summary = client.get_system_summary()
        
        # Ensure all required fields are present
        response = {
            'api_status': 'success',
            'device_count': summary.get('device_count', 0),
            'total_production_kw': summary.get('total_production_kw', 0.0),
            'total_consumption_kw': summary.get('total_consumption_kw', 0.0),
            'net_export_kw': summary.get('net_export_kw', 0.0),
            'pvs_online': summary.get('pvs_online', True),
            'system_online': summary.get('system_online', True),
            'timestamp': summary.get('timestamp', datetime.now().isoformat()),
            'data_source': 'LIVE_PVS'
        }
        
        print(f"✅ API Response: {response['device_count']} devices, PVS online: {response['pvs_online']}")
        return jsonify(response)
        
    except Exception as e:
        print(f"❌ API Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'device_count': 0,
            'total_production_kw': 0.0,
            'total_consumption_kw': 0.0,
            'net_export_kw': 0.0,
            'pvs_online': False,
            'system_online': False,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'ERROR'
        }), 500

@app.route('/api/historical_data')
def historical_data():
    """Get historical data for analysis"""
    try:
        hours = int(request.args.get('hours', 24))
        db = SolarDatabase()
        data = db.get_latest_data(hours=hours)
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'hours': hours
        })
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'hours': hours,
            'error': str(e)
        })

@app.route('/api/historical_data_minutes')
def historical_data_minutes():
    """Get recent historical data by minutes"""
    try:
        minutes = int(request.args.get('minutes', 60))
        db = SolarDatabase()
        data = db.get_latest_data(hours=minutes/60)
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'minutes': minutes
        })
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'minutes': minutes,
            'error': str(e)
        })

@app.route('/api/device_details')
def device_details():
    """Get detailed device information - FIXED DEVICE PARSING"""
    try:
        client = PVSClient()
        
        # Test connection first
        if not client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'devices': [],
                'total_count': 0,
                'working_count': 0,
                'offline_count': 0,
                'data_source': 'ERROR'
            })
        
        # Get device list
        devices = client.get_device_list()
        
        if devices is None:
            return jsonify({
                'api_status': 'error',
                'error': 'Failed to get device list from PVS6',
                'devices': [],
                'total_count': 0,
                'working_count': 0,
                'offline_count': 0,
                'data_source': 'ERROR'
            })
        
        if not devices:
            return jsonify({
                'api_status': 'success',
                'devices': [],
                'total_count': 0,
                'working_count': 0,
                'offline_count': 0,
                'data_source': 'LIVE_PVS',
                'message': 'No devices found in PVS6 response'
            })
        
        # Enhanced device analysis
        device_analysis = []
        working_count = 0
        offline_count = 0
        
        for device in devices:
            device_state = device.get('STATE', '').lower()
            is_working = device_state == 'working'
            
            if is_working:
                working_count += 1
            else:
                offline_count += 1
            
            analysis = {
                'serial': device.get('SERIAL', 'Unknown'),
                'device_type': device.get('DEVICE_TYPE', device.get('TYPE', 'Unknown')),
                'status': device_state,
                'status_description': device.get('STATEDESCR', ''),
                'power_kw': float(device.get('p_3phsum_kw', 0)),
                'energy_kwh': float(device.get('ltea_3phsum_kwh', device.get('net_ltea_3phsum_kwh', 0))),
                'voltage': float(device.get('vln_3phavg_v', device.get('v12_v', 0))),
                'current': float(device.get('i_3phsum_a', device.get('i_a', 0))),
                'temperature': device.get('t_htsnk_degc', 'N/A'),
                'last_update': device.get('DATATIME', ''),
                'model': device.get('MODEL', ''),
                'panel_type': device.get('PANEL', ''),
                'frequency': float(device.get('freq_hz', 0)),
                'subtype': device.get('subtype', ''),
                'is_working': is_working
            }
            device_analysis.append(analysis)
        
        response = {
            'api_status': 'success',
            'devices': device_analysis,
            'total_count': len(device_analysis),
            'working_count': working_count,
            'offline_count': offline_count,
            'data_source': 'LIVE_PVS'
        }
        
        print(f"✅ Device Details: {len(device_analysis)} total, {working_count} working, {offline_count} offline")
        return jsonify(response)
        
    except Exception as e:
        print(f"❌ Device Details Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'devices': [],
            'total_count': 0,
            'working_count': 0,
            'offline_count': 0,
            'data_source': 'ERROR'
        }), 500

@app.route('/api/database_viewer')
def database_viewer():
    """View database contents"""
    try:
        table = request.args.get('table', 'solar_data')
        limit = int(request.args.get('limit', 100))
        
        db = SolarDatabase()
        
        if table == 'solar_data':
            data = db.get_latest_data(hours=24, limit=limit)
            columns = ['id', 'timestamp', 'device_id', 'device_type', 'power_kw', 'energy_kwh', 'voltage', 'current']
        else:
            # Default fallback
            data = []
            columns = []
        
        return jsonify({
            'table': table,
            'columns': columns,
            'data': data,
            'count': len(data)
        })
    except Exception as e:
        return jsonify({
            'table': table,
            'columns': [],
            'data': [],
            'count': 0,
            'error': str(e)
        })

@app.route('/api/system_info')
def system_info():
    """Get system information"""
    try:
        import psutil
        import platform
        
        return jsonify({
            'platform': platform.system(),
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
            'uptime': datetime.now().isoformat(),
            'python_version': sys.version
        })
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
'''

def main():
    print("🔧 FIXING SOLAR MONITOR API DEVICE PARSING")
    print("==========================================")
    
    # Write the fixed web dashboard
    src_dir = os.path.join(os.path.dirname(__file__), 'src')
    web_dashboard_path = os.path.join(src_dir, 'web_dashboard.py')
    
    print(f"📝 Writing fixed web_dashboard.py...")
    with open(web_dashboard_path, 'w') as f:
        f.write(FIXED_WEB_DASHBOARD)
    
    print(f"✅ Fixed web_dashboard.py written")
    print(f"📁 Location: {web_dashboard_path}")
    print("")
    print("🔧 KEY FIXES APPLIED:")
    print("  ✅ Added proper error handling for device list")
    print("  ✅ Fixed None return value handling")
    print("  ✅ Added connection testing before API calls")
    print("  ✅ Enhanced device parsing with proper counts")
    print("  ✅ Added detailed logging for debugging")
    print("")
    print("🚀 NEXT STEP: Deploy to Pi")
    print("==========================")
    print("Run this to update the Pi:")
    print("  tar -czf fix_api_parsing.tar.gz fix_api_parsing.py src/web_dashboard.py")
    print("  # Then on Pi:")
    print("  wget http://192.168.1.169:8008/fix_api_parsing.tar.gz")
    print("  tar -xzf fix_api_parsing.tar.gz")
    print("  cp src/web_dashboard.py ~/solar_monitor/src/")
    print("  sudo systemctl restart solar-monitor.service")

if __name__ == "__main__":
    main()
