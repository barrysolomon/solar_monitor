#!/usr/bin/env python3
"""
Simple Solar Data Collector - No complex dependencies
"""

import sys
import os
import time
import sqlite3
from datetime import datetime
import random

def get_db_connection():
    """Simple database connection"""
    db_path = '/opt/solar_monitor/solar_data.db'
    conn = sqlite3.connect(db_path, timeout=10.0, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=5000')
    return conn

def ensure_tables():
    """Ensure database tables exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create system_status table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS system_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            production_kw REAL DEFAULT 0,
            consumption_kw REAL DEFAULT 0,
            net_export_kw REAL DEFAULT 0,
            grid_frequency REAL DEFAULT 60.0,
            voltage REAL DEFAULT 240.0
        )
    """)
    
    # Create solar_data table with device_id column
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS solar_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            production_kw REAL DEFAULT 0,
            consumption_kw REAL DEFAULT 0,
            net_export_kw REAL DEFAULT 0,
            device_id TEXT DEFAULT NULL
        )
    """)
    
    # Create device_data table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS device_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            device_id TEXT,
            device_type TEXT DEFAULT 'inverter',
            status TEXT DEFAULT 'working',
            power_kw REAL DEFAULT 0,
            voltage REAL DEFAULT 240.0,
            current_a REAL DEFAULT 0,
            frequency REAL DEFAULT 60.0,
            temperature REAL DEFAULT 25.0
        )
    """)
    
    # Create indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_device_id ON solar_data(device_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON solar_data(timestamp)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_device_timestamp ON device_data(device_id, timestamp)")
    
    conn.commit()
    conn.close()
    print("✅ Database tables ensured")

def collect_data():
    """Collect sample data and store in database"""
    try:
        print(f"[{datetime.now()}] Collecting solar data...")
        
        # Generate realistic sample data based on time of day
        hour = datetime.now().hour
        if 6 <= hour <= 18:  # Daytime
            base_production = 4.0 - abs(hour - 12) * 0.2  # Peak at noon
            production_kw = max(0, base_production + random.uniform(-0.5, 0.5))
        else:  # Nighttime
            production_kw = 0
        
        consumption_kw = 2.0 + random.uniform(-0.3, 0.3)
        net_export_kw = production_kw - consumption_kw
        
        print(f"📊 SIMULATED Data: {production_kw:.2f}kW production, {consumption_kw:.2f}kW consumption (PVS6 offline)")
        
        # Store in database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        timestamp = datetime.now().isoformat()
        
        # Insert into system_status
        cursor.execute("""
            INSERT INTO system_status (timestamp, production_kw, consumption_kw, net_export_kw)
            VALUES (?, ?, ?, ?)
        """, (timestamp, production_kw, consumption_kw, net_export_kw))
        
        # Insert into solar_data for compatibility
        cursor.execute("""
            INSERT INTO solar_data (timestamp, production_kw, consumption_kw, net_export_kw)
            VALUES (?, ?, ?, ?)
        """, (timestamp, production_kw, consumption_kw, net_export_kw))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Data stored: {production_kw:.2f}kW, {consumption_kw:.2f}kW, {net_export_kw:.2f}kW")
        
    except Exception as e:
        print(f"❌ Collection error: {e}")

def main():
    """Main data collector loop"""
    print("🌞 Solar Data Collector Starting (SIMULATION MODE - PVS6 offline)...")
    print("⚠️  Using simulated data - PVS6 connection not available")
    
    # Ensure database tables exist
    try:
        ensure_tables()
    except Exception as e:
        print(f"❌ Database setup error: {e}")
        return
    
    # Collect initial data
    collect_data()
    
    # Run collection loop
    while True:
        try:
            time.sleep(60)   # Wait 1 minute
            collect_data()
        except KeyboardInterrupt:
            print("Data collector stopped")
            break
        except Exception as e:
            print(f"❌ Error: {e}")
            time.sleep(60)  # Wait 1 minute before retry

if __name__ == '__main__':
    main()
