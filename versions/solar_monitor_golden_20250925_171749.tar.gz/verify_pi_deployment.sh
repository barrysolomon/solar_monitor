#!/bin/bash

echo "🔍 VERIFYING PI DEPLOYMENT - v1.0.65"
echo "===================================="

echo "📍 Step 1: Check service status"
sudo systemctl status solar-monitor.service --no-pager -l

echo ""
echo "📍 Step 2: Check if service is running"
ps aux | grep web_dashboard_cached_simple.py | grep -v grep

echo ""
echo "📍 Step 3: Check version API directly"
curl -s http://localhost:5000/api/version/current

echo ""
echo "📍 Step 4: Check if port 5000 is listening"
sudo netstat -tlnp | grep :5000

echo ""
echo "📍 Step 5: Check recent service logs"
sudo journalctl -u solar-monitor.service --no-pager -l | tail -15

echo ""
echo "📍 Step 6: Test main page response"
curl -s -I http://localhost:5000/

echo ""
echo "📍 Step 7: If service not running, start it"
if ! pgrep -f web_dashboard_cached_simple.py > /dev/null; then
    echo "⚠️ Service not running, starting..."
    sudo systemctl start solar-monitor.service
    sleep 3
    echo "✅ Service started, testing again..."
    curl -s http://localhost:5000/api/version/current
fi

echo ""
echo "🎯 VERIFICATION COMPLETE"
echo "🌐 Pi should be accessible at: http://192.168.1.126:5000"
