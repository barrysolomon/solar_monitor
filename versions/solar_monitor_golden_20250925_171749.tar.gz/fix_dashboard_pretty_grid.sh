#!/bin/bash

echo "✨ Applying beautiful dashboard with grid view toggle..."

# Backup the current template
sudo cp /home/barry/solar_monitor/templates/dashboard.html /home/barry/solar_monitor/templates/dashboard.html.backup2

# Create a temporary file with the improved CSS and JavaScript
cat > /tmp/dashboard_improvements.txt << 'IMPROVEMENTS_END'

/* Add this CSS after the existing device grid styles */
<style>
/* VIEW TOGGLE BUTTON */
.view-toggle-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 20px 0;
    gap: 15px;
}

.view-toggle-btn {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9em;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
}

.view-toggle-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(52, 152, 219, 0.4);
}

.view-toggle-btn.active {
    background: linear-gradient(135deg, #27ae60, #229954);
    box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);
}

/* GRID VIEW STYLES */
.device-grid.grid-view {
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 15px;
}

.device-grid.grid-view .device-card {
    padding: 15px;
    border-radius: 10px;
}

.device-grid.grid-view .device-details {
    grid-template-columns: 1fr;
    gap: 8px;
}

.device-grid.grid-view .device-detail {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding: 6px 10px;
}

.device-grid.grid-view .device-label {
    margin-bottom: 0;
    font-size: 0.75em;
}

.device-grid.grid-view .device-value {
    font-size: 0.9em;
}

.device-grid.grid-view .device-serial {
    font-size: 0.75em;
    padding: 6px;
    margin-top: 8px;
}

/* CARD VIEW STYLES (DEFAULT) */
.device-grid.card-view {
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
}

/* BEAUTIFUL DEVICE CARDS */
.device-card {
    background: linear-gradient(135deg, #ffffff, #f8f9fa);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    border: 1px solid #e9ecef;
    position: relative;
    overflow: hidden;
}

.device-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3498db, #2980b9);
}

.device-card.pvs-gateway::before {
    background: linear-gradient(90deg, #9b59b6, #8e44ad);
}

.device-card.power-meter::before {
    background: linear-gradient(90deg, #e74c3c, #c0392b);
}

.device-card.inverter::before {
    background: linear-gradient(90deg, #27ae60, #229954);
}

.device-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
}

.device-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 2px solid #ecf0f1;
}

.device-type {
    font-size: 1.2em;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.device-type::before {
    content: '';
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #3498db;
}

.device-card.pvs-gateway .device-type::before {
    background: #9b59b6;
}

.device-card.power-meter .device-type::before {
    background: #e74c3c;
}

.device-card.inverter .device-type::before {
    background: #27ae60;
}

.device-status {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.8em;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.device-status.working {
    background: linear-gradient(135deg, #d4edda, #c3e6cb);
    color: #155724;
    border: 2px solid #c3e6cb;
    box-shadow: 0 2px 8px rgba(39, 174, 96, 0.2);
}

.device-status.offline {
    background: linear-gradient(135deg, #f8d7da, #f5c6cb);
    color: #721c24;
    border: 2px solid #f5c6cb;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.2);
}

.device-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 15px;
}

.device-detail {
    display: flex;
    flex-direction: column;
    padding: 12px;
    background: linear-gradient(135deg, #f8f9fa, #ffffff);
    border-radius: 8px;
    border-left: 4px solid #3498db;
    transition: all 0.2s ease;
}

.device-detail:hover {
    transform: translateX(2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.device-label {
    color: #7f8c8d;
    font-weight: 600;
    font-size: 0.75em;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 6px;
}

.device-value {
    font-weight: 700;
    color: #2c3e50;
    font-size: 1.1em;
}

.device-serial {
    text-align: center;
    font-family: 'Courier New', monospace;
    font-size: 0.85em;
    color: #7f8c8d;
    background: linear-gradient(135deg, #ecf0f1, #bdc3c7);
    padding: 10px;
    border-radius: 8px;
    margin-top: 10px;
    font-weight: 600;
    letter-spacing: 1px;
}

/* RESPONSIVE DESIGN */
@media (max-width: 768px) {
    .device-grid.card-view {
        grid-template-columns: 1fr;
        gap: 15px;
        padding: 0 10px;
    }
    
    .device-grid.grid-view {
        grid-template-columns: 1fr;
        gap: 10px;
    }
    
    .device-details {
        grid-template-columns: 1fr;
        gap: 8px;
    }
    
    .device-type {
        font-size: 1em;
    }
    
    .view-toggle-container {
        flex-direction: column;
        gap: 10px;
    }
}

@media (max-width: 480px) {
    .device-card {
        padding: 15px;
    }
    
    .device-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .device-status {
        align-self: flex-end;
    }
}
</style>

<!-- Add this HTML for the view toggle buttons -->
<div class="view-toggle-container">
    <button id="card-view-btn" class="view-toggle-btn active" onclick="switchView('card')">
        📋 Card View
    </button>
    <button id="grid-view-btn" class="view-toggle-btn" onclick="switchView('grid')">
        📊 Grid View
    </button>
</div>

<!-- Add this JavaScript for view switching -->
<script>
function switchView(viewType) {
    const deviceGrid = document.getElementById('device-grid');
    const cardBtn = document.getElementById('card-view-btn');
    const gridBtn = document.getElementById('grid-view-btn');
    
    if (viewType === 'card') {
        deviceGrid.className = 'device-grid card-view';
        cardBtn.classList.add('active');
        gridBtn.classList.remove('active');
        localStorage.setItem('dashboard-view', 'card');
    } else {
        deviceGrid.className = 'device-grid grid-view';
        gridBtn.classList.add('active');
        cardBtn.classList.remove('active');
        localStorage.setItem('dashboard-view', 'grid');
    }
}

// Load saved view preference
document.addEventListener('DOMContentLoaded', function() {
    const savedView = localStorage.getItem('dashboard-view') || 'card';
    switchView(savedView);
});
</script>

IMPROVEMENTS_END

# Apply the improvements to the dashboard template
# First, add the CSS improvements
sudo sed -i '/<\/style>/i\
/* VIEW TOGGLE AND BEAUTIFUL STYLING */\
.view-toggle-container {\
    display: flex;\
    justify-content: center;\
    align-items: center;\
    margin: 20px 0;\
    gap: 15px;\
}\
\
.view-toggle-btn {\
    background: linear-gradient(135deg, #3498db, #2980b9);\
    color: white;\
    border: none;\
    padding: 12px 24px;\
    border-radius: 25px;\
    cursor: pointer;\
    font-weight: 600;\
    font-size: 0.9em;\
    transition: all 0.3s ease;\
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);\
}\
\
.view-toggle-btn:hover {\
    transform: translateY(-2px);\
    box-shadow: 0 6px 20px rgba(52, 152, 219, 0.4);\
}\
\
.view-toggle-btn.active {\
    background: linear-gradient(135deg, #27ae60, #229954);\
    box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);\
}\
\
.device-grid.grid-view {\
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));\
    gap: 15px;\
}\
\
.device-grid.grid-view .device-card {\
    padding: 15px;\
}\
\
.device-grid.grid-view .device-details {\
    grid-template-columns: 1fr;\
    gap: 8px;\
}\
\
.device-grid.grid-view .device-detail {\
    flex-direction: row;\
    justify-content: space-between;\
    align-items: center;\
    padding: 6px 10px;\
}\
\
.device-grid.card-view {\
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));\
    gap: 20px;\
}\
\
.device-card {\
    background: linear-gradient(135deg, #ffffff, #f8f9fa);\
    border-radius: 15px;\
    padding: 20px;\
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);\
    transition: all 0.3s ease;\
    border: 1px solid #e9ecef;\
    position: relative;\
    overflow: hidden;\
}\
\
.device-card::before {\
    content: "";\
    position: absolute;\
    top: 0;\
    left: 0;\
    right: 0;\
    height: 4px;\
    background: linear-gradient(90deg, #3498db, #2980b9);\
}\
\
.device-card.pvs-gateway::before {\
    background: linear-gradient(90deg, #9b59b6, #8e44ad);\
}\
\
.device-card.power-meter::before {\
    background: linear-gradient(90deg, #e74c3c, #c0392b);\
}\
\
.device-card.inverter::before {\
    background: linear-gradient(90deg, #27ae60, #229954);\
}\
\
.device-card:hover {\
    transform: translateY(-5px);\
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);\
}\
\
.device-type::before {\
    content: "";\
    width: 12px;\
    height: 12px;\
    border-radius: 50%;\
    background: #3498db;\
    display: inline-block;\
    margin-right: 8px;\
}\
\
.device-card.pvs-gateway .device-type::before {\
    background: #9b59b6;\
}\
\
.device-card.power-meter .device-type::before {\
    background: #e74c3c;\
}\
\
.device-card.inverter .device-type::before {\
    background: #27ae60;\
}' /home/barry/solar_monitor/templates/dashboard.html

# Add the view toggle buttons HTML before the device grid
sudo sed -i '/<div class="device-grid" id="device-grid">/i\
                <div class="view-toggle-container">\
                    <button id="card-view-btn" class="view-toggle-btn active" onclick="switchView('\''card'\'')">\
                        📋 Card View\
                    </button>\
                    <button id="grid-view-btn" class="view-toggle-btn" onclick="switchView('\''grid'\'')">\
                        📊 Grid View\
                    </button>\
                </div>' /home/barry/solar_monitor/templates/dashboard.html

# Add the view switching JavaScript
sudo sed -i '/<\/script>/i\
            function switchView(viewType) {\
                const deviceGrid = document.getElementById('\''device-grid'\'');\
                const cardBtn = document.getElementById('\''card-view-btn'\'');\
                const gridBtn = document.getElementById('\''grid-view-btn'\'');\
                \
                if (viewType === '\''card'\'') {\
                    deviceGrid.className = '\''device-grid card-view'\'';\
                    cardBtn.classList.add('\''active'\'');\
                    gridBtn.classList.remove('\''active'\'');\
                    localStorage.setItem('\''dashboard-view'\'', '\''card'\'');\
                } else {\
                    deviceGrid.className = '\''device-grid grid-view'\'';\
                    gridBtn.classList.add('\''active'\'');\
                    cardBtn.classList.remove('\''active'\'');\
                    localStorage.setItem('\''dashboard-view'\'', '\''grid'\'');\
                }\
            }\
            \
            // Load saved view preference\
            document.addEventListener('\''DOMContentLoaded'\'', function() {\
                const savedView = localStorage.getItem('\''dashboard-view'\'') || '\''card'\'';\
                switchView(savedView);\
            });' /home/barry/solar_monitor/templates/dashboard.html

# Set default class for device grid
sudo sed -i 's/<div class="device-grid" id="device-grid">/<div class="device-grid card-view" id="device-grid">/' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Applied beautiful dashboard with grid view toggle"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh"
echo ""
echo "✨ New features:"
echo "   - 📋 Card View: Detailed cards with beautiful styling"
echo "   - 📊 Grid View: Compact grid layout"
echo "   - 🎨 Color-coded device types with gradients"
echo "   - 💾 Remembers your view preference"
echo "   - 📱 Fully responsive design"
echo "   - ✨ Hover effects and animations"
