#!/bin/bash
echo "🛡️ Safe Deployment - Preserving Database"
echo "======================================="

VERSION="v1.0.76"
BACKUP_DIR="/tmp/solar_monitor_backup_$(date +%Y%m%d_%H%M%S)"
INSTALL_DIR="/opt/solar_monitor"

echo "📦 Downloading $VERSION..."
cd /home/barry
rm -f solar_monitor_${VERSION}_ui_fixes.tar.gz
wget http://192.168.1.169:8009/solar_monitor_${VERSION}_ui_fixes.tar.gz

echo "🛑 Stopping services..."
sudo systemctl stop solar-monitor.service
sudo systemctl stop solar-data-collector.service

echo "💾 Backing up database and config..."
mkdir -p "$BACKUP_DIR"
if [ -f "$INSTALL_DIR/solar_data.db" ]; then
    cp "$INSTALL_DIR/solar_data.db" "$BACKUP_DIR/"
    echo "✅ Database backed up to $BACKUP_DIR/solar_data.db"
fi

if [ -f "$INSTALL_DIR/src/config.py" ]; then
    cp "$INSTALL_DIR/src/config.py" "$BACKUP_DIR/"
    echo "✅ Config backed up"
fi

echo "📁 Extracting new version..."
rm -rf solar_monitor_temp
mkdir solar_monitor_temp
cd solar_monitor_temp
tar -xzf ../solar_monitor_${VERSION}_ui_fixes.tar.gz

echo "🔄 Installing new files (preserving database)..."
# Copy everything EXCEPT the database
find . -name "*.py" -exec cp {} "$INSTALL_DIR/{}" \; 2>/dev/null || true
find . -name "*.html" -exec cp {} "$INSTALL_DIR/{}" \; 2>/dev/null || true
find . -name "*.js" -exec cp {} "$INSTALL_DIR/{}" \; 2>/dev/null || true
find . -name "*.css" -exec cp {} "$INSTALL_DIR/{}" \; 2>/dev/null || true

# Copy specific directories
cp -r src/* "$INSTALL_DIR/src/" 2>/dev/null || true
cp -r templates/* "$INSTALL_DIR/templates/" 2>/dev/null || true

echo "🔙 Restoring database..."
if [ -f "$BACKUP_DIR/solar_data.db" ]; then
    cp "$BACKUP_DIR/solar_data.db" "$INSTALL_DIR/"
    echo "✅ Database restored"
else
    echo "⚠️ No database to restore"
fi

echo "🔧 Setting permissions..."
sudo chown -R barry:barry "$INSTALL_DIR"

echo "🚀 Starting services..."
sudo systemctl start solar-monitor.service
sudo systemctl start solar-data-collector.service

echo "🧹 Cleanup..."
cd /home/barry
rm -rf solar_monitor_temp

echo ""
echo "✅ Safe deployment complete!"
echo "📊 Database preserved with historical data"
echo "🗂️ Backup available at: $BACKUP_DIR"
echo ""
echo "🔍 Verify deployment:"
echo "sudo systemctl status solar-monitor.service"
echo "sudo systemctl status solar-data-collector.service"
