#!/bin/bash
echo "🔧 Fixing Data Collector Service Auto-Start"
echo "==========================================="

# Check if services exist
if ! systemctl list-unit-files | grep -q "solar-data-collector.service"; then
    echo "❌ solar-data-collector.service not found!"
    echo "Creating systemd service files..."
    
    # Create the data collector service
    sudo tee /etc/systemd/system/solar-data-collector.service > /dev/null <<EOF
[Unit]
Description=Solar Data Collector
After=network.target
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=barry
Group=barry
WorkingDirectory=/opt/solar_monitor
Environment=PATH=/opt/solar_monitor/venv/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=/opt/solar_monitor/venv/bin/python /opt/solar_monitor/src/data_collector.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    # Create the web dashboard service
    sudo tee /etc/systemd/system/solar-monitor.service > /dev/null <<EOF
[Unit]
Description=Solar Monitor Web Dashboard
After=network.target
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=barry
Group=barry
WorkingDirectory=/opt/solar_monitor
Environment=PATH=/opt/solar_monitor/venv/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=/opt/solar_monitor/venv/bin/python /opt/solar_monitor/web_dashboard_cached_simple.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    echo "✅ Service files created"
fi

echo "🔄 Reloading systemd daemon..."
sudo systemctl daemon-reload

echo "🚀 Enabling services to start on boot..."
sudo systemctl enable solar-data-collector.service
sudo systemctl enable solar-monitor.service

echo "▶️ Starting services..."
sudo systemctl start solar-data-collector.service
sudo systemctl start solar-monitor.service

echo ""
echo "📊 Service Status:"
echo "=================="
echo "Data Collector:"
sudo systemctl is-active solar-data-collector.service
sudo systemctl is-enabled solar-data-collector.service

echo ""
echo "Web Dashboard:"
sudo systemctl is-active solar-monitor.service  
sudo systemctl is-enabled solar-monitor.service

echo ""
echo "🔍 Detailed Status:"
echo "==================="
sudo systemctl status solar-data-collector.service --no-pager -l
echo ""
sudo systemctl status solar-monitor.service --no-pager -l

echo ""
echo "✅ Fix complete! Services should now start automatically on boot."
echo "🔄 To test: sudo reboot"
