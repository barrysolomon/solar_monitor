#!/bin/bash

echo "🚀 NUCLEAR DEPLOYMENT - COMPLETE RESET v1.0.65"
echo "=============================================="

echo "📍 Step 1: Kill ALL related processes"
sudo pkill -f solar-monitor || echo "No solar-monitor processes"
sudo pkill -f web_dashboard_cached_simple.py || echo "No web dashboard processes"
sudo pkill -f data_collector.py || echo "No data collector processes"
sleep 3

echo ""
echo "📍 Step 2: Stop and disable service completely"
sudo systemctl stop solar-monitor.service || echo "Service already stopped"
sudo systemctl disable solar-monitor.service || echo "Service already disabled"
sleep 2

echo ""
echo "📍 Step 3: Remove ALL old installations"
sudo rm -rf /opt/solar_monitor*
sudo rm -rf /home/barry/solar_monitor*
sudo rm -rf /tmp/solar_monitor*

echo ""
echo "📍 Step 4: Create completely fresh directory"
sudo mkdir -p /opt/solar_monitor
sudo chown barry:barry /opt/solar_monitor
sudo chmod 755 /opt/solar_monitor

echo ""
echo "📍 Step 5: Download v1.0.65 to fresh location"
cd /tmp
wget -O solar_monitor_v1.0.65.tar.gz http://192.168.1.169:8009/solar_monitor_v1.0.65_integrated_controls.tar.gz
if [ $? -ne 0 ]; then
    echo "❌ DOWNLOAD FAILED - Check HTTP server"
    exit 1
fi

echo ""
echo "📍 Step 6: Extract to temporary location"
mkdir -p /tmp/solar_extract
cd /tmp/solar_extract
tar -xzf /tmp/solar_monitor_v1.0.65.tar.gz
if [ $? -ne 0 ]; then
    echo "❌ EXTRACTION FAILED"
    exit 1
fi

echo ""
echo "📍 Step 7: Verify version in extracted files"
grep "build.*65" /tmp/solar_extract/src/version.py
if [ $? -ne 0 ]; then
    echo "❌ VERSION VERIFICATION FAILED - Not v1.0.65"
    exit 1
fi

echo ""
echo "📍 Step 8: Copy to final location"
sudo cp -r /tmp/solar_extract/* /opt/solar_monitor/
sudo chown -R barry:barry /opt/solar_monitor
sudo chmod -R 755 /opt/solar_monitor

echo ""
echo "📍 Step 9: Verify version in final location"
grep "build.*65" /opt/solar_monitor/src/version.py
if [ $? -ne 0 ]; then
    echo "❌ FINAL VERSION VERIFICATION FAILED"
    exit 1
fi

echo ""
echo "📍 Step 10: Recreate systemd service"
sudo tee /etc/systemd/system/solar-monitor.service > /dev/null << EOF
[Unit]
Description=Solar Monitor Dashboard
After=network.target

[Service]
Type=simple
User=barry
WorkingDirectory=/opt/solar_monitor
Environment=PYTHONPATH=/opt/solar_monitor
ExecStart=/usr/bin/python3 /opt/solar_monitor/web_dashboard_cached_simple.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo ""
echo "📍 Step 11: Reload systemd and enable service"
sudo systemctl daemon-reload
sudo systemctl enable solar-monitor.service

echo ""
echo "📍 Step 12: Start service"
sudo systemctl start solar-monitor.service
sleep 5

echo ""
echo "📍 Step 13: Check service status"
sudo systemctl status solar-monitor.service --no-pager -l

echo ""
echo "📍 Step 14: Test version API"
curl -s http://localhost:5000/api/version/current | python3 -m json.tool

echo ""
echo "📍 Step 15: Cleanup temporary files"
rm -rf /tmp/solar_extract
rm -f /tmp/solar_monitor_v1.0.65.tar.gz

echo ""
echo "🎉 NUCLEAR DEPLOYMENT COMPLETE!"
echo "🌐 Check: http://192.168.1.126:5000"
echo "📋 Version should now be v1.0.65"
