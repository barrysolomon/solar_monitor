#!/bin/bash

echo "🔍 DEBUGGING DEPLOYMENT - v1.0.65"
echo "=================================="

echo "📍 Step 1: Check current Pi version"
grep -r "build" /opt/solar_monitor/src/version.py 2>/dev/null || echo "❌ No version file found"

echo ""
echo "📍 Step 2: Check service status"
sudo systemctl status solar-monitor.service --no-pager -l

echo ""
echo "📍 Step 3: Stop service completely"
sudo systemctl stop solar-monitor.service
sudo systemctl disable solar-monitor.service
sleep 2

echo ""
echo "📍 Step 4: Kill any remaining processes"
sudo pkill -f "web_dashboard_cached_simple.py" || echo "No processes to kill"
sleep 2

echo ""
echo "📍 Step 5: Backup and remove old installation"
sudo mv /opt/solar_monitor /opt/solar_monitor_backup_debug_$(date +%Y%m%d_%H%M%S) 2>/dev/null || echo "No old installation to backup"

echo ""
echo "📍 Step 6: Create fresh directory"
sudo mkdir -p /opt/solar_monitor
sudo chown barry:barry /opt/solar_monitor

echo ""
echo "📍 Step 7: Download and extract v1.0.65"
cd /tmp
rm -rf solar_monitor_debug
mkdir solar_monitor_debug
cd solar_monitor_debug
wget http://192.168.1.169:8009/solar_monitor_v1.0.65_integrated_controls.tar.gz
if [ $? -eq 0 ]; then
    echo "✅ Download successful"
    tar -xzf solar_monitor_v1.0.65_integrated_controls.tar.gz
    echo "✅ Extraction successful"
else
    echo "❌ Download failed"
    exit 1
fi

echo ""
echo "📍 Step 8: Copy files to /opt/solar_monitor"
sudo cp -r * /opt/solar_monitor/
sudo chown -R barry:barry /opt/solar_monitor

echo ""
echo "📍 Step 9: Verify version in new installation"
grep -r "build" /opt/solar_monitor/src/version.py

echo ""
echo "📍 Step 10: Re-enable and start service"
sudo systemctl enable solar-monitor.service
sudo systemctl start solar-monitor.service
sleep 3

echo ""
echo "📍 Step 11: Check service status"
sudo systemctl status solar-monitor.service --no-pager -l

echo ""
echo "📍 Step 12: Check if web server is responding"
curl -s http://localhost:5000/api/version/current | head -5

echo ""
echo "📍 Step 13: Cleanup"
cd /home/barry
rm -rf /tmp/solar_monitor_debug

echo ""
echo "🎉 DEPLOYMENT COMPLETE - Check version at http://192.168.1.126:5000"
