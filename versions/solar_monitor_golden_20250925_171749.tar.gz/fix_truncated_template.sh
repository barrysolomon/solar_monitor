#!/bin/bash

echo "🔧 Fixing the truncated template..."

# The template got cut off during our sed operation
# Let's restore from the working backup and then apply our improvements more carefully

echo "📋 Current template size: $(wc -c < /home/barry/solar_monitor/templates/dashboard.html) bytes"
echo "📋 Working backup size: $(wc -c < /home/barry/solar_monitor/templates/dashboard.html.working_backup) bytes"

echo "🔄 Restoring from working backup..."
sudo cp /home/barry/solar_monitor/templates/dashboard.html.working_backup /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Template restored"
echo "📋 Restored template size: $(wc -c < /home/barry/solar_monitor/templates/dashboard.html) bytes"

echo "🔄 Restarting service..."
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Check your dashboard at http://192.168.1.126:5000"
echo ""
echo "✅ Your dashboard should be working again!"
echo "📝 We'll apply the beautiful layout more carefully next time"
