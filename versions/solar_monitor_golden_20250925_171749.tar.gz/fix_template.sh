#!/bin/bash
# Fix the JavaScript field name in dashboard template
sudo sed -i 's/device\.type || '\''Unknown'\''/device.device_type || '\''Unknown'\''/g' /home/barry/solar_monitor/templates/dashboard.html

# Also fix any other instances of device.type
sudo sed -i 's/device\.type/device.device_type/g' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Fixed dashboard template JavaScript field names"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service

sleep 3

echo "✅ Service restarted"
echo "🌐 Now refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh to clear cache"
