#!/bin/bash

echo "🚑 Restoring dashboard from backup..."

# Check if we have a backup
if [ -f "/home/barry/solar_monitor/templates/dashboard.html.backup2" ]; then
    echo "✅ Found backup2, restoring..."
    sudo cp /home/barry/solar_monitor/templates/dashboard.html.backup2 /home/barry/solar_monitor/templates/dashboard.html
elif [ -f "/home/barry/solar_monitor/templates/dashboard.html.backup" ]; then
    echo "✅ Found backup, restoring..."
    sudo cp /home/barry/solar_monitor/templates/dashboard.html.backup /home/barry/solar_monitor/templates/dashboard.html
else
    echo "❌ No backup found. Let's check what's wrong with the current template..."
    echo "Current template size:"
    ls -la /home/barry/solar_monitor/templates/dashboard.html
    echo ""
    echo "First few lines of template:"
    head -10 /home/barry/solar_monitor/templates/dashboard.html
fi

echo "🔄 Restarting service..."
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Check your dashboard at http://192.168.1.126:5000"
echo ""
echo "If it's still blank, we'll need to restore from the original template."
