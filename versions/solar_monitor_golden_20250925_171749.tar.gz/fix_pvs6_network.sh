#!/bin/bash
echo "🔧 Fixing PVS6 Network Connectivity"
echo "=================================="
echo ""

echo "📡 Current Network Status:"
echo "-------------------------"
ip addr show | grep -E "(wlan0|eth0)" -A 3
echo ""

echo "🔍 Current Routes:"
echo "----------------"
ip route show
echo ""

echo "📶 WiFi Status:"
echo "-------------"
iwconfig wlan0 2>/dev/null || echo "WiFi interface not found"
echo ""

echo "🔧 Attempting to fix connectivity..."
echo ""

# Check if we're connected to the right networks
echo "1. Checking network interfaces..."
WLAN_IP=$(ip addr show wlan0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d'/' -f1)
ETH_IP=$(ip addr show eth0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d'/' -f1)

echo "   wlan0 IP: ${WLAN_IP:-Not connected}"
echo "   eth0 IP: ${ETH_IP:-Not connected}"
echo ""

# The PVS6 should be reachable via wlan0 (SunPower network)
if [[ -n "$WLAN_IP" ]]; then
    echo "2. Testing wlan0 connectivity to PVS6..."
    ping -I wlan0 -c 2 172.27.152.1 2>/dev/null && echo "   ✅ PVS6 reachable via wlan0 (172.27.152.1)" || echo "   ❌ PVS6 not reachable via wlan0"
    ping -I wlan0 -c 2 172.27.153.1 2>/dev/null && echo "   ✅ PVS6 reachable via wlan0 (172.27.153.1)" || echo "   ❌ PVS6 not reachable via wlan0"
else
    echo "2. ❌ wlan0 not connected - need to connect to SunPower WiFi"
fi
echo ""

echo "3. Checking if PVS6 is on a different subnet..."
# Try correct PVS6 IP addresses
for ip in 172.27.152.1 172.27.153.1; do
    echo "   Testing $ip..."
    timeout 3 ping -c 1 $ip >/dev/null 2>&1 && echo "   ✅ Found PVS6 at $ip" && break
done
echo ""

echo "💡 Next Steps:"
echo "1. Ensure Pi wlan0 is connected to SunPower WiFi network"
echo "2. Ensure Pi eth0 is connected to your home network"
echo "3. Check if PVS6 IP address has changed"
echo "4. Restart networking: sudo systemctl restart networking"