"""
Enhanced Solar Monitor Web Dashboard with Database APIs
Provides comprehensive database querying and data collection control
"""
import os
import sys
import sqlite3
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
import requests
from typing import List, Dict, Optional

# Add the src directory to Python path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

try:
    from pvs_client import PVSClient
    from database import SolarDatabase
    import config
except ImportError as e:
    print(f"Import error: {e}")
    print("Make sure you're running from the project root directory")
    sys.exit(1)

app = Flask(__name__, template_folder='templates')

# Global instances
pvs_client = PVSClient()
solar_db = SolarDatabase()

# ============================================================================
# EXISTING DASHBOARD ROUTES
# ============================================================================

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/current_status')
def current_status():
    """Get current system status and live data"""
    try:
        # Test PVS connection
        if not pvs_client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'pvs_online': False,
                'system_online': False,
                'device_count': 0,
                'total_production_kw': 0.0,
                'total_consumption_kw': 0.0,
                'net_export_kw': 0.0,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'ERROR'
            }), 500

        # Get live device data
        devices = pvs_client.get_device_list()
        if devices is None:
            devices = []

        # Get system summary
        system_summary = pvs_client.get_system_summary()
        
        response = {
            'api_status': 'success',
            'pvs_online': True,
            'system_online': True,
            'device_count': len(devices),
            'total_production_kw': system_summary.get('total_production_kw', 0.0),
            'total_consumption_kw': system_summary.get('total_consumption_kw', 0.0),
            'net_export_kw': system_summary.get('net_export_kw', 0.0),
            'timestamp': datetime.now().isoformat(),
            'data_source': 'LIVE_PVS'
        }
        
        return jsonify(response)
        
    except Exception as e:
        print(f"❌ API Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'device_count': 0,
            'total_production_kw': 0.0,
            'total_consumption_kw': 0.0,
            'net_export_kw': 0.0,
            'pvs_online': False,
            'system_online': False,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'ERROR'
        }), 500

@app.route('/api/device_details')
def device_details():
    """Get detailed device information"""
    try:
        # Test connection first
        if not pvs_client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'devices': [],
                'device_count': 0,
                'pvs_online': False
            }), 500

        # Get device list
        devices = pvs_client.get_device_list()
        if devices is None:
            devices = []

        # Process devices for frontend
        processed_devices = []
        for device in devices:
            try:
                parsed_device = pvs_client.parse_device_data(device)
                processed_devices.append(parsed_device)
            except Exception as e:
                print(f"Error parsing device {device.get('DeviceID', 'unknown')}: {e}")
                # Add raw device data as fallback
                processed_devices.append({
                    'device_id': device.get('DeviceID', 'Unknown'),
                    'device_type': device.get('DeviceType', 'Unknown'),
                    'serial': device.get('DeviceID', 'Unknown'),
                    'status': 'unknown',
                    'power_kw': 0.0,
                    'energy_kwh': 0.0,
                    'voltage': 0.0,
                    'current': 0.0,
                    'raw_data': json.dumps(device)
                })

        response = {
            'api_status': 'success',
            'devices': processed_devices,
            'device_count': len(processed_devices),
            'pvs_online': True,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
        
    except Exception as e:
        print(f"❌ Device Details Error: {e}")
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'devices': [],
            'device_count': 0,
            'pvs_online': False,
            'timestamp': datetime.now().isoformat()
        }), 500

# ============================================================================
# NEW DATABASE QUERY APIs
# ============================================================================

@app.route('/api/db/status')
def database_status():
    """Get comprehensive database status and health information"""
    try:
        db_path = config.DATABASE_PATH
        
        # Check if database file exists
        db_exists = os.path.exists(db_path)
        if not db_exists:
            return jsonify({
                'status': 'error',
                'error': 'Database file does not exist',
                'db_path': db_path,
                'exists': False
            }), 404
            
        # Get database file info
        db_stat = os.stat(db_path)
        db_size = db_stat.st_size
        db_modified = datetime.fromtimestamp(db_stat.st_mtime).isoformat()
        
        # Connect to database and get table info
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Get table information
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # Get record counts for each table
            table_info = {}
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                
                # Get latest record timestamp if applicable
                latest_timestamp = None
                if table in ['solar_data', 'system_status']:
                    try:
                        cursor.execute(f"SELECT MAX(timestamp) FROM {table}")
                        latest_result = cursor.fetchone()
                        if latest_result and latest_result[0]:
                            latest_timestamp = latest_result[0]
                    except:
                        pass
                
                table_info[table] = {
                    'record_count': count,
                    'latest_timestamp': latest_timestamp
                }
            
            # Get recent data collection activity (last hour)
            cursor.execute("""
                SELECT COUNT(*) FROM solar_data 
                WHERE timestamp > datetime('now', '-1 hour')
            """)
            recent_records = cursor.fetchone()[0]
            
            # Calculate data collection rate
            cursor.execute("""
                SELECT MIN(timestamp), MAX(timestamp), COUNT(*) 
                FROM solar_data 
                WHERE timestamp > datetime('now', '-24 hours')
            """)
            rate_result = cursor.fetchone()
            
            collection_rate = 0
            if rate_result and rate_result[0] and rate_result[1] and rate_result[2]:
                start_time = datetime.fromisoformat(rate_result[0])
                end_time = datetime.fromisoformat(rate_result[1])
                duration_hours = (end_time - start_time).total_seconds() / 3600
                if duration_hours > 0:
                    collection_rate = rate_result[2] / duration_hours
        
        return jsonify({
            'status': 'success',
            'database': {
                'path': db_path,
                'exists': True,
                'size_bytes': db_size,
                'size_mb': round(db_size / (1024 * 1024), 2),
                'last_modified': db_modified
            },
            'tables': table_info,
            'activity': {
                'recent_records_1h': recent_records,
                'collection_rate_per_hour': round(collection_rate, 1),
                'is_collecting': recent_records > 0
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/db/query')
def database_query():
    """Execute custom SQL queries on the database (READ-ONLY)"""
    try:
        query = request.args.get('sql', '').strip()
        if not query:
            return jsonify({
                'status': 'error',
                'error': 'No SQL query provided. Use ?sql=YOUR_QUERY'
            }), 400
        
        # Security: Only allow SELECT statements
        query_upper = query.upper().strip()
        if not query_upper.startswith('SELECT'):
            return jsonify({
                'status': 'error',
                'error': 'Only SELECT queries are allowed for security'
            }), 403
        
        # Prevent dangerous operations
        dangerous_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'ALTER', 'CREATE']
        if any(keyword in query_upper for keyword in dangerous_keywords):
            return jsonify({
                'status': 'error',
                'error': 'Query contains dangerous keywords'
            }), 403
        
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            
            # Get column names
            columns = [description[0] for description in cursor.description]
            
            # Get results
            rows = cursor.fetchall()
            
            # Convert to list of dictionaries
            results = []
            for row in rows:
                results.append(dict(zip(columns, row)))
        
        return jsonify({
            'status': 'success',
            'query': query,
            'columns': columns,
            'results': results,
            'count': len(results),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'query': query if 'query' in locals() else None,
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/db/tables')
def database_tables():
    """Get information about all database tables and their schemas"""
    try:
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Get all tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            table_names = [row[0] for row in cursor.fetchall()]
            
            tables_info = {}
            for table_name in table_names:
                # Get table schema
                cursor.execute(f"PRAGMA table_info({table_name})")
                schema = cursor.fetchall()
                
                # Get record count
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                
                # Get sample data (first 3 records)
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 3")
                sample_data = cursor.fetchall()
                
                tables_info[table_name] = {
                    'schema': [
                        {
                            'column': col[1],
                            'type': col[2],
                            'not_null': bool(col[3]),
                            'default': col[4],
                            'primary_key': bool(col[5])
                        }
                        for col in schema
                    ],
                    'record_count': count,
                    'sample_data': sample_data
                }
        
        return jsonify({
            'status': 'success',
            'tables': tables_info,
            'table_count': len(table_names),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/db/recent_data')
def recent_database_data():
    """Get recent data from the database with flexible filtering"""
    try:
        # Parameters
        table = request.args.get('table', 'solar_data')
        hours = int(request.args.get('hours', 1))
        limit = int(request.args.get('limit', 100))
        device_type = request.args.get('device_type', None)
        device_id = request.args.get('device_id', None)
        
        # Validate table name for security
        valid_tables = ['solar_data', 'system_status']
        if table not in valid_tables:
            return jsonify({
                'status': 'error',
                'error': f'Invalid table. Must be one of: {valid_tables}'
            }), 400
        
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Build query based on table and filters
            if table == 'solar_data':
                query = """
                    SELECT * FROM solar_data 
                    WHERE timestamp > datetime('now', '-{} hours')
                """.format(hours)
                
                params = []
                if device_type:
                    query += " AND device_type = ?"
                    params.append(device_type)
                    
                if device_id:
                    query += " AND device_id = ?"
                    params.append(device_id)
                    
                query += " ORDER BY timestamp DESC LIMIT ?"
                params.append(limit)
                
            else:  # system_status
                query = """
                    SELECT * FROM system_status 
                    WHERE timestamp > datetime('now', '-{} hours')
                    ORDER BY timestamp DESC LIMIT ?
                """.format(hours)
                params = [limit]
            
            cursor.execute(query, params)
            columns = [description[0] for description in cursor.description]
            rows = cursor.fetchall()
            
            # Convert to list of dictionaries
            results = []
            for row in rows:
                results.append(dict(zip(columns, row)))
        
        return jsonify({
            'status': 'success',
            'table': table,
            'filters': {
                'hours': hours,
                'limit': limit,
                'device_type': device_type,
                'device_id': device_id
            },
            'results': results,
            'count': len(results),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/db/stats')
def database_statistics():
    """Get comprehensive database statistics and analytics"""
    try:
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            stats = {}
            
            # Solar data statistics
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_records,
                    COUNT(DISTINCT device_id) as unique_devices,
                    COUNT(DISTINCT device_type) as device_types,
                    MIN(timestamp) as earliest_record,
                    MAX(timestamp) as latest_record,
                    AVG(power_kw) as avg_power,
                    MAX(power_kw) as max_power,
                    SUM(power_kw) as total_power
                FROM solar_data
            """)
            solar_stats = cursor.fetchone()
            
            if solar_stats:
                stats['solar_data'] = {
                    'total_records': solar_stats[0],
                    'unique_devices': solar_stats[1],
                    'device_types': solar_stats[2],
                    'earliest_record': solar_stats[3],
                    'latest_record': solar_stats[4],
                    'avg_power_kw': round(solar_stats[5] or 0, 3),
                    'max_power_kw': round(solar_stats[6] or 0, 3),
                    'total_power_kw': round(solar_stats[7] or 0, 3)
                }
            
            # Device type breakdown
            cursor.execute("""
                SELECT device_type, COUNT(*) as count, AVG(power_kw) as avg_power
                FROM solar_data 
                GROUP BY device_type 
                ORDER BY count DESC
            """)
            device_breakdown = cursor.fetchall()
            stats['device_breakdown'] = [
                {
                    'device_type': row[0],
                    'record_count': row[1],
                    'avg_power_kw': round(row[2] or 0, 3)
                }
                for row in device_breakdown
            ]
            
            # Recent activity (last 24 hours)
            cursor.execute("""
                SELECT 
                    COUNT(*) as records_24h,
                    AVG(power_kw) as avg_power_24h,
                    MAX(power_kw) as max_power_24h
                FROM solar_data 
                WHERE timestamp > datetime('now', '-24 hours')
            """)
            recent_stats = cursor.fetchone()
            
            if recent_stats:
                stats['recent_activity'] = {
                    'records_last_24h': recent_stats[0],
                    'avg_power_24h_kw': round(recent_stats[1] or 0, 3),
                    'max_power_24h_kw': round(recent_stats[2] or 0, 3),
                    'collection_rate_per_hour': round((recent_stats[0] or 0) / 24, 1)
                }
            
            # System status statistics
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_status_records,
                    AVG(total_production_kw) as avg_production,
                    MAX(total_production_kw) as max_production,
                    AVG(total_consumption_kw) as avg_consumption,
                    MAX(total_consumption_kw) as max_consumption
                FROM system_status
            """)
            system_stats = cursor.fetchone()
            
            if system_stats:
                stats['system_status'] = {
                    'total_records': system_stats[0],
                    'avg_production_kw': round(system_stats[1] or 0, 3),
                    'max_production_kw': round(system_stats[2] or 0, 3),
                    'avg_consumption_kw': round(system_stats[3] or 0, 3),
                    'max_consumption_kw': round(system_stats[4] or 0, 3)
                }
        
        return jsonify({
            'status': 'success',
            'statistics': stats,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

# ============================================================================
# DATA COLLECTION CONTROL APIs
# ============================================================================

@app.route('/api/collector/status')
def collector_status():
    """Get data collector status and health"""
    try:
        # Check if data collection is active by looking at recent database activity
        with sqlite3.connect(config.DATABASE_PATH) as conn:
            cursor = conn.cursor()
            
            # Check for recent data (last 5 minutes)
            cursor.execute("""
                SELECT COUNT(*) FROM solar_data 
                WHERE timestamp > datetime('now', '-5 minutes')
            """)
            recent_count = cursor.fetchone()[0]
            
            # Get latest record
            cursor.execute("""
                SELECT MAX(timestamp) FROM solar_data
            """)
            latest_timestamp = cursor.fetchone()[0]
            
            # Calculate time since last collection
            time_since_last = None
            if latest_timestamp:
                latest_dt = datetime.fromisoformat(latest_timestamp)
                time_since_last = (datetime.now() - latest_dt).total_seconds()
        
        # Test PVS connection
        pvs_online = pvs_client.test_connection()
        
        # Determine collector status
        is_collecting = recent_count > 0
        is_healthy = is_collecting and pvs_online and (time_since_last is None or time_since_last < 300)  # 5 minutes
        
        return jsonify({
            'status': 'success',
            'collector': {
                'is_collecting': is_collecting,
                'is_healthy': is_healthy,
                'recent_records_5min': recent_count,
                'latest_collection': latest_timestamp,
                'seconds_since_last': round(time_since_last) if time_since_last else None,
                'pvs_online': pvs_online,
                'poll_interval': config.POLL_INTERVAL_SECONDS
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/collector/test')
def test_data_collection():
    """Test data collection manually (single collection cycle)"""
    try:
        # Test PVS connection
        if not pvs_client.test_connection():
            return jsonify({
                'status': 'error',
                'error': 'Cannot connect to PVS6',
                'pvs_online': False
            }), 500
        
        # Get device data
        devices = pvs_client.get_device_list()
        if not devices:
            return jsonify({
                'status': 'error',
                'error': 'No device data received from PVS6',
                'pvs_online': True,
                'device_count': 0
            }), 500
        
        # Try to store one device's data as a test
        test_results = []
        for i, device in enumerate(devices[:3]):  # Test first 3 devices
            try:
                parsed_data = pvs_client.parse_device_data(device)
                solar_db.insert_solar_data(parsed_data)
                test_results.append({
                    'device_id': parsed_data.get('device_id', 'unknown'),
                    'device_type': parsed_data.get('device_type', 'unknown'),
                    'success': True,
                    'power_kw': parsed_data.get('power_kw', 0)
                })
            except Exception as e:
                test_results.append({
                    'device_id': device.get('DeviceID', 'unknown'),
                    'device_type': device.get('DeviceType', 'unknown'),
                    'success': False,
                    'error': str(e)
                })
        
        # Test system status storage
        try:
            system_summary = pvs_client.get_system_summary()
            solar_db.insert_system_status(system_summary)
            system_test = {'success': True, 'data': system_summary}
        except Exception as e:
            system_test = {'success': False, 'error': str(e)}
        
        successful_tests = sum(1 for result in test_results if result['success'])
        
        return jsonify({
            'status': 'success',
            'test_results': {
                'pvs_online': True,
                'total_devices': len(devices),
                'tested_devices': len(test_results),
                'successful_devices': successful_tests,
                'device_tests': test_results,
                'system_test': system_test
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

# ============================================================================
# EXISTING HISTORICAL DATA ROUTES (Enhanced)
# ============================================================================

@app.route('/api/historical_data')
def historical_data():
    """Get historical data for analysis (enhanced with better error handling)"""
    try:
        hours = int(request.args.get('hours', 24))
        
        # Try to get data from database
        try:
            data = solar_db.get_latest_data(hours=hours)
        except Exception as db_error:
            return jsonify({
                'data': [],
                'count': 0,
                'hours': hours,
                'error': f'Database error: {str(db_error)}',
                'suggestion': 'Check if data collection is running with /api/collector/status'
            }), 500
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'hours': hours,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'hours': hours if 'hours' in locals() else 24,
            'error': str(e),
            'status': 'error'
        }), 500

if __name__ == '__main__':
    print("🚀 Starting Enhanced Solar Monitor Dashboard")
    print("=" * 60)
    print(f"📊 Dashboard: http://0.0.0.0:5000")
    print(f"🗄️  Database APIs:")
    print(f"   Status: http://0.0.0.0:5000/api/db/status")
    print(f"   Query: http://0.0.0.0:5000/api/db/query?sql=SELECT * FROM solar_data LIMIT 10")
    print(f"   Tables: http://0.0.0.0:5000/api/db/tables")
    print(f"   Recent: http://0.0.0.0:5000/api/db/recent_data?hours=1")
    print(f"   Stats: http://0.0.0.0:5000/api/db/stats")
    print(f"🔧 Collector APIs:")
    print(f"   Status: http://0.0.0.0:5000/api/collector/status")
    print(f"   Test: http://0.0.0.0:5000/api/collector/test")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=False)
