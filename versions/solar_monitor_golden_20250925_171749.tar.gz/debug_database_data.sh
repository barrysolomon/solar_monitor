#!/bin/bash
echo "🔍 Debugging Database Data for Time Range Issues"
echo "=============================================="
echo ""

echo "📅 Current Pi Time:"
date
echo ""

echo "🗄️ Checking system_status table:"
echo "Recent records (last 10):"
sqlite3 /opt/solar_monitor/solar_data.db "
SELECT timestamp, total_production_kw, total_consumption_kw, net_export_kw 
FROM system_status 
ORDER BY timestamp DESC 
LIMIT 10;
"
echo ""

echo "📊 Count of records in last 4 hours:"
sqlite3 /opt/solar_monitor/solar_data.db "
SELECT COUNT(*) as record_count
FROM system_status 
WHERE timestamp > datetime('now', 'localtime', '-4 hours');
"
echo ""

echo "📈 Time range of data in last 4 hours:"
sqlite3 /opt/solar_monitor/solar_data.db "
SELECT 
    MIN(timestamp) as earliest,
    MAX(timestamp) as latest,
    COUNT(*) as count
FROM system_status 
WHERE timestamp > datetime('now', 'localtime', '-4 hours');
"
echo ""

echo "🕐 Testing timezone queries:"
echo "UTC now: $(sqlite3 /opt/solar_monitor/solar_data.db "SELECT datetime('now');")"
echo "Local now: $(sqlite3 /opt/solar_monitor/solar_data.db "SELECT datetime('now', 'localtime');")"
echo "4h ago UTC: $(sqlite3 /opt/solar_monitor/solar_data.db "SELECT datetime('now', '-4 hours');")"
echo "4h ago Local: $(sqlite3 /opt/solar_monitor/solar_data.db "SELECT datetime('now', 'localtime', '-4 hours');")"
echo ""

echo "🔍 Sample aggregation query (15-min intervals, last 4 hours):"
sqlite3 /opt/solar_monitor/solar_data.db "
SELECT
    datetime(
        (strftime('%s', timestamp) / (15 * 60)) * (15 * 60),
        'unixepoch'
    ) as time_bucket,
    AVG(total_production_kw) as avg_production,
    AVG(total_consumption_kw) as avg_consumption,
    COUNT(*) as record_count
FROM system_status
WHERE timestamp > datetime('now', 'localtime', '-4 hours')
  AND total_production_kw IS NOT NULL
  AND total_consumption_kw IS NOT NULL
GROUP BY time_bucket
ORDER BY time_bucket ASC;
"
