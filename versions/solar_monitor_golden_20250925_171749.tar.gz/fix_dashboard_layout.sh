#!/bin/bash

echo "🎨 CREATING IMPROVED DASHBOARD LAYOUT FIX"
echo "=========================================="

# Create the comprehensive dashboard template fix
cat > fix_dashboard_layout_complete.sh << 'EOF'
#!/bin/bash

echo "🎨 Applying comprehensive dashboard layout improvements..."

# Backup the original template
sudo cp /home/barry/solar_monitor/templates/dashboard.html /home/barry/solar_monitor/templates/dashboard.html.backup

# Create improved CSS section
cat > /tmp/improved_device_css.txt << 'CSS_END'
        /* IMPROVED DEVICE GRID LAYOUT */
        .device-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 20px;
            margin-top: 20px;
            padding: 0 10px;
        }

        .device-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border-left: 4px solid #3498db;
        }

        .device-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .device-card.pvs-gateway {
            border-left-color: #9b59b6;
        }

        .device-card.power-meter {
            border-left-color: #e74c3c;
        }

        .device-card.inverter {
            border-left-color: #27ae60;
        }

        .device-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ecf0f1;
        }

        .device-type {
            font-size: 1.1em;
            font-weight: 700;
            color: #2c3e50;
            margin: 0;
        }

        .device-status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: 600;
            text-transform: uppercase;
        }

        .device-status.working {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .device-status.offline {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .device-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            font-size: 0.9em;
        }

        .device-detail {
            display: flex;
            flex-direction: column;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 6px;
            border-left: 3px solid #3498db;
        }

        .device-label {
            color: #7f8c8d;
            font-weight: 600;
            font-size: 0.8em;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .device-value {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1em;
        }

        .device-serial {
            grid-column: 1 / -1;
            text-align: center;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            color: #7f8c8d;
            background: #ecf0f1;
            padding: 8px;
            border-radius: 4px;
            margin-top: 10px;
        }

        /* Mobile responsive */
        @media (max-width: 768px) {
            .device-grid {
                grid-template-columns: 1fr;
                gap: 15px;
                padding: 0 5px;
            }
            
            .device-details {
                grid-template-columns: 1fr;
                gap: 8px;
            }
            
            .device-type {
                font-size: 1em;
            }
        }
CSS_END

# Replace the existing device grid CSS
sudo sed -i '/\/\* Device Grid \*\//,/\.device-detail {/c\
        /* Device Grid */\
        .device-grid {\
            display: grid;\
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));\
            gap: 20px;\
            margin-top: 20px;\
            padding: 0 10px;\
        }' /home/barry/solar_monitor/templates/dashboard.html

# Update the JavaScript device rendering function
sudo sed -i '/card\.innerHTML = `/,/`;/c\
                            // Add device type class for styling\
                            let deviceClass = '\''device-card'\'';\
                            const deviceType = (device.device_type || '\''Unknown'\'').toLowerCase();\
                            if (deviceType.includes('\''pvs'\'') || deviceType.includes('\''gateway'\'')) {\
                                deviceClass += '\'' pvs-gateway'\'';\
                            } else if (deviceType.includes('\''meter'\'')) {\
                                deviceClass += '\'' power-meter'\'';\
                            } else if (deviceType.includes('\''inverter'\'')) {\
                                deviceClass += '\'' inverter'\'';\
                            }\
                            \
                            card.className = deviceClass;\
                            \
                            // Format values with proper units and precision\
                            const power = parseFloat(device.power_kw || 0).toFixed(2);\
                            const energy = parseFloat(device.energy_kwh || 0).toFixed(1);\
                            const voltage = parseFloat(device.voltage || 0).toFixed(1);\
                            const current = parseFloat(device.current || 0).toFixed(2);\
                            const temperature = device.temperature !== '\''N/A'\'' ? `${device.temperature}°C` : '\''N/A'\'';\
                            \
                            card.innerHTML = `\
                                <div class="device-header">\
                                    <h3 class="device-type">${device.device_type || '\''Unknown Device'\''}</h3>\
                                    <span class="device-status ${device.status === '\''working'\'' ? '\''working'\'' : '\''offline'\''}">\
                                        ${device.status || '\''Unknown'\''}\
                                    </span>\
                                </div>\
                                <div class="device-details">\
                                    <div class="device-detail">\
                                        <span class="device-label">Power Output</span>\
                                        <span class="device-value">${power} kW</span>\
                                    </div>\
                                    <div class="device-detail">\
                                        <span class="device-label">Total Energy</span>\
                                        <span class="device-value">${energy} kWh</span>\
                                    </div>\
                                    <div class="device-detail">\
                                        <span class="device-label">Voltage</span>\
                                        <span class="device-value">${voltage} V</span>\
                                    </div>\
                                    <div class="device-detail">\
                                        <span class="device-label">Current</span>\
                                        <span class="device-value">${current} A</span>\
                                    </div>\
                                    ${device.temperature !== '\''N/A'\'' ? `\
                                    <div class="device-detail">\
                                        <span class="device-label">Temperature</span>\
                                        <span class="device-value">${temperature}</span>\
                                    </div>\
                                    ` : '\'''\''}\
                                    ${device.model ? `\
                                    <div class="device-detail">\
                                        <span class="device-label">Model</span>\
                                        <span class="device-value">${device.model}</span>\
                                    </div>\
                                    ` : '\'''\''}\
                                </div>\
                                <div class="device-serial">\
                                    Serial: ${device.serial || '\''Unknown'\''}\
                                </div>\
                            `;' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Applied comprehensive dashboard improvements"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh"
echo ""
echo "🎨 New features:"
echo "   - Better grid layout with responsive design"
echo "   - Detailed panel data (Power, Energy, Voltage, Current, Temperature)"
echo "   - Color-coded device types"
echo "   - Improved mobile layout"
echo "   - Better visual hierarchy"
EOF

chmod +x fix_dashboard_layout_complete.sh
tar -czf fix_dashboard_layout.tar.gz fix_dashboard_layout_complete.sh

echo "📦 Dashboard layout fix package created!"
echo ""
echo "🔧 RUN THESE COMMANDS ON YOUR PI:"
echo "=================================="
echo ""
echo "# 1. Download the layout fix"
echo "wget http://192.168.1.128:8008/fix_dashboard_layout.tar.gz"
echo ""
echo "# 2. Extract and run the fix"
echo "tar -xzf fix_dashboard_layout.tar.gz"
echo "chmod +x fix_dashboard_layout_complete.sh"
echo "./fix_dashboard_layout_complete.sh"
echo ""
echo "# 3. Then refresh your browser with Ctrl+F5"
echo ""
echo "✨ This will create a much better layout with detailed panel information!"
