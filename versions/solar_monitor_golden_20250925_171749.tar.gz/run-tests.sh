#!/bin/bash
# SOLAR MONITOR TEST RUNNER

echo "🧪 SOLAR MONITOR TEST SUITE"
echo "==========================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Installing..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Install dependencies
echo "📦 Installing test dependencies..."
npm install

echo ""
echo "🔍 Running API Tests..."
echo "======================"
npm run test:api

echo ""
echo "🔗 Running Integration Tests..."
echo "=============================="
npm run test:integration

echo ""
echo "⚡ Running Performance Tests..."
echo "=============================="
npm run test:performance

echo ""
echo "🖥️  Running UI Tests..."
echo "====================="
npm run test:ui

echo ""
echo "📊 Generating Coverage Report..."
echo "==============================="
npm run test:coverage

echo ""
echo "🎯 TEST SUITE COMPLETE"
echo "======================"
echo "✅ All categories tested"
echo "✅ Coverage report generated"
echo "📁 Results in: ./coverage/"
