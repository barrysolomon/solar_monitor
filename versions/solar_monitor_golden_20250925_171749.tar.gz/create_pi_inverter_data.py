#!/usr/bin/env python3
"""
Create individual inverter time-series data on Pi based on existing system data
"""

import sqlite3
import random
from datetime import datetime

def create_individual_inverter_data():
    """Create time-series data for individual inverters based on system data"""
    
    # Connect to Pi database
    conn = sqlite3.connect('/opt/solar_monitor/solar_data.db')
    cursor = conn.cursor()
    
    # Get all system data records from the last 3 days
    cursor.execute("""
        SELECT timestamp, production_kw, consumption_kw 
        FROM solar_data 
        WHERE timestamp >= datetime('now', '-3 days')
        AND production_kw > 0
        ORDER BY timestamp
    """)
    
    system_records = cursor.fetchall()
    print(f"Found {len(system_records)} system records with production > 0")
    
    # Get list of inverter IDs
    inverter_ids = [f"INV{i:03d}" for i in range(1, 19)]  # INV001 to INV018
    
    # Clear existing time-series device data (keep only the original static records)
    cursor.execute("DELETE FROM device_data WHERE timestamp > '2025-09-24 20:30:00'")
    deleted_count = cursor.rowcount
    print(f"Cleared {deleted_count} existing time-series device records")
    
    records_created = 0
    
    for timestamp_str, total_production_kw, total_consumption_kw in system_records:
        # Distribute production across inverters with some variation
        base_production_per_inverter = total_production_kw / 18
        
        for i, inverter_id in enumerate(inverter_ids):
            # Add some realistic variation between inverters (some perform better than others)
            variation_factor = 0.8 + (i * 0.02) + random.uniform(-0.1, 0.1)  # 0.7 to 1.1 range
            inverter_production = base_production_per_inverter * variation_factor
            
            # Calculate other realistic values
            voltage = 240.0 + random.uniform(-5, 5)
            current_a = inverter_production * 1000 / voltage if voltage > 0 else 0
            frequency = 60.0 + random.uniform(-0.2, 0.2)
            temperature = 25.0 + (inverter_production * 8) + random.uniform(-3, 3)  # Temp increases with load
            status = 'working' if inverter_production > 0.05 else 'idle'
            
            # Insert record
            cursor.execute("""
                INSERT INTO device_data (timestamp, device_id, device_type, status, power_kw, voltage, current_a, frequency, temperature)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (timestamp_str, inverter_id, 'inverter', status, 
                  round(inverter_production, 3), round(voltage, 1), round(current_a, 2), 
                  round(frequency, 1), round(temperature, 1)))
            
            records_created += 1
            
            # Commit every 100 records to avoid memory issues
            if records_created % 100 == 0:
                conn.commit()
                print(f"Processed {records_created} records...")
    
    conn.commit()
    conn.close()
    
    print(f"✅ Created {records_created} individual inverter time-series records")
    print(f"📊 Each inverter now has ~{records_created // 18} time-series data points")

if __name__ == '__main__':
    print("🔧 Creating individual inverter time-series data on Pi")
    print("=" * 60)
    
    create_individual_inverter_data()
    
    print("\n✅ Individual inverter time-series data created!")
    print("🔌 device_data table now contains time-series records for each inverter")
    print("⏰ Data spans the last 3 days with realistic per-inverter variations")
    print("🎯 Device filter will now show multiple records per inverter over time")
