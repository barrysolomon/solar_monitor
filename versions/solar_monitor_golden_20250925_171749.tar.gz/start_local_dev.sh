#!/bin/bash

echo "🚀 STARTING LOCAL DEVELOPMENT ENVIRONMENT"
echo "========================================"

# Check if we're in the right directory
if [ ! -f "src/web_dashboard.py" ]; then
    echo "❌ Please run this from the solar_monitor project root directory"
    exit 1
fi

# Check if Pi is reachable
echo "📡 Testing connection to Pi..."
if curl -s --connect-timeout 5 http://192.168.1.126:5000/api/current_status > /dev/null; then
    echo "✅ Pi is reachable at 192.168.1.126:5000"
else
    echo "❌ Cannot reach Pi at 192.168.1.126:5000"
    echo "   Make sure your Pi is running and accessible"
    exit 1
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "🔧 Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install requirements
echo "📦 Installing requirements..."
pip install flask requests

echo ""
echo "🌐 Starting local development server..."
echo "   Dashboard: http://localhost:5001"
echo "   Debug: http://localhost:5001/debug/pi_status"
echo ""
echo "📡 Using real data from Pi: http://192.168.1.126:5000"
echo ""
echo "✨ You can now safely test dashboard improvements locally!"
echo "   Press Ctrl+C to stop the server"
echo ""

# Start the local development server
python3 local_dev_server.py
