#!/bin/bash

echo "🔧 SOLAR MONITOR DATA COLLECTION FIX"
echo "===================================="
echo "$(date)"
echo ""

# Function to print section headers
print_section() {
    echo ""
    echo "📍 $1"
    echo "----------------------------------------"
}

print_section "1. STOPPING EXISTING SERVICES"
sudo systemctl stop solar-data-collector.service 2>/dev/null || echo "Data collector service not running"
sudo systemctl stop solar-monitor.service 2>/dev/null || echo "Web dashboard service not running"

# Kill any hanging processes
sudo pkill -f data_collector.py 2>/dev/null || echo "No data collector processes to kill"
sudo pkill -f web_dashboard 2>/dev/null || echo "No web dashboard processes to kill"

print_section "2. INSTALLING REQUIRED PACKAGES"
echo "Updating package list..."
sudo apt update -qq

echo "Installing Python packages..."
sudo apt install -y python3-pip python3-venv python3-dev

echo "Installing Python modules..."
pip3 install --user requests flask schedule sqlite3 || echo "Some packages may already be installed"

print_section "3. CHECKING PVS6 CONNECTIVITY"
echo "Testing PVS6 connection..."
if ping -c 2 172.27.152.1 >/dev/null 2>&1; then
    echo "✅ PVS6 ping successful"
    
    if curl -s --connect-timeout 10 "http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList" | head -1 >/dev/null 2>&1; then
        echo "✅ PVS6 HTTP endpoint reachable"
    else
        echo "❌ PVS6 HTTP endpoint not reachable"
        echo "🔧 Attempting to reconnect WiFi..."
        sudo iwconfig wlan0 essid 'SunPower' 2>/dev/null || echo "WiFi reconnection failed"
        sleep 5
    fi
else
    echo "❌ Cannot ping PVS6"
    echo "🔧 Checking WiFi connection..."
    iwconfig 2>/dev/null | grep -i sunpower || echo "Not connected to SunPower WiFi"
fi

print_section "4. FIXING FILE PERMISSIONS"
echo "Setting correct ownership and permissions..."
sudo chown -R barry:barry /opt/solar_monitor/ 2>/dev/null || echo "Directory ownership already correct"
sudo chmod +x /opt/solar_monitor/src/data_collector.py 2>/dev/null || echo "data_collector.py already executable"
sudo chmod 664 /opt/solar_monitor/solar_data.db 2>/dev/null || echo "Database permissions already correct"

print_section "5. CREATING/UPDATING DATA COLLECTOR SERVICE"
echo "Creating systemd service file..."
sudo tee /etc/systemd/system/solar-data-collector.service > /dev/null << 'EOF'
[Unit]
Description=Solar Data Collector
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=barry
Group=barry
WorkingDirectory=/opt/solar_monitor
Environment=PYTHONPATH=/opt/solar_monitor
Environment=PYTHONUNBUFFERED=1
ExecStart=/usr/bin/python3 /opt/solar_monitor/src/data_collector.py
Restart=always
RestartSec=30
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

print_section "6. CREATING/UPDATING WEB DASHBOARD SERVICE"
echo "Creating web dashboard service file..."
sudo tee /etc/systemd/system/solar-monitor.service > /dev/null << 'EOF'
[Unit]
Description=Solar Monitor Web Dashboard
After=network.target solar-data-collector.service
Wants=network-online.target

[Service]
Type=simple
User=barry
Group=barry
WorkingDirectory=/opt/solar_monitor
Environment=PYTHONPATH=/opt/solar_monitor
Environment=PYTHONUNBUFFERED=1
ExecStart=/usr/bin/python3 /opt/solar_monitor/web_dashboard_cached_simple.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

print_section "7. RELOADING SYSTEMD AND ENABLING SERVICES"
sudo systemctl daemon-reload
sudo systemctl enable solar-data-collector.service
sudo systemctl enable solar-monitor.service

print_section "8. TESTING DATA COLLECTOR MANUALLY"
echo "Testing data collector connection..."
cd /opt/solar_monitor
timeout 30 python3 src/data_collector.py --test 2>&1 | head -10 || echo "Manual test completed (may have timed out)"

print_section "9. STARTING SERVICES"
echo "Starting data collector service..."
sudo systemctl start solar-data-collector.service
sleep 5

echo "Starting web dashboard service..."
sudo systemctl start solar-monitor.service
sleep 3

print_section "10. CHECKING SERVICE STATUS"
echo "Data collector status:"
sudo systemctl status solar-data-collector.service --no-pager -l | head -15

echo ""
echo "Web dashboard status:"
sudo systemctl status solar-monitor.service --no-pager -l | head -15

print_section "11. TESTING API ENDPOINTS"
echo "Waiting for services to fully start..."
sleep 10

echo "Testing current status API:"
curl -s --connect-timeout 10 "http://localhost:5000/api/current_status" | head -5 2>/dev/null && echo "✅ API responding" || echo "❌ API not responding yet"

print_section "12. CHECKING DATABASE"
if [ -f "/opt/solar_monitor/solar_data.db" ]; then
    echo "Database exists, checking recent data..."
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) FROM solar_data WHERE timestamp > datetime('now', '-1 hour');" 2>/dev/null && echo "Recent solar data found" || echo "No recent solar data yet"
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) FROM system_status WHERE timestamp > datetime('now', '-1 hour');" 2>/dev/null && echo "Recent system status found" || echo "No recent system status yet"
else
    echo "Database will be created automatically by the data collector"
fi

print_section "SUMMARY"
echo "🎯 DATA COLLECTION FIX COMPLETE!"
echo ""
echo "✅ Services should now be running:"
echo "   - solar-data-collector.service (collects data every 30 seconds)"
echo "   - solar-monitor.service (web dashboard on port 5000)"
echo ""
echo "🔍 To monitor progress:"
echo "   sudo journalctl -u solar-data-collector.service -f"
echo "   sudo journalctl -u solar-monitor.service -f"
echo ""
echo "🌐 Web dashboard should be available at:"
echo "   http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "⏱️  Data collection starts immediately and runs every 30 seconds"
echo "   First data should appear within 1-2 minutes"
echo ""
echo "🔧 If issues persist, run the diagnostic script:"
echo "   bash diagnose_data_collection.sh"
echo ""
echo "===================================="
echo "Fix completed: $(date)"
