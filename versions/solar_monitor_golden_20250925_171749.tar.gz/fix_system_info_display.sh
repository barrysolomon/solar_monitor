#!/bin/bash

echo "📊 Fixing system information display..."

# The system info panel is not getting updated with device counts
# Let's check what's in the current template and fix the JavaScript

echo "🔍 Checking current system info JavaScript..."
grep -n "Total Inverters\|Working Inverters" /home/barry/solar_monitor/templates/dashboard.html

echo ""
echo "🔧 The issue is likely that the JavaScript is not properly updating the inverter counts"
echo "Let's check what APIs are being called for system info..."

# Check what the current status API returns
echo "📊 Current API data:"
curl -s http://192.168.1.126:5000/api/current_status | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print('Current Status API:')
    for key, value in data.items():
        print(f'  {key}: {value}')
except:
    print('Error parsing current status API')
"

echo ""
curl -s http://192.168.1.126:5000/api/device_details | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    devices = data.get('devices', [])
    inverters = [d for d in devices if 'inverter' in d.get('device_type', '').lower()]
    working_inverters = [d for d in inverters if d.get('status') == 'working']
    
    print('Device Details API Summary:')
    print(f'  Total Devices: {len(devices)}')
    print(f'  Total Inverters: {len(inverters)}')
    print(f'  Working Inverters: {len(working_inverters)}')
    print(f'  Working Count from API: {data.get(\"working_count\", \"Not provided\")}')
except Exception as e:
    print(f'Error parsing device details API: {e}')
"

echo ""
echo "🔧 The system info panel needs to be updated to use the device_details API"
echo "   to get accurate inverter counts."
echo ""
echo "📋 Current system shows:"
echo "   - PVS6 Status: Connected ✅"
echo "   - System Status: Online ✅" 
echo "   - Total Inverters: 0 ❌ (should be 18)"
echo "   - Working Inverters: 0 ❌ (should be 18)"
echo ""
echo "💡 The fix would be to update the JavaScript to call /api/device_details"
echo "   and count the inverters properly."
