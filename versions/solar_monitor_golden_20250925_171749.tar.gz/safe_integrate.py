#!/usr/bin/env python3
"""
Safe integration script - test before applying
"""
import os
import sys
import shutil
import subprocess
import time

def test_current_system():
    """Test if current system is working"""
    try:
        import requests
        response = requests.get('http://localhost:5000/api/current_status', timeout=5)
        return response.status_code == 200
    except:
        return False

def test_isolated_module():
    """Test the isolated module works"""
    try:
        # Start isolated module on port 5001
        proc = subprocess.Popen([
            'python3', '/opt/solar_monitor/status_api_module.py'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        time.sleep(2)  # Let it start
        
        import requests
        response = requests.get('http://localhost:5001/api/system/collector-status', timeout=5)
        
        proc.terminate()
        return response.status_code == 200
    except:
        return False

def rollback_to_backup():
    """Rollback to the latest backup"""
    backup_dir = '/opt/solar_monitor/safe_backups'
    backups = [d for d in os.listdir(backup_dir) if d.startswith('working_system_')]
    if not backups:
        print("No backups found!")
        return False
    
    latest_backup = sorted(backups)[-1]
    backup_path = f"{backup_dir}/{latest_backup}"
    
    print(f"Rolling back to {latest_backup}...")
    
    # Restore files
    critical_files = [
        'web_dashboard_cached_simple.py',
        'templates/dashboard.html'
    ]
    
    for file in critical_files:
        src = f"{backup_path}/{file}"
        dst = f"/opt/solar_monitor/{file}"
        if os.path.exists(src):
            shutil.copy2(src, dst)
            print(f"   ✅ Restored {file}")
    
    return True

def safe_integrate():
    """Safely integrate modules"""
    print("🧪 Testing current system...")
    if not test_current_system():
        print("❌ Current system not working, aborting")
        return False
    print("✅ Current system OK")
    
    print("🧪 Testing isolated module...")
    if not test_isolated_module():
        print("❌ Isolated module not working, aborting")
        return False
    print("✅ Isolated module OK")
    
    print("🔧 Attempting safe integration...")
    
    # Try to add the missing collector API to main app
    try:
        # Read current main app
        with open('/opt/solar_monitor/web_dashboard_cached_simple.py', 'r') as f:
            content = f.read()
        
        # Check if collector API already exists
        if '/api/system/collector-status' in content:
            print("✅ Collector API already exists")
            return True
        
        # Add collector API safely at the end
        collector_api = """
@app.route('/api/system/collector-status')
def safe_collector_status():
    try:
        import subprocess
        result = subprocess.run(['systemctl', 'is-active', 'solar-data-collector.service'],
                              capture_output=True, text=True, timeout=5)
        is_running = result.returncode == 0 and result.stdout.strip() == 'active'
        return jsonify({
            'status': 'running' if is_running else 'stopped',
            'success': is_running
        })
    except Exception as e:
        return jsonify({'status': 'error', 'success': False, 'error': str(e)})
"""
        
        # Find safe insertion point (before if __name__)
        if "if __name__ == '__main__':" in content:
            insert_pos = content.find("if __name__ == '__main__':")
            new_content = content[:insert_pos] + collector_api + "\n" + content[insert_pos:]
        else:
            new_content = content + collector_api
        
        # Write safely
        with open('/opt/solar_monitor/web_dashboard_cached_simple.py', 'w') as f:
            f.write(new_content)
        
        print("✅ Added collector API safely")
        
        # Test the integration
        subprocess.run(['sudo', 'systemctl', 'restart', 'solar-monitor.service'])
        time.sleep(3)
        
        if test_current_system():
            print("✅ Integration successful!")
            return True
        else:
            print("❌ Integration failed, rolling back...")
            rollback_to_backup()
            subprocess.run(['sudo', 'systemctl', 'restart', 'solar-monitor.service'])
            return False
            
    except Exception as e:
        print(f"❌ Integration error: {e}")
        print("🔄 Rolling back...")
        rollback_to_backup()
        subprocess.run(['sudo', 'systemctl', 'restart', 'solar-monitor.service'])
        return False

if __name__ == "__main__":
    safe_integrate()
