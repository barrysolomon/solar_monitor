#!/bin/bash
echo "🚀 Simple Code-Only Deployment v2.0.24"
echo "======================================="

cd /home/barry

echo "📦 Downloading v2.0.24 (Page-Aware Refresh)..."
wget -O solar_monitor_v2.0.24_page_aware_refresh.tar.gz http://192.168.1.169:8009/solar_monitor_v2.0.24_page_aware_refresh.tar.gz

echo "🛑 Stopping services..."
sudo systemctl stop solar-monitor.service
sudo systemctl stop solar-data-collector.service

echo "📁 Extracting files..."
rm -rf temp_deploy
mkdir temp_deploy
cd temp_deploy
tar -xzf ../solar_monitor_v2.0.24_page_aware_refresh.tar.gz

echo "🔄 Updating code files only (database untouched)..."
sudo cp web_dashboard_cached_simple.py /opt/solar_monitor/
sudo cp -r src/* /opt/solar_monitor/src/
sudo cp -r templates/* /opt/solar_monitor/templates/

echo "🔧 Configuring update server..."
# Get the IP of the deployment server (where we downloaded from)
DEPLOY_SERVER_IP=$(echo "http://192.168.1.169:8009/solar_monitor_v2.0.24_page_aware_refresh.tar.gz" | sed -n 's|.*://\([^:]*\):.*|\1|p')
echo "📡 Setting update server to: $DEPLOY_SERVER_IP:8009"

# Update any remaining old server references in the deployed files
sudo sed -i "s/192\.168\.1\.128:8008/$DEPLOY_SERVER_IP:8009/g" /opt/solar_monitor/web_dashboard_cached_simple.py
sudo sed -i "s/192\.168\.1\.128:8008/$DEPLOY_SERVER_IP:8009/g" /opt/solar_monitor/templates/dashboard.html

echo "🔧 Setting permissions..."
sudo chown -R barry:barry /opt/solar_monitor

echo "🚀 Starting services..."
sudo systemctl start solar-monitor.service
sudo systemctl start solar-data-collector.service

echo "🧹 Cleanup..."
cd /home/barry
rm -rf temp_deploy

echo ""
echo "✅ Simple deployment complete!"
echo "📊 Database preserved - no data lost"
echo "🔧 Only code files updated"
echo "🔄 Update server configured: $DEPLOY_SERVER_IP:8009"
echo "🌐 Access your dashboard at: http://$(hostname -I | awk '{print $1}'):5000"
