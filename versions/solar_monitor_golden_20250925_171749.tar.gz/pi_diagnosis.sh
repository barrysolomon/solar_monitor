#!/bin/bash

echo "🔍 DIAGNOSING VERSION LOADING ISSUE"
echo "=================================="

echo "📍 Step 1: Check installed version file"
cat /opt/solar_monitor/src/version.py | grep -A 5 -B 5 "build"

echo ""
echo "📍 Step 2: Check service status"
sudo systemctl status solar-monitor.service --no-pager -l | tail -10

echo ""
echo "📍 Step 3: Check if service is using correct directory"
ps aux | grep web_dashboard_cached_simple.py

echo ""
echo "📍 Step 4: Test API version endpoint directly"
curl -s http://localhost:5000/api/version/current

echo ""
echo "📍 Step 5: Check service logs for errors"
sudo journalctl -u solar-monitor.service --no-pager -l | tail -20

echo ""
echo "📍 Step 6: Restart service to force reload"
sudo systemctl restart solar-monitor.service
sleep 3

echo ""
echo "📍 Step 7: Test API again after restart"
curl -s http://localhost:5000/api/version/current

echo ""
echo "📍 Step 8: Check if there are multiple Python processes"
ps aux | grep python | grep -v grep
