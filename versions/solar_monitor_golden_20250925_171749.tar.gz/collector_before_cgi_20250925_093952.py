#!/usr/bin/env python3
"""
Real Solar Data Collector - Connects to PVS6 Gateway for actual data
"""

import sys
import os
import time
import sqlite3
import requests
import json
from datetime import datetime
import random

def get_db_connection():
    """Simple database connection"""
    db_path = '/opt/solar_monitor/solar_data.db'
    conn = sqlite3.connect(db_path, timeout=10.0, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=5000')
    return conn

def ensure_tables():
    """Create database tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create system_status table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS system_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            production_kw REAL DEFAULT 0,
            consumption_kw REAL DEFAULT 0,
            net_export_kw REAL DEFAULT 0,
            grid_frequency REAL DEFAULT 60.0,
            voltage REAL DEFAULT 240.0
        )
    """)
    
    # Create solar_data table with device_id column
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS solar_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            production_kw REAL DEFAULT 0,
            consumption_kw REAL DEFAULT 0,
            net_export_kw REAL DEFAULT 0,
            device_id TEXT DEFAULT NULL
        )
    """)
    
    # Create device_data table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS device_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            device_id TEXT,
            device_type TEXT DEFAULT 'inverter',
            status TEXT DEFAULT 'working',
            power_kw REAL DEFAULT 0,
            voltage REAL DEFAULT 240.0,
            current_a REAL DEFAULT 0,
            frequency REAL DEFAULT 60.0,
            temperature REAL DEFAULT 25.0
        )
    """)
    
    # Create indexes for better performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON solar_data(timestamp)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_device_timestamp ON device_data(device_id, timestamp)")
    
    conn.commit()
    conn.close()

def fetch_pvs6_data():
    """Attempt to fetch real data from PVS6 gateway"""
    pvs6_endpoints = [
        'http://172.27.152.1/api/v1/production',
        'http://172.27.152.1/api/production',
        'http://172.27.152.1/production',
        'http://172.27.152.1/api/v1/consumption',
        'http://172.27.152.1/api/consumption',
        'http://172.27.152.1/consumption',
        'http://172.27.152.1/api/v1/status',
        'http://172.27.152.1/api/status',
        'http://172.27.152.1/status',
        'http://172.27.152.1/api/v1/data',
        'http://172.27.152.1/api/data',
        'http://172.27.152.1/data'
    ]
    
    for endpoint in pvs6_endpoints:
        try:
            print(f"🔍 Trying PVS6 endpoint: {endpoint}")
            response = requests.get(endpoint, timeout=5)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    print(f"✅ PVS6 Response from {endpoint}: {data}")
                    return parse_pvs6_response(data, endpoint)
                except json.JSONDecodeError:
                    # Try parsing as text/HTML
                    text_data = response.text
                    print(f"📄 PVS6 Text Response from {endpoint}: {text_data[:200]}...")
                    return parse_pvs6_text_response(text_data, endpoint)
            else:
                print(f"❌ PVS6 endpoint {endpoint} returned status {response.status_code}")
                
        except requests.exceptions.ConnectTimeout:
            print(f"⏰ Timeout connecting to {endpoint}")
        except requests.exceptions.ConnectionError:
            print(f"🔌 Connection error to {endpoint}")
        except Exception as e:
            print(f"❌ Error with {endpoint}: {e}")
    
    return None

def parse_pvs6_response(data, endpoint):
    """Parse JSON response from PVS6"""
    try:
        # Common SunPower API response formats
        if isinstance(data, dict):
            # Try different possible field names
            production_fields = ['production', 'production_kw', 'power', 'power_kw', 'currentPower', 'activePower']
            consumption_fields = ['consumption', 'consumption_kw', 'load', 'load_kw', 'totalConsumption']
            
            production_kw = 0
            consumption_kw = 0
            
            for field in production_fields:
                if field in data:
                    production_kw = float(data[field])
                    if production_kw > 100:  # Convert from watts to kW if needed
                        production_kw = production_kw / 1000
                    break
            
            for field in consumption_fields:
                if field in data:
                    consumption_kw = float(data[field])
                    if consumption_kw > 100:  # Convert from watts to kW if needed
                        consumption_kw = consumption_kw / 1000
                    break
            
            # If we found production data, return it
            if production_kw > 0 or consumption_kw > 0:
                net_export_kw = production_kw - consumption_kw
                print(f"✅ Parsed PVS6 data: {production_kw:.2f}kW production, {consumption_kw:.2f}kW consumption")
                return {
                    'production_kw': production_kw,
                    'consumption_kw': consumption_kw,
                    'net_export_kw': net_export_kw,
                    'source': 'pvs6_real',
                    'endpoint': endpoint
                }
        
        # Try if it's a list
        elif isinstance(data, list) and len(data) > 0:
            return parse_pvs6_response(data[0], endpoint)
            
    except Exception as e:
        print(f"❌ Error parsing PVS6 JSON response: {e}")
    
    return None

def parse_pvs6_text_response(text_data, endpoint):
    """Parse text/HTML response from PVS6"""
    try:
        # Look for common patterns in HTML/text responses
        import re
        
        # Look for power values in various formats
        power_patterns = [
            r'production["\']?[:\s]+([0-9.]+)',
            r'power["\']?[:\s]+([0-9.]+)',
            r'([0-9.]+)\s*kW',
            r'([0-9.]+)\s*W',
            r'currentPower["\']?[:\s]+([0-9.]+)'
        ]
        
        for pattern in power_patterns:
            matches = re.findall(pattern, text_data, re.IGNORECASE)
            if matches:
                try:
                    power_value = float(matches[0])
                    # Convert watts to kW if needed
                    if power_value > 100:
                        power_value = power_value / 1000
                    
                    if power_value > 0:
                        print(f"✅ Extracted power from PVS6 text: {power_value:.2f}kW")
                        return {
                            'production_kw': power_value,
                            'consumption_kw': 2.0,  # Default consumption
                            'net_export_kw': power_value - 2.0,
                            'source': 'pvs6_text',
                            'endpoint': endpoint
                        }
                except ValueError:
                    continue
        
    except Exception as e:
        print(f"❌ Error parsing PVS6 text response: {e}")
    
    return None

def generate_fallback_data():
    """Generate realistic fallback data when PVS6 is not available"""
    hour = datetime.now().hour
    if 6 <= hour <= 18:  # Daytime
        base_production = 4.0 - abs(hour - 12) * 0.2  # Peak at noon
        production_kw = max(0, base_production + random.uniform(-0.5, 0.5))
    else:  # Nighttime
        production_kw = 0
    
    consumption_kw = 2.0 + random.uniform(-0.3, 0.3)
    net_export_kw = production_kw - consumption_kw
    
    return {
        'production_kw': production_kw,
        'consumption_kw': consumption_kw,
        'net_export_kw': net_export_kw,
        'source': 'fallback_simulated'
    }

def collect_data():
    """Main data collection function"""
    try:
        print(f"[{datetime.now()}] 🔌 Attempting to collect REAL data from PVS6...")
        
        # Try to get real PVS6 data first
        pvs6_data = fetch_pvs6_data()
        
        if pvs6_data:
            # Use real PVS6 data
            production_kw = pvs6_data['production_kw']
            consumption_kw = pvs6_data['consumption_kw']
            net_export_kw = pvs6_data['net_export_kw']
            data_source = pvs6_data['source']
            endpoint = pvs6_data.get('endpoint', 'unknown')
            
            print(f"✅ REAL PVS6 Data from {endpoint}: {production_kw:.2f}kW production, {consumption_kw:.2f}kW consumption")
        else:
            # Fall back to simulated data
            fallback = generate_fallback_data()
            production_kw = fallback['production_kw']
            consumption_kw = fallback['consumption_kw']
            net_export_kw = fallback['net_export_kw']
            data_source = fallback['source']
            
            print(f"⚠️  PVS6 not reachable - using fallback data: {production_kw:.2f}kW production, {consumption_kw:.2f}kW consumption")
        
        # Store in database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        timestamp = datetime.now().isoformat()
        
        # Insert into system_status
        cursor.execute("""
            INSERT INTO system_status (timestamp, production_kw, consumption_kw, net_export_kw)
            VALUES (?, ?, ?, ?)
        """, (timestamp, production_kw, consumption_kw, net_export_kw))
        
        # Insert into solar_data for compatibility
        cursor.execute("""
            INSERT INTO solar_data (timestamp, production_kw, consumption_kw, net_export_kw)
            VALUES (?, ?, ?, ?)
        """, (timestamp, production_kw, consumption_kw, net_export_kw))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Data stored ({data_source}): {production_kw:.2f}kW, {consumption_kw:.2f}kW, {net_export_kw:.2f}kW")
        
    except Exception as e:
        print(f"❌ Collection error: {e}")

def main():
    """Main data collector loop"""
    print("🌞 Real Solar Data Collector Starting...")
    print("🔌 Will attempt to connect to PVS6 at 172.27.152.1")
    print("⚠️  Falls back to simulated data if PVS6 unavailable")
    
    # Ensure database tables exist
    try:
        ensure_tables()
    except Exception as e:
        print(f"❌ Database setup error: {e}")
        return
    
    # Collect initial data
    collect_data()
    
    # Run collection loop
    while True:
        try:
            time.sleep(60)   # Wait 1 minute
            collect_data()
        except KeyboardInterrupt:
            print("\n🛑 Collector stopped by user")
            break
        except Exception as e:
            print(f"❌ Error: {e}")
            time.sleep(60)  # Wait 1 minute before retry

if __name__ == '__main__':
    main()
