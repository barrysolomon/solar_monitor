#!/bin/bash
# Find Raspberry Pi on the network

echo "🔍 FINDING RASPBERRY PI ON NETWORK"
echo "=================================="
echo ""

# Get the current network
NETWORK=$(ip route | grep default | awk '{print $3}' | head -1 | sed 's/\.[0-9]*$/.0\/24/')

if [ -z "$NETWORK" ]; then
    # Fallback to common networks
    NETWORKS=("192.168.1.0/24" "192.168.0.0/24" "10.0.0.0/24")
else
    NETWORKS=("$NETWORK")
fi

echo "Scanning networks: ${NETWORKS[*]}"
echo ""

for network in "${NETWORKS[@]}"; do
    echo "Scanning $network..."
    
    # Use nmap if available, otherwise use ping
    if command -v nmap >/dev/null 2>&1; then
        nmap -sn "$network" 2>/dev/null | grep -B2 -i "raspberry\|pi" | grep -E "Nmap scan report|MAC Address" | while read line; do
            if [[ $line == *"Nmap scan report"* ]]; then
                IP=$(echo "$line" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}')
                echo "Found Pi at: $IP"
            fi
        done
    else
        echo "nmap not found, using basic ping scan..."
        for i in {1..254}; do
            IP="${network%.*}.$i"
            if ping -c 1 -W 1 "$IP" >/dev/null 2>&1; then
                echo "Active host: $IP"
            fi
        done
    fi
done

echo ""
echo "💡 To test SSH connection to a Pi:"
echo "   ssh barry@<IP_ADDRESS>"
echo ""
echo "🚀 To deploy Solar Monitor:"
echo "   ./deploy_to_pi.sh <IP_ADDRESS>"
