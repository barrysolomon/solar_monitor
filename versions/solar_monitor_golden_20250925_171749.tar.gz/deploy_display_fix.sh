#!/bin/bash

echo "🎨 DEPLOYING DEVICE DISPLAY FIX TO RASPBERRY PI"
echo "==============================================="

PI_IP="192.168.1.126"
COMPUTER_IP="192.168.1.128"  # Correct IP
HTTP_PORT="8008"

echo "📦 Creating deployment package..."
tar -czf fix_device_display.tar.gz web_dashboard_fixed.py

echo "📡 Making fix available via HTTP..."
echo "✅ Fix available at: http://${COMPUTER_IP}:${HTTP_PORT}/fix_device_display.tar.gz"

echo ""
echo "🔧 RUN THESE COMMANDS ON YOUR PI:"
echo "=================================="
echo ""
echo "# 1. Download the fix"
echo "wget http://${COMPUTER_IP}:${HTTP_PORT}/fix_device_display.tar.gz"
echo ""
echo "# 2. Extract and install"
echo "tar -xzf fix_device_display.tar.gz"
echo "sudo cp web_dashboard_fixed.py /home/barry/solar_monitor/src/web_dashboard.py"
echo ""
echo "# 3. Restart the service"
echo "sudo systemctl restart solar-monitor.service"
echo ""
echo "# 4. Test the fix"
echo "curl -s http://192.168.1.126:5000/api/device_details | head -20"
echo ""
echo "🌐 Then check your dashboard: http://192.168.1.126:5000"
echo ""
echo "✨ This fix will:"
echo "   - Show proper device types instead of 'Unknown'"
echo "   - Reduce font sizes for better display"
echo "   - Improve responsive layout for all panel data"
