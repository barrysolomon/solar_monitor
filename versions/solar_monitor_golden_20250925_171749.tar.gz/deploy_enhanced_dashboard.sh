#!/bin/bash

echo "🚀 DEPLOYING ENHANCED DASHBOARD WITH DATABASE APIs"
echo "=================================================="

PI_IP="192.168.1.126"
COMPUTER_IP="192.168.1.128"
HTTP_PORT="8008"

# Create deployment package
echo "📦 Creating deployment package..."
tar -czf enhanced_dashboard.tar.gz \
    web_dashboard_with_db_apis.py \
    templates/dashboard.html

echo "✅ Package created: enhanced_dashboard.tar.gz"

# Start HTTP server in background if not running
if ! pgrep -f "python3 -m http.server $HTTP_PORT" > /dev/null; then
    echo "🌐 Starting HTTP server on port $HTTP_PORT..."
    python3 -m http.server $HTTP_PORT &
    sleep 2
fi

echo "📡 HTTP server running at http://$COMPUTER_IP:$HTTP_PORT"

# Deploy to Pi
echo "🚀 Deploying to Pi at $PI_IP..."

cat << 'EOF' > /tmp/deploy_enhanced.sh
#!/bin/bash

COMPUTER_IP="192.168.1.128"
HTTP_PORT="8008"

echo "📥 Downloading enhanced dashboard..."
cd /home/pi
wget -O enhanced_dashboard.tar.gz "http://${COMPUTER_IP}:${HTTP_PORT}/enhanced_dashboard.tar.gz"

if [ $? -ne 0 ]; then
    echo "❌ Download failed"
    exit 1
fi

echo "📦 Extracting package..."
tar -xzf enhanced_dashboard.tar.gz

echo "🔄 Backing up current dashboard..."
sudo cp /home/pi/solar_monitor/src/web_dashboard.py /home/pi/solar_monitor/src/web_dashboard.py.backup

echo "🔧 Installing enhanced dashboard..."
sudo cp web_dashboard_with_db_apis.py /home/pi/solar_monitor/src/web_dashboard.py

echo "🔄 Restarting solar-monitor service..."
sudo systemctl restart solar-monitor.service

echo "⏳ Waiting for service to start..."
sleep 5

echo "🔍 Checking service status..."
sudo systemctl status solar-monitor.service --no-pager -l

echo "🧪 Testing new APIs..."
echo "📊 Database Status:"
curl -s http://localhost:5000/api/db/status | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f'  Status: {data.get(\"status\", \"unknown\")}')
    if data.get('database'):
        db = data['database']
        print(f'  Database: {db.get(\"size_mb\", 0)} MB')
        print(f'  Tables: {len(data.get(\"tables\", {}))}')
    if data.get('activity'):
        act = data['activity']
        print(f'  Recent Records: {act.get(\"recent_records_1h\", 0)}')
        print(f'  Collection Rate: {act.get(\"collection_rate_per_hour\", 0)}/hour')
        print(f'  Is Collecting: {act.get(\"is_collecting\", False)}')
except Exception as e:
    print(f'  Error: {e}')
"

echo ""
echo "🔧 Collector Status:"
curl -s http://localhost:5000/api/collector/status | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f'  Status: {data.get(\"status\", \"unknown\")}')
    if data.get('collector'):
        col = data['collector']
        print(f'  Is Collecting: {col.get(\"is_collecting\", False)}')
        print(f'  Is Healthy: {col.get(\"is_healthy\", False)}')
        print(f'  PVS Online: {col.get(\"pvs_online\", False)}')
        print(f'  Recent Records: {col.get(\"recent_records_5min\", 0)}')
        if col.get('seconds_since_last'):
            print(f'  Last Collection: {col.get(\"seconds_since_last\")} seconds ago')
except Exception as e:
    print(f'  Error: {e}')
"

echo ""
echo "📈 Testing Historical Data:"
curl -s "http://localhost:5000/api/historical_data?hours=1" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f'  Status: {data.get(\"status\", \"unknown\")}')
    print(f'  Data Points: {data.get(\"count\", 0)}')
    if data.get('error'):
        print(f'  Error: {data[\"error\"]}')
    if data.get('suggestion'):
        print(f'  Suggestion: {data[\"suggestion\"]}')
except Exception as e:
    print(f'  Error: {e}')
"

echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo "🌐 Enhanced Dashboard APIs available at:"
echo "   http://192.168.1.126:5000/api/db/status"
echo "   http://192.168.1.126:5000/api/db/query?sql=SELECT * FROM solar_data LIMIT 5"
echo "   http://192.168.1.126:5000/api/db/tables"
echo "   http://192.168.1.126:5000/api/db/recent_data?hours=1"
echo "   http://192.168.1.126:5000/api/db/stats"
echo "   http://192.168.1.126:5000/api/collector/status"
echo "   http://192.168.1.126:5000/api/collector/test"

# Cleanup
rm -f enhanced_dashboard.tar.gz web_dashboard_with_db_apis.py
EOF

# Copy deployment script to Pi and execute
scp /tmp/deploy_enhanced.sh pi@$PI_IP:/tmp/
ssh pi@$PI_IP "chmod +x /tmp/deploy_enhanced.sh && /tmp/deploy_enhanced.sh"

echo ""
echo "🎉 ENHANCED DASHBOARD DEPLOYED!"
echo "==============================================="
echo "📊 Dashboard: http://$PI_IP:5000"
echo ""
echo "🗄️  NEW DATABASE APIs:"
echo "   📋 Status: http://$PI_IP:5000/api/db/status"
echo "   🔍 Query: http://$PI_IP:5000/api/db/query?sql=SELECT * FROM solar_data LIMIT 10"
echo "   📊 Tables: http://$PI_IP:5000/api/db/tables"
echo "   📈 Recent: http://$PI_IP:5000/api/db/recent_data?hours=1"
echo "   📉 Stats: http://$PI_IP:5000/api/db/stats"
echo ""
echo "🔧 DATA COLLECTION APIs:"
echo "   ✅ Status: http://$PI_IP:5000/api/collector/status"
echo "   🧪 Test: http://$PI_IP:5000/api/collector/test"
echo ""
echo "💡 EXAMPLE QUERIES:"
echo "   curl http://$PI_IP:5000/api/db/status"
echo "   curl \"http://$PI_IP:5000/api/db/query?sql=SELECT device_type, COUNT(*) FROM solar_data GROUP BY device_type\""
echo "   curl \"http://$PI_IP:5000/api/db/recent_data?table=solar_data&hours=6&device_type=Inverter\""
echo ""
echo "🚀 Ready for remote database queries!"
