#!/bin/bash
# PLAYWRIGHT TEST RUNNER

echo "🎭 RUNNING PLAYWRIGHT TESTS"
echo "==========================="
echo ""

# Ensure web server is running
if ! curl -s http://localhost:5000 > /dev/null; then
    echo "❌ Web server not running on port 5000"
    echo "   Start with: sudo systemctl start solar-monitor.service"
    exit 1
fi

echo "✅ Web server is running"
echo ""

# Run all tests
echo "🧪 Running all Playwright tests..."
npx playwright test

echo ""
echo "📊 Generating HTML report..."
npx playwright show-report

echo ""
echo "🎯 PLAYWRIGHT TESTS COMPLETE"
echo "============================"
echo "✅ All page validation tests run"
echo "✅ Data loading verified"
echo "✅ UI functionality tested"
echo ""
echo "📁 View detailed report: playwright-report/index.html"
