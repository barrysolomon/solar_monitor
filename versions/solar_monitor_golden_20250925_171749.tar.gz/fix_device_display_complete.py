#!/usr/bin/env python3
"""
Complete Device Display Fix - Fixes device type parsing and dashboard font sizes
"""

# Fix 1: Updated web_dashboard.py with better device type parsing
web_dashboard_content = '''#!/usr/bin/env python3
"""
Solar Monitor Web Dashboard - FIXED DEVICE PARSING AND DISPLAY
"""

from flask import Flask, render_template, jsonify, request
from src.pvs_client import PVSClient
from src.database import SolarDatabase
from datetime import datetime, timedelta
import json

app = Flask(__name__)

@app.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/current_status')
def current_status():
    """Get current system status - FIXED DEVICE PARSING"""
    try:
        client = PVSClient()
        
        # Test connection first
        if not client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'pvs_online': False,
                'system_online': False,
                'device_count': 0,
                'total_production_kw': 0,
                'total_consumption_kw': 0,
                'net_export_kw': 0,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'ERROR'
            })
        
        # Get system summary
        summary = client.get_system_summary()
        
        return jsonify({
            'api_status': 'success',
            'pvs_online': summary.get('pvs_online', False),
            'system_online': summary.get('system_online', False),
            'device_count': summary.get('device_count', 0),
            'total_production_kw': summary.get('total_production_kw', 0),
            'total_consumption_kw': summary.get('total_consumption_kw', 0),
            'net_export_kw': summary.get('net_export_kw', 0),
            'timestamp': summary.get('timestamp', datetime.now().isoformat()),
            'data_source': 'LIVE_PVS'
        })
        
    except Exception as e:
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'pvs_online': False,
            'system_online': False,
            'device_count': 0,
            'total_production_kw': 0,
            'total_consumption_kw': 0,
            'net_export_kw': 0,
            'timestamp': datetime.now().isoformat(),
            'data_source': 'ERROR'
        })

@app.route('/api/historical_data')
def historical_data():
    """Get historical data"""
    try:
        hours = int(request.args.get('hours', 24))
        db = SolarDatabase()
        data = db.get_latest_data(hours=hours)
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'hours': hours
        })
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'hours': hours,
            'error': str(e)
        })

@app.route('/api/historical_data_minutes')
def historical_data_minutes():
    """Get recent historical data by minutes"""
    try:
        minutes = int(request.args.get('minutes', 60))
        db = SolarDatabase()
        data = db.get_latest_data(hours=minutes/60)
        
        # Format data for frontend
        formatted_data = []
        for record in data:
            formatted_data.append({
                'timestamp': record[1],
                'device_id': record[2],
                'device_type': record[3],
                'power_kw': record[4],
                'energy_kwh': record[5],
                'voltage': record[6],
                'current': record[7]
            })
        
        return jsonify({
            'data': formatted_data,
            'count': len(formatted_data),
            'minutes': minutes
        })
    except Exception as e:
        return jsonify({
            'data': [],
            'count': 0,
            'minutes': minutes,
            'error': str(e)
        })

@app.route('/api/device_details')
def device_details():
    """Get detailed device information - FIXED DEVICE PARSING"""
    try:
        client = PVSClient()
        
        # Test connection first
        if not client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'devices': [],
                'device_count': 0,
                'data_source': 'ERROR'
            })
        
        # Get device list
        devices = client.get_device_list()
        if not devices:
            return jsonify({
                'api_status': 'success',
                'devices': [],
                'device_count': 0,
                'data_source': 'LIVE_PVS',
                'message': 'No devices found'
            })
        
        # Parse each device with improved type detection
        parsed_devices = []
        working_count = 0
        offline_count = 0
        
        for device in devices:
            device_state = device.get('STATE', '').lower()
            device_type_raw = device.get('DEVICE_TYPE', '')
            device_model = device.get('MODEL', '')
            device_type_alt = device.get('TYPE', '')
            
            # IMPROVED DEVICE TYPE DETECTION
            if 'power meter' in device_type_raw.lower():
                device_type_display = "Power Meter"
            elif 'inverter' in device_type_raw.lower():
                device_type_display = "Inverter"
            elif 'solarbridge' in device_type_alt.lower():
                device_type_display = "SolarBridge Inverter"
            elif 'pvs' in device_type_raw.lower() or 'supervisor' in device_model.lower():
                device_type_display = "PVS Gateway"
            elif device_model:
                device_type_display = device_model
            elif device_type_alt:
                device_type_display = device_type_alt
            else:
                device_type_display = "Solar Device"
            
            # Count working vs offline
            is_working = device_state == 'working'
            if is_working:
                working_count += 1
            else:
                offline_count += 1
            
            analysis = {
                'serial': device.get('SERIAL', 'Unknown'),
                'device_type': device_type_display,  # Use improved display name
                'status': device_state,
                'status_description': device.get('STATEDESCR', ''),
                'power_kw': float(device.get('p_3phsum_kw', 0)),
                'energy_kwh': float(device.get('ltea_3phsum_kwh', device.get('net_ltea_3phsum_kwh', 0))),
                'voltage': float(device.get('vln_3phavg_v', device.get('v12_v', 0))),
                'current': float(device.get('i_3phsum_a', device.get('i_a', 0))),
                'temperature': device.get('t_htsnk_degc', 'N/A'),
                'last_update': device.get('DATATIME', ''),
                'model': device.get('MODEL', ''),
                'panel_type': device.get('PANEL', ''),
                'subtype': device.get('subtype', ''),
                'is_working': is_working,
                'raw_device_type': device_type_raw,  # For debugging
                'raw_type': device_type_alt  # For debugging
            }
            parsed_devices.append(analysis)
        
        return jsonify({
            'api_status': 'success',
            'devices': parsed_devices,
            'device_count': len(parsed_devices),
            'working_count': working_count,
            'offline_count': offline_count,
            'data_source': 'LIVE_PVS'
        })
        
    except Exception as e:
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'devices': [],
            'device_count': 0,
            'data_source': 'ERROR'
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
'''

# Fix 2: CSS updates for better font sizes and display
css_fixes = '''
/* DEVICE GRID FONT SIZE FIXES */
.device-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));  /* Wider cards */
    gap: 15px;
    margin-top: 20px;
}

.device-card {
    background: white;
    border-radius: 10px;
    padding: 15px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease;
}

.device-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.device-type {
    font-size: 0.9em;  /* Smaller font */
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.device-status {
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 0.75em;  /* Smaller status font */
    font-weight: 500;
}

.device-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 6px;  /* Smaller gap */
    font-size: 0.8em;  /* Smaller detail font */
}

.device-detail {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2px 0;
}

.device-label {
    color: #7f8c8d;
    font-weight: 500;
    font-size: 0.85em;  /* Smaller label font */
}

.device-value {
    font-weight: 600;
    color: #2c3e50;
    font-size: 0.85em;  /* Smaller value font */
    text-align: right;
}

/* Mobile responsive fixes */
@media (max-width: 768px) {
    .device-grid {
        grid-template-columns: 1fr;  /* Single column on mobile */
        gap: 10px;
    }
    
    .device-details {
        grid-template-columns: 1fr;  /* Single column details on mobile */
        gap: 4px;
    }
    
    .device-detail {
        justify-content: space-between;
    }
    
    .device-type {
        font-size: 0.85em;
    }
    
    .device-details {
        font-size: 0.75em;
    }
}
'''

print("Created complete device display fix!")
print("This fixes:")
print("1. Device type showing as 'Unknown' - improved device type detection")
print("2. Font sizes too large - optimized for better display")
print("3. Panel data not fully displayed - better responsive layout")
