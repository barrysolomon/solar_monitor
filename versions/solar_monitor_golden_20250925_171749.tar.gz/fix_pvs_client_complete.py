#!/usr/bin/env python3
"""
Complete PVS Client Fix - Adds missing parse_device_data method
"""

import requests
import json
from datetime import datetime
from typing import Dict, List, Optional

class PVSClient:
    def __init__(self, pvs_ip='172.27.152.1', pvs_port=80):
        self.pvs_ip = pvs_ip
        self.pvs_port = pvs_port
        self.base_url = f"http://{pvs_ip}:{pvs_port}"
        
    def test_connection(self) -> bool:
        """Test connection to PVS"""
        try:
            response = requests.get(f"{self.base_url}/cgi-bin/dl_cgi?Command=DeviceList", timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def get_device_list(self) -> Optional[List[Dict]]:
        """Get list of all devices from PVS - REAL DATA ONLY"""
        try:
            response = requests.get(f"{self.base_url}/cgi-bin/dl_cgi?Command=DeviceList", timeout=10)
            response.raise_for_status()
            
            data = response.json()
            if 'devices' in data:
                print(f"✅ Got {len(data['devices'])} REAL devices from PVS")
                return data['devices']
            return []
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Error fetching device list: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Error parsing JSON response: {e}")
            return None
    
    def parse_device_data(self, device: Dict) -> Dict:
        """Parse individual device data - MISSING METHOD THAT WAS CAUSING ERRORS"""
        try:
            device_type = device.get('DEVICE_TYPE', '').lower()
            device_state = device.get('STATE', '').lower()
            device_state_desc = device.get('STATEDESCR', '')
            
            parsed_device = {
                'serial': device.get('SERIAL', ''),
                'type': device.get('TYPE', ''),
                'device_type': device_type,
                'state': device_state,
                'state_description': device_state_desc,
                'status': 'online' if device_state == 'working' else 'offline',
                'timestamp': datetime.now().isoformat()
            }
            
            # Parse power meters
            if 'power meter' in device_type or 'meter' in device_type:
                parsed_device.update({
                    'power_kw': float(device.get('p_3phsum_kw', 0)),
                    'energy_kwh': float(device.get('net_ltea_3phsum_kwh', 0)),
                    'subtype': device.get('subtype', '').lower(),
                    'category': 'meter'
                })
            
            # Parse inverters
            elif 'inverter' in device_type or 'solarbridge' in device.get('TYPE', '').lower():
                parsed_device.update({
                    'power_kw': float(device.get('p_3phsum_kw', 0)),
                    'energy_kwh': float(device.get('ltea_3phsum_kwh', 0)),
                    'voltage': float(device.get('vln_3phavg_v', 0)),
                    'current': float(device.get('i_3phsum_a', 0)),
                    'temperature': float(device.get('t_htsnk_degc', 0)),
                    'panel': device.get('PANEL', ''),
                    'frequency': float(device.get('freq_hz', 0)),
                    'category': 'inverter'
                })
            
            # Parse PVS gateway
            else:
                parsed_device.update({
                    'category': 'gateway'
                })
            
            return parsed_device
            
        except Exception as e:
            print(f"❌ Error parsing device {device.get('SERIAL', 'unknown')}: {e}")
            return {
                'serial': device.get('SERIAL', 'unknown'),
                'type': 'unknown',
                'category': 'unknown',
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def get_system_summary(self) -> Dict:
        """Get system summary using REAL PVS data only"""
        devices = self.get_device_list()
        if not devices:
            return {
                'device_count': 0,
                'total_production_kw': 0,
                'total_consumption_kw': 0,
                'net_export_kw': 0,
                'system_online': False,
                'pvs_online': False,
                'timestamp': datetime.now().isoformat()
            }

        summary = {
            'timestamp': datetime.now().isoformat(),
            'device_count': len(devices),
            'total_production_kw': 0,
            'total_consumption_kw': 0,
            'net_export_kw': 0,
            'inverters': [],
            'meters': [],
            'system_online': True,
            'pvs_online': True
        }

        production_power = 0
        consumption_power = 0

        for device in devices:
            device_type = device.get('DEVICE_TYPE', '').lower()
            # Use REAL PVS state fields
            device_state = device.get('STATE', '').lower()
            device_state_desc = device.get('STATEDESCR', '')

            # Parse power meters using REAL PVS data
            if 'power meter' in device_type or 'meter' in device_type:
                power_kw = float(device.get('p_3phsum_kw', 0))
                subtype = device.get('subtype', '').lower()

                meter_data = {
                    'serial': device.get('SERIAL', ''),
                    'power_kw': power_kw,
                    'energy_kwh': float(device.get('net_ltea_3phsum_kwh', 0)),
                    'type': device.get('TYPE', ''),
                    'subtype': subtype,
                    'state': device_state,  # REAL state from PVS
                    'state_description': device_state_desc,  # REAL description
                    'status': 'online' if device_state == 'working' else 'offline'
                }
                summary['meters'].append(meter_data)

                # Categorize production vs consumption
                if 'production' in subtype:
                    production_power += power_kw
                elif 'consumption' in subtype:
                    consumption_power += power_kw

            # Parse inverters using REAL PVS data
            elif 'inverter' in device_type or 'solarbridge' in device.get('TYPE', '').lower():
                power_kw = float(device.get('p_3phsum_kw', 0))

                inverter_data = {
                    'serial': device.get('SERIAL', ''),
                    'power_kw': power_kw,
                    'energy_kwh': float(device.get('ltea_3phsum_kwh', 0)),
                    'voltage': float(device.get('vln_3phavg_v', 0)),
                    'current': float(device.get('i_3phsum_a', 0)),
                    'temperature': float(device.get('t_htsnk_degc', 0)),
                    'state': device_state,  # REAL state from PVS
                    'state_description': device_state_desc,  # REAL description
                    'status': 'online' if device_state == 'working' else 'offline',  # Correct status logic
                    'panel': device.get('PANEL', ''),
                    'frequency': float(device.get('freq_hz', 0))
                }
                summary['inverters'].append(inverter_data)

        # Set totals
        summary['total_production_kw'] = production_power
        summary['total_consumption_kw'] = consumption_power
        summary['net_export_kw'] = production_power - consumption_power

        print(f"✅ REAL PVS Summary: {len(summary['inverters'])} inverters, {len(summary['meters'])} meters")
        print(f"✅ Production: {production_power:.2f}kW, Consumption: {consumption_power:.2f}kW")
        
        return summary
