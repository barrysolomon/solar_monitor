#!/usr/bin/env python3
"""
Emergency rollback script
"""
import os
import shutil

def emergency_rollback():
    backup_dir = '/opt/solar_monitor/safe_backups'
    backups = [d for d in os.listdir(backup_dir) if d.startswith('working_system_')]
    if not backups:
        print("No backups found!")
        return False
    
    latest_backup = sorted(backups)[-1]
    backup_path = f"{backup_dir}/{latest_backup}"
    
    print(f"EMERGENCY ROLLBACK to {latest_backup}")
    
    critical_files = [
        'web_dashboard_cached_simple.py',
        'templates/dashboard.html'
    ]
    
    for file in critical_files:
        src = f"{backup_path}/{file}"
        dst = f"/opt/solar_monitor/{file}"
        if os.path.exists(src):
            shutil.copy2(src, dst)
            print(f"   ✅ Restored {file}")
    
    import subprocess
    subprocess.run(['sudo', 'systemctl', 'restart', 'solar-monitor.service'])
    print("✅ Service restarted")

if __name__ == "__main__":
    emergency_rollback()
