#!/bin/bash

echo "🔧 PVS6 CONNECTION FIX SCRIPT"
echo "============================"
echo ""

echo "📡 Step 1: Check current network status"
echo "======================================="
echo "WiFi interfaces:"
ip addr show wlan0 2>/dev/null | grep -E "inet |state" || echo "wlan0 not found"
echo ""
echo "Active connections:"
nmcli connection show --active
echo ""

echo "🔍 Step 2: Test PVS6 connectivity"
echo "================================="
echo "Testing PVS6 ping..."
if ping -c 2 172.27.152.1 >/dev/null 2>&1; then
    echo "✅ PVS6 ping successful"
    
    echo "Testing PVS6 API..."
    if curl -s --connect-timeout 5 "http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList" | grep -q "device"; then
        echo "✅ PVS6 API responding"
        echo "🎯 PVS6 is reachable - issue might be in Solar Monitor service"
        
        echo ""
        echo "🔄 Step 3: Restart Solar Monitor service"
        echo "========================================"
        sudo systemctl restart solar-monitor.service
        sleep 3
        echo "✅ Solar Monitor service restarted"
        
    else
        echo "❌ PVS6 API not responding (but ping works)"
        echo "🎯 PVS6 device might be busy or API issue"
    fi
    
else
    echo "❌ PVS6 ping failed"
    echo ""
    echo "🔄 Step 3: Reconnect WiFi to PVS6"
    echo "================================="
    
    echo "Bringing up PVS6-WiFi connection..."
    nmcli connection up 'PVS6-WiFi' 2>/dev/null && echo "✅ PVS6-WiFi connection activated" || {
        echo "❌ PVS6-WiFi connection failed, trying direct WiFi connect..."
        nmcli device wifi connect 'SunPower37297' password '2231297' 2>/dev/null && echo "✅ Direct WiFi connection successful" || echo "❌ Direct WiFi connection failed"
    }
    
    echo ""
    echo "Waiting 5 seconds for connection to stabilize..."
    sleep 5
    
    echo "Testing PVS6 after WiFi reconnect..."
    if ping -c 2 172.27.152.1 >/dev/null 2>&1; then
        echo "✅ PVS6 ping now successful"
        echo "🔄 Restarting Solar Monitor service..."
        sudo systemctl restart solar-monitor.service
        sleep 3
        echo "✅ Solar Monitor service restarted"
    else
        echo "❌ PVS6 still unreachable after WiFi reconnect"
    fi
fi

echo ""
echo "📊 Step 4: Final status check"
echo "============================="
echo "Solar Monitor service status:"
systemctl is-active solar-monitor.service

echo ""
echo "Testing Solar Monitor API..."
sleep 2
curl -s "http://localhost:5000/api/current_status" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f'PVS Online: {data.get(\"pvs_online\", False)}')
    print(f'Device Count: {data.get(\"device_count\", 0)}')
    print(f'Data Source: {data.get(\"data_source\", \"Unknown\")}')
except:
    print('API not responding yet, may need more time')
"

echo ""
echo "🎉 FIX COMPLETE!"
echo "==============="
echo "• Refresh your dashboard to see updated status"
echo "• PVS6 connection should be restored"
echo "• If still disconnected, wait 30 seconds and refresh again"

