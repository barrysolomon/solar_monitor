#!/bin/bash

echo "🔍 SOLAR MONITOR DATA COLLECTION DIAGNOSTICS"
echo "============================================="
echo "$(date)"
echo ""

# Function to print section headers
print_section() {
    echo ""
    echo "📍 $1"
    echo "----------------------------------------"
}

# Function to test command and show result
test_command() {
    local cmd="$1"
    local description="$2"
    echo "Testing: $description"
    echo "Command: $cmd"
    if eval "$cmd" 2>/dev/null; then
        echo "✅ SUCCESS"
    else
        echo "❌ FAILED"
    fi
    echo ""
}

print_section "1. SYSTEM STATUS"
echo "Current time: $(date)"
echo "Uptime: $(uptime)"
echo "Free memory: $(free -h | grep Mem)"
echo ""

print_section "2. DATA COLLECTOR SERVICE STATUS"
sudo systemctl status solar-data-collector.service --no-pager -l || echo "❌ Data collector service not found or not running"

print_section "3. WEB DASHBOARD SERVICE STATUS"
sudo systemctl status solar-monitor.service --no-pager -l || echo "❌ Web dashboard service not found or not running"

print_section "4. RUNNING PROCESSES"
echo "Looking for data collector processes:"
ps aux | grep -E "(data_collector|solar)" | grep -v grep || echo "❌ No solar monitor processes found"

print_section "5. NETWORK CONNECTIVITY"
echo "Testing PVS6 connectivity (172.27.152.1):"
ping -c 3 172.27.152.1 2>/dev/null && echo "✅ PVS6 ping successful" || echo "❌ Cannot ping PVS6"

echo ""
echo "Testing PVS6 HTTP endpoint:"
curl -s --connect-timeout 10 --max-time 15 "http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList" | head -5 2>/dev/null && echo "✅ PVS6 HTTP endpoint reachable" || echo "❌ Cannot reach PVS6 HTTP endpoint"

print_section "6. DATABASE STATUS"
if [ -f "/opt/solar_monitor/solar_data.db" ]; then
    echo "✅ Database file exists"
    echo "Database size: $(du -h /opt/solar_monitor/solar_data.db | cut -f1)"
    
    echo ""
    echo "Recent data counts:"
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) as total_solar_records FROM solar_data;" 2>/dev/null && echo "Solar data records found" || echo "❌ Cannot query solar_data table"
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) as total_system_records FROM system_status;" 2>/dev/null && echo "System status records found" || echo "❌ Cannot query system_status table"
    
    echo ""
    echo "Latest timestamps:"
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT timestamp FROM solar_data ORDER BY timestamp DESC LIMIT 1;" 2>/dev/null | head -1 && echo "(Latest solar data)" || echo "❌ No solar data found"
    sqlite3 /opt/solar_monitor/solar_data.db "SELECT timestamp FROM system_status ORDER BY timestamp DESC LIMIT 1;" 2>/dev/null | head -1 && echo "(Latest system status)" || echo "❌ No system status found"
else
    echo "❌ Database file not found at /opt/solar_monitor/solar_data.db"
fi

print_section "7. LOG FILES"
echo "Data collector logs (last 20 lines):"
sudo journalctl -u solar-data-collector.service --no-pager -l | tail -20 || echo "❌ No data collector logs found"

echo ""
echo "Web dashboard logs (last 10 lines):"
sudo journalctl -u solar-monitor.service --no-pager -l | tail -10 || echo "❌ No web dashboard logs found"

print_section "8. API ENDPOINTS TEST"
echo "Testing local API endpoints:"
curl -s --connect-timeout 5 "http://localhost:5000/api/current_status" | head -10 2>/dev/null && echo "✅ Current status API working" || echo "❌ Current status API not responding"

print_section "9. PYTHON ENVIRONMENT"
echo "Python version: $(python3 --version)"
echo "Python path: $(which python3)"
echo ""
echo "Required Python packages:"
python3 -c "import requests; print('✅ requests module available')" 2>/dev/null || echo "❌ requests module missing"
python3 -c "import sqlite3; print('✅ sqlite3 module available')" 2>/dev/null || echo "❌ sqlite3 module missing"
python3 -c "import schedule; print('✅ schedule module available')" 2>/dev/null || echo "❌ schedule module missing"
python3 -c "import flask; print('✅ flask module available')" 2>/dev/null || echo "❌ flask module missing"

print_section "10. FILE PERMISSIONS"
echo "Solar monitor directory permissions:"
ls -la /opt/solar_monitor/ | head -10 || echo "❌ Cannot access /opt/solar_monitor/"

echo ""
echo "Key file permissions:"
[ -f "/opt/solar_monitor/src/data_collector.py" ] && echo "✅ data_collector.py exists" || echo "❌ data_collector.py missing"
[ -f "/opt/solar_monitor/web_dashboard_cached_simple.py" ] && echo "✅ web dashboard exists" || echo "❌ web dashboard missing"
[ -x "/opt/solar_monitor/src/data_collector.py" ] && echo "✅ data_collector.py is executable" || echo "❌ data_collector.py not executable"

print_section "11. WIFI/NETWORK CONFIGURATION"
echo "Network interfaces:"
ip addr show | grep -E "(wlan0|eth0)" || echo "❌ No network interfaces found"

echo ""
echo "WiFi status:"
iwconfig 2>/dev/null | grep -E "(ESSID|Access Point)" || echo "❌ No WiFi information available"

echo ""
echo "Current routes:"
ip route | head -5

print_section "SUMMARY & RECOMMENDATIONS"
echo "🔧 COMMON FIXES:"
echo ""
echo "1. If data collector service is not running:"
echo "   sudo systemctl start solar-data-collector.service"
echo "   sudo systemctl enable solar-data-collector.service"
echo ""
echo "2. If PVS6 is not reachable:"
echo "   - Check WiFi connection to SunPower network"
echo "   - Verify PVS6 IP address (should be 172.27.152.1)"
echo "   - Try: sudo iwconfig wlan0 essid 'SunPower'"
echo ""
echo "3. If Python modules are missing:"
echo "   sudo apt update && sudo apt install python3-pip"
echo "   pip3 install requests flask schedule"
echo ""
echo "4. If database issues:"
echo "   sudo chown barry:barry /opt/solar_monitor/solar_data.db"
echo "   sudo chmod 664 /opt/solar_monitor/solar_data.db"
echo ""
echo "5. To restart everything:"
echo "   sudo systemctl restart solar-data-collector.service"
echo "   sudo systemctl restart solar-monitor.service"
echo ""
echo "============================================="
echo "Diagnostics complete: $(date)"
