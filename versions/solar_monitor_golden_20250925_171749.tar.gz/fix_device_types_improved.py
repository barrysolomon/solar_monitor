#!/usr/bin/env python3
"""
Improved Device Type Detection Fix
"""

# This is the improved device_details function with better type detection
device_details_function = '''
@app.route('/api/device_details')
def device_details():
    """Get detailed device information - IMPROVED DEVICE TYPE DETECTION"""
    try:
        client = PVSClient()
        
        # Test connection first
        if not client.test_connection():
            return jsonify({
                'api_status': 'error',
                'error': 'Cannot connect to PVS6',
                'devices': [],
                'device_count': 0,
                'data_source': 'ERROR'
            })
        
        # Get device list
        devices = client.get_device_list()
        if not devices:
            return jsonify({
                'api_status': 'success',
                'devices': [],
                'device_count': 0,
                'data_source': 'LIVE_PVS',
                'message': 'No devices found'
            })
        
        # Parse each device with MUCH IMPROVED type detection
        parsed_devices = []
        working_count = 0
        offline_count = 0
        
        for device in devices:
            device_state = device.get('STATE', '').lower()
            device_type_raw = device.get('DEVICE_TYPE', '').lower()
            device_model = device.get('MODEL', '').lower()
            device_type_alt = device.get('TYPE', '').lower()
            serial = device.get('SERIAL', '')
            
            # MUCH IMPROVED DEVICE TYPE DETECTION LOGIC
            device_type_display = "Unknown"
            
            # Check serial number patterns first (most reliable)
            if 'pvs6' in serial.lower():
                device_type_display = "PVS Gateway"
            elif serial.startswith('ZT') and len(serial) > 10:
                device_type_display = "PVS Gateway"
            elif 'pv' in serial.lower() and 'm' in serial.lower():
                device_type_display = "Power Meter"
            
            # Check device type fields
            elif 'power meter' in device_type_raw:
                device_type_display = "Power Meter"
            elif 'inverter' in device_type_raw:
                device_type_display = "Inverter"
            elif 'pvs' in device_type_raw:
                device_type_display = "PVS Gateway"
                
            # Check TYPE field
            elif 'solarbridge' in device_type_alt:
                device_type_display = "SolarBridge Inverter"
            elif 'inverter' in device_type_alt:
                device_type_display = "Inverter"
            elif 'meter' in device_type_alt:
                device_type_display = "Power Meter"
                
            # Check MODEL field
            elif 'supervisor' in device_model:
                device_type_display = "PVS Gateway"
            elif 'pvs' in device_model:
                device_type_display = "PVS Gateway"
            elif 'solarbridge' in device_model:
                device_type_display = "SolarBridge Inverter"
            elif 'inverter' in device_model:
                device_type_display = "Inverter"
            elif 'meter' in device_model:
                device_type_display = "Power Meter"
                
            # Fallback: use model or type if available
            elif device_model and device_model != 'unknown':
                device_type_display = device_model.title()
            elif device_type_alt and device_type_alt != 'unknown':
                device_type_display = device_type_alt.title()
            
            # Count working vs offline
            is_working = device_state == 'working'
            if is_working:
                working_count += 1
            else:
                offline_count += 1
            
            analysis = {
                'serial': serial,
                'device_type': device_type_display,  # Use improved display name
                'status': device_state,
                'status_description': device.get('STATEDESCR', ''),
                'power_kw': float(device.get('p_3phsum_kw', 0)),
                'energy_kwh': float(device.get('ltea_3phsum_kwh', device.get('net_ltea_3phsum_kwh', 0))),
                'voltage': float(device.get('vln_3phavg_v', device.get('v12_v', 0))),
                'current': float(device.get('i_3phsum_a', device.get('i_a', 0))),
                'temperature': device.get('t_htsnk_degc', 'N/A'),
                'last_update': device.get('DATATIME', ''),
                'model': device.get('MODEL', ''),
                'panel_type': device.get('PANEL', ''),
                'subtype': device.get('subtype', ''),
                'is_working': is_working,
                'raw_device_type': device_type_raw,  # For debugging
                'raw_type': device_type_alt,  # For debugging
                'raw_model': device_model  # For debugging
            }
            parsed_devices.append(analysis)
        
        return jsonify({
            'api_status': 'success',
            'devices': parsed_devices,
            'device_count': len(parsed_devices),
            'working_count': working_count,
            'offline_count': offline_count,
            'data_source': 'LIVE_PVS'
        })
        
    except Exception as e:
        return jsonify({
            'api_status': 'error',
            'error': str(e),
            'devices': [],
            'device_count': 0,
            'data_source': 'ERROR'
        })
'''

print("Created improved device type detection!")
print("This will properly identify:")
print("- ZT223785000549W1297 → PVS Gateway")
print("- PVS6M22371297p → Power Meter")
print("- And other devices based on serial patterns")
