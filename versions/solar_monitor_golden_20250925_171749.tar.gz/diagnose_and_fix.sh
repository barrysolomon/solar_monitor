#!/bin/bash

echo "🔍 Diagnosing the blank page issue..."

# Check the current template file
echo "📊 Current template file info:"
ls -la /home/barry/solar_monitor/templates/dashboard.html

echo ""
echo "📄 First 20 lines of current template:"
head -20 /home/barry/solar_monitor/templates/dashboard.html

echo ""
echo "📄 Last 10 lines of current template:"
tail -10 /home/barry/solar_monitor/templates/dashboard.html

echo ""
echo "🔍 Checking for HTML structure:"
grep -c "<html>" /home/barry/solar_monitor/templates/dashboard.html
grep -c "</html>" /home/barry/solar_monitor/templates/dashboard.html
grep -c "<body>" /home/barry/solar_monitor/templates/dashboard.html
grep -c "</body>" /home/barry/solar_monitor/templates/dashboard.html

echo ""
echo "🔍 Checking for JavaScript errors:"
grep -n "function\|script" /home/barry/solar_monitor/templates/dashboard.html | head -10

echo ""
echo "🔍 Available backups:"
ls -la /home/barry/solar_monitor/templates/dashboard.html.*

echo ""
echo "🔧 If the template is corrupted, we can:"
echo "   1. Fix the current template in place"
echo "   2. Or restore from working_backup if needed"
echo ""
echo "📊 Service status:"
sudo systemctl status solar-monitor.service --no-pager -l | head -10

echo ""
echo "📋 Recent service logs:"
sudo journalctl -u solar-monitor.service --lines=5 --no-pager
