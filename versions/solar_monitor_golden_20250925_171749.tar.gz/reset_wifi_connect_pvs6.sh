#!/bin/bash
# Reset WiFi and Connect to PVS6 Hotspot

echo "🔄 RESET WIFI AND CONNECT TO PVS6"
echo "================================="

# Step 1: Reset WiFi interface
echo "1. Resetting WiFi interface..."
sudo rfkill unblock wifi
sudo ip link set wlan0 down
sleep 2
sudo ip link set wlan0 up
sleep 3

# Step 2: Kill any existing WiFi processes
echo "2. Cleaning up existing WiFi processes..."
sudo pkill -f wpa_supplicant
sudo pkill -f dhclient
sudo rm -rf /var/run/wpa_supplicant/
sleep 2

# Step 3: Scan for PVS6 WiFi hotspot
echo "3. Scanning for PVS6 WiFi hotspot..."
echo "Looking for SunPower networks..."

# Scan multiple times to ensure we catch the hotspot
for i in {1..3}; do
    echo "  Scan attempt $i..."
    SUNPOWER_NETWORKS=$(sudo iwlist wlan0 scan 2>/dev/null | grep -i "sunpower" | head -5)
    if [ -n "$SUNPOWER_NETWORKS" ]; then
        break
    fi
    sleep 2
done

if [ -n "$SUNPOWER_NETWORKS" ]; then
    echo "✅ Found SunPower networks:"
    echo "$SUNPOWER_NETWORKS"
    
    # Extract SSID from the scan results
    SSID=$(echo "$SUNPOWER_NETWORKS" | head -1 | sed 's/.*ESSID:"\([^"]*\)".*/\1/')
    echo "🔗 Target SSID: $SSID"
    
    # Derive password from SSID
    if [[ $SSID =~ SunPower([0-9]+) ]]; then
        NUMBERS="${BASH_REMATCH[1]}"
        echo "📊 Extracted numbers: $NUMBERS"
        
        if [ ${#NUMBERS} -eq 5 ]; then
            # Standard PVS6 password format: first 3 + last 4 digits of serial
            # For SunPower37297, password would be 22371297 (from serial ZT223785000549W1297)
            # But we'll try the simpler format first: 223 + 37297 = 22337297
            PASSWORD1="223${NUMBERS}"
            PASSWORD2="2237${NUMBERS}"
            
            echo "🔑 Trying password formats..."
            echo "  Format 1: $PASSWORD1"
            echo "  Format 2: $PASSWORD2"
            
            # Method 1: Try with nmcli (preferred)
            echo "4. Attempting connection with nmcli..."
            
            # Try first password format
            echo "  Trying password: $PASSWORD1"
            if sudo nmcli device wifi connect "$SSID" password "$PASSWORD1" 2>/dev/null; then
                echo "✅ Connected with password: $PASSWORD1"
                CONNECTION_SUCCESS=true
            else
                echo "  First password failed, trying second format..."
                # Try second password format
                echo "  Trying password: $PASSWORD2"
                if sudo nmcli device wifi connect "$SSID" password "$PASSWORD2" 2>/dev/null; then
                    echo "✅ Connected with password: $PASSWORD2"
                    CONNECTION_SUCCESS=true
                else
                    echo "  nmcli failed, trying manual wpa_supplicant..."
                    CONNECTION_SUCCESS=false
                fi
            fi
            
            # Method 2: Manual wpa_supplicant if nmcli fails
            if [ "$CONNECTION_SUCCESS" != "true" ]; then
                echo "5. Trying manual wpa_supplicant connection..."
                
                # Create temporary wpa_supplicant config
                TEMP_WPA_CONF="/tmp/wpa_supplicant_pvs6.conf"
                cat > "$TEMP_WPA_CONF" << EOF
country=US
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1

network={
    ssid="$SSID"
    psk="$PASSWORD1"
    key_mgmt=WPA-PSK
}
EOF
                
                # Try manual connection
                sudo wpa_supplicant -B -i wlan0 -c "$TEMP_WPA_CONF" -D nl80211,wext
                sleep 5
                
                # Get IP address
                sudo dhclient wlan0
                sleep 3
                
                # Check if we got an IP
                WLAN_IP=$(ip addr show wlan0 | grep "inet " | awk '{print $2}' | cut -d'/' -f1)
                if [[ $WLAN_IP == 172.27.152.* ]]; then
                    echo "✅ Manual connection successful!"
                    CONNECTION_SUCCESS=true
                else
                    echo "❌ Manual connection failed, trying second password..."
                    
                    # Try with second password
                    cat > "$TEMP_WPA_CONF" << EOF
country=US
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1

network={
    ssid="$SSID"
    psk="$PASSWORD2"
    key_mgmt=WPA-PSK
}
EOF
                    
                    sudo pkill -f wpa_supplicant
                    sleep 2
                    sudo wpa_supplicant -B -i wlan0 -c "$TEMP_WPA_CONF" -D nl80211,wext
                    sleep 5
                    sudo dhclient wlan0
                    sleep 3
                    
                    WLAN_IP=$(ip addr show wlan0 | grep "inet " | awk '{print $2}' | cut -d'/' -f1)
                    if [[ $WLAN_IP == 172.27.152.* ]]; then
                        echo "✅ Manual connection with second password successful!"
                        CONNECTION_SUCCESS=true
                    fi
                fi
                
                # Cleanup
                rm -f "$TEMP_WPA_CONF"
            fi
            
        else
            echo "❌ Unexpected number format in SSID: $NUMBERS (length: ${#NUMBERS})"
            CONNECTION_SUCCESS=false
        fi
    else
        echo "❌ Could not extract numbers from SSID: $SSID"
        CONNECTION_SUCCESS=false
    fi
else
    echo "❌ No SunPower WiFi networks found"
    echo ""
    echo "🔧 Troubleshooting steps:"
    echo "1. Make sure PVS6 is powered on"
    echo "2. Check if PVS6 WiFi hotspot is enabled"
    echo "3. Move Pi closer to PVS6"
    echo "4. Try scanning manually:"
    echo "   sudo iwlist wlan0 scan | grep -i -A5 -B5 sunpower"
    CONNECTION_SUCCESS=false
fi

# Step 6: Verify connection
echo ""
echo "6. Verifying connection..."

if [ "$CONNECTION_SUCCESS" = "true" ]; then
    # Check network status
    echo "📊 Network Status:"
    iwconfig wlan0 2>/dev/null | grep -E "(ESSID|Access Point|Bit Rate)"
    
    # Check IP address
    WLAN_IP=$(ip addr show wlan0 | grep "inet " | awk '{print $2}' | cut -d'/' -f1)
    echo "📍 WiFi IP: $WLAN_IP"
    
    if [[ $WLAN_IP == 172.27.152.* ]]; then
        echo "✅ Connected to PVS6 network!"
        
        # Test PVS6 connectivity
        echo "7. Testing PVS6 connectivity..."
        if ping -c 3 -W 3 172.27.152.1 >/dev/null 2>&1; then
            echo "✅ PVS6 is reachable at 172.27.152.1"
            
            # Test PVS6 API
            echo "8. Testing PVS6 API..."
            API_RESPONSE=$(curl -s --connect-timeout 10 "http://172.27.152.1/cgi-bin/dl_cgi?Command=DeviceList" 2>/dev/null)
            if [ -n "$API_RESPONSE" ] && [[ $API_RESPONSE == *"devices"* ]]; then
                echo "✅ PVS6 API is responding!"
                
                # Count devices
                DEVICE_COUNT=$(echo "$API_RESPONSE" | grep -o '"DEVICE_TYPE"' | wc -l)
                echo "✅ Found $DEVICE_COUNT devices in PVS6 API"
                
                echo ""
                echo "🎉 SUCCESS! PVS6 CONNECTION ESTABLISHED"
                echo "======================================"
                echo "✅ WiFi connected to: $SSID"
                echo "✅ Pi IP address: $WLAN_IP"
                echo "✅ PVS6 reachable: 172.27.152.1"
                echo "✅ PVS6 API working: $DEVICE_COUNT devices"
                echo ""
                echo "🔄 Now restart Solar Monitor service:"
                echo "  sudo systemctl restart solar-monitor.service"
                echo ""
                echo "🧪 Test the fix:"
                echo "  curl http://localhost:5000/api/current_status"
                
            else
                echo "❌ PVS6 API not responding properly"
                echo "Response: ${API_RESPONSE:0:100}..."
            fi
        else
            echo "❌ Cannot ping PVS6 at 172.27.152.1"
        fi
    else
        echo "❌ Connected but got wrong IP range: $WLAN_IP"
        echo "Expected: 172.27.152.x"
    fi
else
    echo "❌ Failed to connect to PVS6 WiFi"
    echo ""
    echo "🔧 Manual connection steps:"
    echo "1. Find the exact SSID:"
    echo "   sudo iwlist wlan0 scan | grep -i sunpower"
    echo ""
    echo "2. Connect manually (replace SSID and password):"
    echo "   sudo nmcli device wifi connect 'SunPowerXXXXX' password 'XXXXXXXX'"
    echo ""
    echo "3. Check connection:"
    echo "   iwconfig"
    echo "   ip addr show wlan0"
fi

echo ""
echo "🏁 WiFi reset and PVS6 connection attempt complete!"
