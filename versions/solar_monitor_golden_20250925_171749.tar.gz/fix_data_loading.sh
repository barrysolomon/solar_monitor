#!/bin/bash

echo "🔧 FIXING DATA LOADING ISSUES"
echo "============================="

echo "📍 Step 1: Check if data collector service exists"
sudo systemctl status solar-data-collector.service --no-pager -l 2>/dev/null || echo "❌ Data collector service not found"

echo ""
echo "📍 Step 2: Check for any data collection processes"
ps aux | grep data_collector.py | grep -v grep

echo ""
echo "📍 Step 3: Check database for recent data"
sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) as total_records FROM solar_data;" 2>/dev/null || echo "❌ Database not accessible"
sqlite3 /opt/solar_monitor/solar_data.db "SELECT timestamp FROM system_status ORDER BY timestamp DESC LIMIT 1;" 2>/dev/null || echo "❌ No system status data"

echo ""
echo "📍 Step 4: Test PVS6 connectivity"
curl -s --connect-timeout 5 http://172.27.153.1/cgi-bin/dl_cgi?Command=DeviceList | head -5 || echo "❌ Cannot reach PVS6"

echo ""
echo "📍 Step 5: Check web dashboard logs"
sudo journalctl -u solar-monitor.service --no-pager -l | tail -10

echo ""
echo "📍 Step 6: Test API endpoints"
echo "Testing current status API:"
curl -s http://localhost:5000/api/current_status | head -10

echo ""
echo "📍 Step 7: Create and start data collector service"
sudo tee /etc/systemd/system/solar-data-collector.service > /dev/null << 'EOF'
[Unit]
Description=Solar Data Collector
After=network.target

[Service]
Type=simple
User=barry
WorkingDirectory=/opt/solar_monitor
Environment=PYTHONPATH=/opt/solar_monitor
ExecStart=/usr/bin/python3 /opt/solar_monitor/src/data_collector.py
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF

echo ""
echo "📍 Step 8: Enable and start data collector"
sudo systemctl daemon-reload
sudo systemctl enable solar-data-collector.service
sudo systemctl start solar-data-collector.service
sleep 3

echo ""
echo "📍 Step 9: Check data collector status"
sudo systemctl status solar-data-collector.service --no-pager -l

echo ""
echo "📍 Step 10: Wait and test data collection"
echo "Waiting 10 seconds for data collection..."
sleep 10
sqlite3 /opt/solar_monitor/solar_data.db "SELECT COUNT(*) as new_records FROM solar_data WHERE timestamp > datetime('now', '-1 minute');" 2>/dev/null || echo "❌ No new data collected"

echo ""
echo "🎯 DATA LOADING FIX COMPLETE"
echo "🔄 Refresh your browser at: http://192.168.1.126:5000"
