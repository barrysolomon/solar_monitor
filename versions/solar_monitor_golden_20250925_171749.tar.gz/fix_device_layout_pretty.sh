#!/bin/bash

echo "✨ Applying beautiful device layout with icons and alignment..."

# First, backup the current working template
sudo cp /home/barry/solar_monitor/templates/dashboard.html /home/barry/solar_monitor/templates/dashboard.html.working_backup

# Create a temporary CSS file with our improvements
cat > /tmp/device_layout_improvements.css << 'CSS_END'
/* BEAUTIFUL DEVICE LAYOUT WITH ICONS */
.device-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 20px;
    margin-top: 20px;
    padding: 0 15px;
}

.device-card {
    background: linear-gradient(145deg, #ffffff, #f8f9fa);
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.device-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, #3498db, #2980b9);
}

.device-card.pvs-gateway::before {
    background: linear-gradient(90deg, #9b59b6, #8e44ad);
}

.device-card.power-meter::before {
    background: linear-gradient(90deg, #e74c3c, #c0392b);
}

.device-card.inverter::before {
    background: linear-gradient(90deg, #27ae60, #229954);
}

.device-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
}

.device-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f1f3f4;
}

.device-type {
    font-size: 1.3em;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.device-icon {
    font-size: 1.4em;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    border: 2px solid #dee2e6;
}

.device-card.pvs-gateway .device-icon {
    background: linear-gradient(135deg, #e8d5f2, #d1b3e8);
    border-color: #9b59b6;
    color: #8e44ad;
}

.device-card.power-meter .device-icon {
    background: linear-gradient(135deg, #fadbd8, #f5b7b1);
    border-color: #e74c3c;
    color: #c0392b;
}

.device-card.inverter .device-icon {
    background: linear-gradient(135deg, #d5f4e6, #abebc6);
    border-color: #27ae60;
    color: #229954;
}

.device-status {
    padding: 8px 16px;
    border-radius: 24px;
    font-size: 0.85em;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.device-status.working {
    background: linear-gradient(135deg, #d4edda, #c3e6cb);
    color: #155724;
    border: 2px solid #b8dabd;
}

.device-status.working::before {
    content: '●';
    color: #28a745;
    font-size: 1.2em;
}

.device-status.offline {
    background: linear-gradient(135deg, #f8d7da, #f5c6cb);
    color: #721c24;
    border: 2px solid #f1aeb5;
}

.device-status.offline::before {
    content: '●';
    color: #dc3545;
    font-size: 1.2em;
}

.device-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin-bottom: 20px;
}

.device-detail {
    display: flex;
    align-items: center;
    padding: 14px 16px;
    background: linear-gradient(135deg, #f8f9fa, #ffffff);
    border-radius: 12px;
    border-left: 4px solid #dee2e6;
    transition: all 0.2s ease;
    gap: 12px;
}

.device-detail:hover {
    transform: translateX(4px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.device-detail-icon {
    font-size: 1.2em;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #e9ecef, #f8f9fa);
    color: #6c757d;
    flex-shrink: 0;
}

.device-detail-content {
    flex: 1;
    min-width: 0;
}

.device-label {
    color: #6c757d;
    font-weight: 600;
    font-size: 0.8em;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
    display: block;
}

.device-value {
    font-weight: 700;
    color: #2c3e50;
    font-size: 1.1em;
    display: block;
    word-break: break-all;
}

.device-serial {
    text-align: center;
    font-family: 'Courier New', monospace;
    font-size: 0.9em;
    color: #6c757d;
    background: linear-gradient(135deg, #f1f3f4, #e9ecef);
    padding: 12px 16px;
    border-radius: 10px;
    font-weight: 600;
    letter-spacing: 1.2px;
    border: 1px solid #dee2e6;
}

/* Special styling for different data types */
.device-detail.power .device-detail-icon {
    background: linear-gradient(135deg, #fff3cd, #ffeaa7);
    color: #856404;
}

.device-detail.energy .device-detail-icon {
    background: linear-gradient(135deg, #d1ecf1, #bee5eb);
    color: #0c5460;
}

.device-detail.voltage .device-detail-icon {
    background: linear-gradient(135deg, #f8d7da, #f5c6cb);
    color: #721c24;
}

.device-detail.current .device-detail-icon {
    background: linear-gradient(135deg, #d4edda, #c3e6cb);
    color: #155724;
}

.device-detail.temperature .device-detail-icon {
    background: linear-gradient(135deg, #ffeaa7, #fdcb6e);
    color: #8b4513;
}

/* Mobile responsive */
@media (max-width: 768px) {
    .device-grid {
        grid-template-columns: 1fr;
        gap: 16px;
        padding: 0 10px;
    }
    
    .device-details {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .device-card {
        padding: 20px;
    }
    
    .device-type {
        font-size: 1.1em;
    }
    
    .device-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
}
CSS_END

# Add the improved CSS to the template (replace existing device styles)
sudo sed -i '/\/\* Device Grid \*\//,/\.device-detail {/c\
        /* BEAUTIFUL DEVICE LAYOUT WITH ICONS */\
        .device-grid {\
            display: grid;\
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));\
            gap: 20px;\
            margin-top: 20px;\
            padding: 0 15px;\
        }\
\
        .device-card {\
            background: linear-gradient(145deg, #ffffff, #f8f9fa);\
            border-radius: 16px;\
            padding: 24px;\
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);\
            border: 1px solid #e9ecef;\
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);\
            position: relative;\
            overflow: hidden;\
        }\
\
        .device-card::before {\
            content: "";\
            position: absolute;\
            top: 0;\
            left: 0;\
            right: 0;\
            height: 5px;\
            background: linear-gradient(90deg, #3498db, #2980b9);\
        }\
\
        .device-card.pvs-gateway::before {\
            background: linear-gradient(90deg, #9b59b6, #8e44ad);\
        }\
\
        .device-card.power-meter::before {\
            background: linear-gradient(90deg, #e74c3c, #c0392b);\
        }\
\
        .device-card.inverter::before {\
            background: linear-gradient(90deg, #27ae60, #229954);\
        }\
\
        .device-card:hover {\
            transform: translateY(-8px);\
            box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);\
        }\
\
        .device-header {\
            display: flex;\
            justify-content: space-between;\
            align-items: center;\
            margin-bottom: 20px;\
            padding-bottom: 16px;\
            border-bottom: 2px solid #f1f3f4;\
        }\
\
        .device-type {\
            font-size: 1.3em;\
            font-weight: 700;\
            color: #2c3e50;\
            margin: 0;\
            display: flex;\
            align-items: center;\
            gap: 12px;\
        }\
\
        .device-status {\
            padding: 8px 16px;\
            border-radius: 24px;\
            font-size: 0.85em;\
            font-weight: 700;\
            text-transform: uppercase;\
            letter-spacing: 0.8px;\
            display: flex;\
            align-items: center;\
            gap: 6px;\
        }\
\
        .device-status.working {\
            background: linear-gradient(135deg, #d4edda, #c3e6cb);\
            color: #155724;\
            border: 2px solid #b8dabd;\
        }\
\
        .device-status.offline {\
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);\
            color: #721c24;\
            border: 2px solid #f1aeb5;\
        }\
\
        .device-details {\
            display: grid;\
            grid-template-columns: 1fr 1fr;\
            gap: 16px;\
            margin-bottom: 20px;\
        }\
\
        .device-detail {\
            display: flex;\
            align-items: center;\
            padding: 14px 16px;\
            background: linear-gradient(135deg, #f8f9fa, #ffffff);\
            border-radius: 12px;\
            border-left: 4px solid #dee2e6;\
            transition: all 0.2s ease;\
            gap: 12px;\
        }\
\
        .device-detail:hover {\
            transform: translateX(4px);\
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);\
        }\
\
        .device-label {\
            color: #6c757d;\
            font-weight: 600;\
            font-size: 0.8em;\
            text-transform: uppercase;\
            letter-spacing: 0.5px;\
            margin-bottom: 4px;\
            display: block;\
        }\
\
        .device-value {\
            font-weight: 700;\
            color: #2c3e50;\
            font-size: 1.1em;\
            display: block;\
        }\
\
        .device-serial {\
            text-align: center;\
            font-family: "Courier New", monospace;\
            font-size: 0.9em;\
            color: #6c757d;\
            background: linear-gradient(135deg, #f1f3f4, #e9ecef);\
            padding: 12px 16px;\
            border-radius: 10px;\
            font-weight: 600;\
            letter-spacing: 1.2px;\
            border: 1px solid #dee2e6;\
        }' /home/barry/solar_monitor/templates/dashboard.html

# Update the JavaScript to include icons and better formatting
sudo sed -i '/card\.innerHTML = `/,/`;/c\
                            // Add device type class for styling\
                            let deviceClass = '\''device-card'\'';\
                            let deviceIcon = '\''🔧'\'';\
                            const deviceType = (device.device_type || '\''Unknown'\'').toLowerCase();\
                            \
                            if (deviceType.includes('\''pvs'\'') || deviceType.includes('\''gateway'\'')) {\
                                deviceClass += '\'' pvs-gateway'\'';\
                                deviceIcon = '\''🏠'\'';\
                            } else if (deviceType.includes('\''meter'\'')) {\
                                deviceClass += '\'' power-meter'\'';\
                                deviceIcon = '\''⚡'\'';\
                            } else if (deviceType.includes('\''inverter'\'')) {\
                                deviceClass += '\'' inverter'\'';\
                                deviceIcon = '\''☀️'\'';\
                            }\
                            \
                            card.className = deviceClass;\
                            \
                            // Format values with proper units and precision\
                            const power = parseFloat(device.power_kw || 0).toFixed(2);\
                            const energy = parseFloat(device.energy_kwh || 0).toFixed(1);\
                            const voltage = parseFloat(device.voltage || 0).toFixed(1);\
                            const current = parseFloat(device.current || 0).toFixed(2);\
                            const temperature = device.temperature !== '\''N/A'\'' ? `${device.temperature}°C` : '\''N/A'\'';\
                            \
                            card.innerHTML = `\
                                <div class="device-header">\
                                    <div class="device-type">\
                                        <div class="device-icon">${deviceIcon}</div>\
                                        ${device.device_type || '\''Unknown Device'\''}\
                                    </div>\
                                    <span class="device-status ${device.status === '\''working'\'' ? '\''working'\'' : '\''offline'\''}">\
                                        ${device.status || '\''Unknown'\''}\
                                    </span>\
                                </div>\
                                <div class="device-details">\
                                    <div class="device-detail power">\
                                        <div class="device-detail-icon">⚡</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Power Output</span>\
                                            <span class="device-value">${power} kW</span>\
                                        </div>\
                                    </div>\
                                    <div class="device-detail energy">\
                                        <div class="device-detail-icon">🔋</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Total Energy</span>\
                                            <span class="device-value">${energy} kWh</span>\
                                        </div>\
                                    </div>\
                                    <div class="device-detail voltage">\
                                        <div class="device-detail-icon">🔌</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Voltage</span>\
                                            <span class="device-value">${voltage} V</span>\
                                        </div>\
                                    </div>\
                                    <div class="device-detail current">\
                                        <div class="device-detail-icon">⚡</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Current</span>\
                                            <span class="device-value">${current} A</span>\
                                        </div>\
                                    </div>\
                                    ${device.temperature !== '\''N/A'\'' ? `\
                                    <div class="device-detail temperature">\
                                        <div class="device-detail-icon">🌡️</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Temperature</span>\
                                            <span class="device-value">${temperature}</span>\
                                        </div>\
                                    </div>\
                                    ` : '\'''\''}\
                                    ${device.model ? `\
                                    <div class="device-detail">\
                                        <div class="device-detail-icon">📋</div>\
                                        <div class="device-detail-content">\
                                            <span class="device-label">Model</span>\
                                            <span class="device-value">${device.model}</span>\
                                        </div>\
                                    </div>\
                                    ` : '\'''\''}\
                                </div>\
                                <div class="device-serial">\
                                    📟 Serial: ${device.serial || '\''Unknown'\''}\
                                </div>\
                            `;' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Applied beautiful device layout with icons and alignment"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh"
echo ""
echo "✨ New beautiful features:"
echo "   🏠 PVS Gateway with house icon"
echo "   ⚡ Power Meters with lightning icon"
echo "   ☀️ Inverters with sun icon"
echo "   📊 Perfectly aligned data with individual icons"
echo "   🎨 Color-coded borders and hover effects"
echo "   📱 Fully responsive design"
