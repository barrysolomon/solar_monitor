#!/bin/bash

echo "🔧 Fixing JavaScript display issue..."

# The JavaScript got inserted as text instead of code
# Let's remove the text version and properly embed it in script tags

# First, remove the text that's showing on the page
sudo sed -i '/function switchView(viewType)/,/switchView(savedView); });/d' /home/barry/solar_monitor/templates/dashboard.html

# Now properly add the JavaScript inside script tags
sudo sed -i '/<\/script>/i\
            // View switching functionality\
            function switchView(viewType) {\
                const deviceGrid = document.getElementById('\''device-grid'\'');\
                const cardBtn = document.getElementById('\''card-view-btn'\'');\
                const gridBtn = document.getElementById('\''grid-view-btn'\'');\
                \
                if (viewType === '\''card'\'') {\
                    deviceGrid.className = '\''device-grid card-view'\'';\
                    cardBtn.classList.add('\''active'\'');\
                    gridBtn.classList.remove('\''active'\'');\
                    localStorage.setItem('\''dashboard-view'\'', '\''card'\'');\
                } else {\
                    deviceGrid.className = '\''device-grid grid-view'\'';\
                    gridBtn.classList.add('\''active'\'');\
                    cardBtn.classList.remove('\''active'\'');\
                    localStorage.setItem('\''dashboard-view'\'', '\''grid'\'');\
                }\
            }\
            \
            // Load saved view preference on page load\
            document.addEventListener('\''DOMContentLoaded'\'', function() {\
                const savedView = localStorage.getItem('\''dashboard-view'\'') || '\''card'\'';\
                switchView(savedView);\
            });' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Fixed JavaScript display issue"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service
sleep 3

echo "✅ Service restarted"
echo "🌐 Refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh"
echo ""
echo "✅ The JavaScript function should no longer appear as text on the page"
