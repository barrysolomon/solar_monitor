#!/bin/bash
# Solar Monitor - HTTP Deployment Script
# Run this on the Pi to download and deploy from your computer

set -e

echo "🚀 SOLAR MONITOR - HTTP DEPLOYMENT"
echo "================================="

# Get your computer's IP (you'll need to replace this)
COMPUTER_IP="192.168.1.169"  # Your computer's IP
HTTP_PORT="8008"
PACKAGE_NAME="solar_monitor_v1.0.0_final.tar.gz"

echo "📡 Downloading from http://${COMPUTER_IP}:${HTTP_PORT}/${PACKAGE_NAME}"

# Download the deployment package
if wget -q --spider "http://${COMPUTER_IP}:${HTTP_PORT}/${PACKAGE_NAME}"; then
    echo "✅ Package found, downloading..."
    wget "http://${COMPUTER_IP}:${HTTP_PORT}/${PACKAGE_NAME}"
else
    echo "❌ Cannot reach deployment server at http://${COMPUTER_IP}:${HTTP_PORT}"
    echo ""
    echo "🔧 Troubleshooting:"
    echo "  1. Make sure HTTP server is running on your computer:"
    echo "     python3 -m http.server 8008"
    echo "  2. Check your computer's IP address:"
    echo "     ifconfig | grep 'inet 192.168'"
    echo "  3. Update COMPUTER_IP in this script if needed"
    exit 1
fi

echo "📦 Extracting package..."
tar -xzf "${PACKAGE_NAME}"

# Find the extracted directory
if [ -d "src" ]; then
    EXTRACT_DIR="."
else
    EXTRACT_DIR=$(find . -name "src" -type d | head -1 | xargs dirname)
fi

echo "📁 Found extracted files in: ${EXTRACT_DIR}"

# Create project directory
PROJECT_DIR="$HOME/solar_monitor"
echo "🏠 Setting up project directory: ${PROJECT_DIR}"

# Backup existing installation
if [ -d "${PROJECT_DIR}" ]; then
    BACKUP_DIR="$HOME/solar_monitor_backup_$(date +%Y%m%d_%H%M%S)"
    echo "💾 Backing up existing installation to ${BACKUP_DIR}"
    mv "${PROJECT_DIR}" "${BACKUP_DIR}"
fi

mkdir -p "${PROJECT_DIR}"

# Copy files
echo "📋 Copying application files..."
if [ "${EXTRACT_DIR}" != "." ]; then
    cp -r "${EXTRACT_DIR}"/* "${PROJECT_DIR}/"
else
    cp -r src templates requirements.txt install.sh start.sh "${PROJECT_DIR}/" 2>/dev/null || true
    cp README.md QUICKSTART.md RASPBERRY_PI_SETUP.md DEPLOYMENT_GUIDE.md "${PROJECT_DIR}/" 2>/dev/null || true
fi

cd "${PROJECT_DIR}"

echo "🐍 Setting up Python environment..."

# Update system packages
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python and dependencies
echo "🔧 Installing system dependencies..."
sudo apt install -y python3 python3-pip python3-venv git

# Create virtual environment
echo "🌐 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install Python packages
echo "📦 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Set permissions
chmod +x src/solar_monitor.py 2>/dev/null || true
chmod +x start.sh 2>/dev/null || true

echo "⚙️ Creating systemd service..."

# Create systemd service
sudo tee /etc/systemd/system/solar-monitor.service > /dev/null << EOF
[Unit]
Description=Solar Monitor Service
After=network.target
Wants=network.target

[Service]
Type=simple
User=$USER
Group=$USER
WorkingDirectory=${PROJECT_DIR}/src
Environment=PATH=${PROJECT_DIR}/venv/bin
ExecStart=${PROJECT_DIR}/venv/bin/python solar_monitor.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
echo "🚀 Enabling and starting service..."
sudo systemctl daemon-reload
sudo systemctl enable solar-monitor.service

# Test PVS connection
echo "🔍 Testing PVS6 connection..."
cd src
if python3 solar_monitor.py --test-connection; then
    echo "✅ PVS6 connection successful!"
    
    # Start the service
    sudo systemctl start solar-monitor.service
    
    # Wait for service to start
    sleep 5
    
    # Check service status
    if sudo systemctl is-active --quiet solar-monitor.service; then
        echo ""
        echo "🎉 SOLAR MONITOR DEPLOYMENT COMPLETE!"
        echo "===================================="
        echo ""
        echo "✅ Service Status: RUNNING"
        echo "🌐 Dashboard URL: http://$(hostname -I | awk '{print $1}'):5000"
        echo ""
        echo "📊 Features Available:"
        echo "  • Real-time solar monitoring"
        echo "  • Historical data analytics"
        echo "  • Device status management"
        echo "  • Professional dashboard"
        echo ""
        echo "🔧 Service Management:"
        echo "  sudo systemctl status solar-monitor.service"
        echo "  sudo journalctl -u solar-monitor.service -f"
        echo "  sudo systemctl restart solar-monitor.service"
        echo ""
        echo "🎯 Access your dashboard at: http://$(hostname -I | awk '{print $1}'):5000"
        
    else
        echo "❌ Service failed to start. Check logs:"
        sudo journalctl -u solar-monitor.service -n 20
    fi
    
else
    echo "❌ PVS6 connection failed!"
    echo ""
    echo "🔧 Troubleshooting:"
    echo "  1. Check PVS6 network connection"
    echo "  2. Try: ping 172.27.152.1 (WiFi hotspot)"
    echo "  3. Try: ping 172.27.153.1 (Ethernet BLUE port)"
    echo "  4. Check network configuration"
    echo ""
    echo "📖 See RASPBERRY_PI_SETUP.md for network setup help"
fi

# Cleanup
echo "🧹 Cleaning up..."
cd "$HOME"
rm -f "${PACKAGE_NAME}"

echo ""
echo "🏁 Deployment script completed!"
echo "Dashboard should be available at: http://$(hostname -I | awk '{print $1}'):5000"
