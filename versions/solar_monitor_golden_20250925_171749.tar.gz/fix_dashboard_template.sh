#!/bin/bash

echo "🎨 FIXING DASHBOARD TEMPLATE DEVICE TYPE DISPLAY"
echo "================================================"

PI_IP="192.168.1.126"
COMPUTER_IP="192.168.1.128"
HTTP_PORT="8008"

# Create the sed command to fix the JavaScript field name
echo "📝 Creating template fix..."

cat > fix_template.sh << 'EOF'
#!/bin/bash
# Fix the JavaScript field name in dashboard template
sudo sed -i 's/device\.type || '\''Unknown'\''/device.device_type || '\''Unknown'\''/g' /home/barry/solar_monitor/templates/dashboard.html

# Also fix any other instances of device.type
sudo sed -i 's/device\.type/device.device_type/g' /home/barry/solar_monitor/templates/dashboard.html

echo "✅ Fixed dashboard template JavaScript field names"
echo "🔄 Restarting service..."

# Restart service to reload template
sudo systemctl restart solar-monitor.service

sleep 3

echo "✅ Service restarted"
echo "🌐 Now refresh your browser at http://192.168.1.126:5000"
echo "   Use Ctrl+F5 for hard refresh to clear cache"
EOF

chmod +x fix_template.sh
tar -czf fix_dashboard_template.tar.gz fix_template.sh

echo "📦 Template fix package created!"
echo ""
echo "🔧 RUN THESE COMMANDS ON YOUR PI:"
echo "=================================="
echo ""
echo "# 1. Download the template fix"
echo "wget http://${COMPUTER_IP}:${HTTP_PORT}/fix_dashboard_template.tar.gz"
echo ""
echo "# 2. Extract and run the fix"
echo "tar -xzf fix_dashboard_template.tar.gz"
echo "chmod +x fix_template.sh"
echo "./fix_template.sh"
echo ""
echo "# 3. Then refresh your browser with Ctrl+F5"
echo ""
echo "✨ This will fix the JavaScript to use 'device.device_type' instead of 'device.type'"
