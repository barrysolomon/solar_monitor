#!/bin/bash
# Quick Solar Monitor Device Parsing Fix

echo "🔧 SOLAR MONITOR - QUICK DEVICE PARSING FIX"
echo "==========================================="

PI_IP="192.168.1.126"

echo "📊 Current Status Check:"
curl -s "http://$PI_IP:5000/api/current_status" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(f'  Device Count: {data.get(\"device_count\", 0)}')
    print(f'  PVS Online: {data.get(\"pvs_online\", False)}')
    print(f'  System Online: {data.get(\"system_online\", False)}')
    
    if data.get('device_count', 0) == 0 and data.get('pvs_online', False):
        print('  🔍 DIAGNOSIS: PVS6 connected but device parsing broken')
        print('  🎯 SOLUTION: Need to fix PVS Client device parsing')
    elif not data.get('pvs_online', False):
        print('  🔍 DIAGNOSIS: PVS6 connection failed')
        print('  🎯 SOLUTION: Need to fix network connection')
    else:
        print('  ✅ System appears to be working')
except:
    print('  ❌ Could not parse API response')
"

echo ""
echo "🛠️  RECOMMENDED FIX:"
echo "==================="
echo "The issue is device parsing, not connectivity."
echo ""
echo "Run this command on your Pi:"
echo "ssh barry@$PI_IP"
echo ""
echo "Then run:"
echo "wget http://192.168.1.169:8008/deploy_from_http.sh"
echo "chmod +x deploy_from_http.sh"
echo "./deploy_from_http.sh"
echo ""
echo "This will redeploy with fixed device parsing logic."
